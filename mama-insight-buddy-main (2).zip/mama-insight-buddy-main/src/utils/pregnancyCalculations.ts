import { differenceInWeeks, differenceInDays } from "date-fns";

export interface PregnancyInfo {
  currentWeek: number;
  daysLeft: number;
  babySize: string;
  isPostpartum: boolean;
}

export function calculatePregnancyInfo(
  expectedDate: string, 
  isPostpartum: boolean
): PregnancyInfo {
  const expectedDateObj = new Date(expectedDate);
  const today = new Date();
  
  let currentWeek = 0;
  let daysLeft = 0;
  
  if (isPostpartum) {
    // Calculate weeks since birth
    const weeksSinceBirth = differenceInWeeks(today, expectedDateObj);
    currentWeek = Math.min(12, Math.max(0, weeksSinceBirth));
    daysLeft = 0;
  } else {
    // Calculate pregnancy weeks (from conception, which is 2 weeks after LMP)
    const pregnancyStart = new Date(expectedDateObj);
    pregnancyStart.setDate(pregnancyStart.getDate() - 280); // 40 weeks = 280 days
    
    const pregnancyWeeks = differenceInWeeks(today, pregnancyStart);
    const daysRemaining = differenceInDays(expectedDateObj, today);
    
    currentWeek = Math.min(42, Math.max(0, pregnancyWeeks));
    daysLeft = Math.max(0, daysRemaining);
  }
  
  const babySize = getBabySizeForWeek(currentWeek);
  
  return {
    currentWeek,
    daysLeft,
    babySize,
    isPostpartum
  };
}

function getBabySizeForWeek(week: number): string {
  const babySizes = [
    "frø", "frø", "sesam", "blåbær", "ærtebælle", "linse", "blåbær",
    "hindbær", "kirsebær", "jordgulvet", "dadel", "lime", "fersken",
    "citron", "nektarin", "avocado", "løg", "paprika", "banan", 
    "grapefrugt", "broccoli", "aubergine", "majskolbe", "blomkål",
    "agurk", "rød kål", "honningdynte", "cocos", "græskar", "ananas",
    "savoy kål", "butternut squash", "honningmelon", "cantaloupe melon",
    "romaine salat", "schweizer kål", "vandmelon", "babymelon", "græskar", "vandmelon"
  ];
  
  if (week >= 0 && week < babySizes.length) {
    return babySizes[week];
  }
  
  return "baby";
}

export function calculatePregnancyWeek(expectedDate: string): number {
  if (!expectedDate) return 0;
  
  const expectedDateObj = new Date(expectedDate);
  const today = new Date();
  
  // Calculate pregnancy weeks from conception (2 weeks after LMP)
  const pregnancyStart = new Date(expectedDateObj);
  pregnancyStart.setDate(pregnancyStart.getDate() - 280); // 40 weeks = 280 days
  
  const pregnancyWeeks = differenceInWeeks(today, pregnancyStart);
  return Math.min(42, Math.max(0, pregnancyWeeks));
}

export function getWelcomeMessage(
  userName: string, 
  pregnancyInfo: PregnancyInfo
): string {
  const { currentWeek, babySize, isPostpartum } = pregnancyInfo;
  
  if (isPostpartum) {
    if (currentWeek === 0) {
      return `Hej ${userName}, tillykke med din baby! Vi er her for at støtte dig gennem de første uger som ny forælder.`;
    } else {
      return `Hej ${userName}, du er nu ${currentWeek} uge${currentWeek > 1 ? 'r' : ''} inde i dit postpartum forløb. Vi håber du og baby har det godt!`;
    }
  } else {
    if (currentWeek < 4) {
      return `Hej ${userName}, velkommen til din graviditetsrejse! Du er i de tidlige stadier af graviditeten.`;
    } else {
      return `Hej ${userName}, du er nu i uge ${currentWeek} af din graviditet. Din baby er cirka på størrelse med ${babySize === 'en ' ? '' : 'en '}${babySize}!`;
    }
  }
}