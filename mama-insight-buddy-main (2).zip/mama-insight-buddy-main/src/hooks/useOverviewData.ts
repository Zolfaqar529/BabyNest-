import { useState, useEffect } from 'react';
import { useSupabaseData } from './useSupabaseData';
import { format, subDays, startOfWeek, endOfWeek, eachDayOfInterval } from 'date-fns';
import { da } from 'date-fns/locale';
import type { PDFReportData } from './pdfGenerator';

export interface TimelineDay {
  date: string;
  formattedDate: string;
  mood: number | null;
  energy: number | null;
  symptoms: string[];
  sleep: number | null;
  weight: string | null;
  exercise: string | null;
  status: 'good' | 'warning' | 'critical' | 'no-data';
  hasData: boolean;
}

export interface SummaryData {
  mostCommonSymptoms: Array<{ symptom: string; count: number }>;
  moodTrend: 'improving' | 'declining' | 'stable';
  energyTrend: 'improving' | 'declining' | 'stable';
  averageMood: number;
  averageEnergy: number;
  daysWithData: number;
  totalDays: number;
  weeklySummary: string;
}

export interface ChartData {
  mood: Array<{ date: string; value: number }>;
  energy: Array<{ date: string; value: number }>;
  weight: Array<{ date: string; value: number }>;
  sleep: Array<{ date: string; value: number }>;
  symptoms: Array<{ symptom: string; frequency: number }>;
}

export function useOverviewData() {
  const { dailyEntries, babyLogs, profile, loading: dataLoading } = useSupabaseData();
  const [loading, setLoading] = useState(true);
  const [timelineData, setTimelineData] = useState<TimelineDay[]>([]);
  const [summaryData, setSummaryData] = useState<SummaryData | null>(null);
  const [chartData, setChartData] = useState<ChartData | null>(null);

  useEffect(() => {
    if (!dataLoading && dailyEntries) {
      processData();
    }
  }, [dataLoading, dailyEntries, babyLogs]);

  const processData = () => {
    const timeline = generateTimelineData();
    const summary = generateSummaryData();
    const charts = generateChartData();

    setTimelineData(timeline);
    setSummaryData(summary);
    setChartData(charts);
    setLoading(false);
  };

  const generateTimelineData = (): TimelineDay[] => {
    const days = Array.from({ length: 30 }, (_, i) => {
      const date = subDays(new Date(), 29 - i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const entry = dailyEntries.find(e => e.date === dateStr);

      const symptoms = entry?.symptoms || [];
      const mood = entry?.mood || null;
      const energy = entry?.energy_level || null;

      // Determine status based on data
      let status: TimelineDay['status'] = 'no-data';
      if (entry) {
        if (symptoms.length === 0 && (mood || 0) >= 7 && (energy || 0) >= 7) {
          status = 'good';
        } else if (symptoms.length <= 2 && (mood || 0) >= 5 && (energy || 0) >= 5) {
          status = 'warning';
        } else {
          status = 'critical';
        }
      }

      return {
        date: dateStr,
        formattedDate: format(date, 'dd/MM', { locale: da }),
        mood,
        energy,
        symptoms,
        sleep: entry?.sleep || null,
        weight: entry?.weight || null,
        exercise: entry?.exercise || null,
        status,
        hasData: !!entry,
      };
    });

    return days;
  };

  const generateSummaryData = (): SummaryData => {
    const last7Days = timelineData.slice(-7);
    const previous7Days = timelineData.slice(-14, -7);

    // Most common symptoms from both daily entries and baby logs
    const symptomCounts: { [key: string]: number } = {};
    
    // Count symptoms from daily tracking
    dailyEntries.forEach(entry => {
      if (entry.symptoms) {
        entry.symptoms.forEach(symptom => {
          symptomCounts[symptom] = (symptomCounts[symptom] || 0) + 1;
        });
      }
    });

    // Add notes from baby logs as "symptoms" if they contain concerning content
    babyLogs.forEach(log => {
      if (log.notes && log.notes.trim()) {
        symptomCounts['Baby noter'] = (symptomCounts['Baby noter'] || 0) + 1;
      }
      if (log.sleep_quality && log.sleep_quality < 5) {
        symptomCounts['Dårlig baby søvn'] = (symptomCounts['Dårlig baby søvn'] || 0) + 1;
      }
    });

    const mostCommonSymptoms = Object.entries(symptomCounts)
      .map(([symptom, count]) => ({ symptom, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    // Calculate trends
    const recentMoodAvg = last7Days
      .filter(d => d.mood !== null)
      .reduce((sum, d) => sum + (d.mood || 0), 0) / last7Days.filter(d => d.mood !== null).length || 0;

    const previousMoodAvg = previous7Days
      .filter(d => d.mood !== null)
      .reduce((sum, d) => sum + (d.mood || 0), 0) / previous7Days.filter(d => d.mood !== null).length || 0;

    const recentEnergyAvg = last7Days
      .filter(d => d.energy !== null)
      .reduce((sum, d) => sum + (d.energy || 0), 0) / last7Days.filter(d => d.energy !== null).length || 0;

    const previousEnergyAvg = previous7Days
      .filter(d => d.energy !== null)
      .reduce((sum, d) => sum + (d.energy || 0), 0) / previous7Days.filter(d => d.energy !== null).length || 0;

    const moodTrend = recentMoodAvg > previousMoodAvg ? 'improving' : recentMoodAvg < previousMoodAvg ? 'declining' : 'stable';
    const energyTrend = recentEnergyAvg > previousEnergyAvg ? 'improving' : recentEnergyAvg < previousEnergyAvg ? 'declining' : 'stable';

    // Generate weekly summary text including baby data
    const weeklySummary = generateWeeklySummaryText(mostCommonSymptoms, moodTrend, energyTrend);

    return {
      mostCommonSymptoms,
      moodTrend,
      energyTrend,
      averageMood: Math.round(recentMoodAvg * 10) / 10,
      averageEnergy: Math.round(recentEnergyAvg * 10) / 10,
      daysWithData: last7Days.filter(d => d.hasData).length,
      totalDays: 7,
      weeklySummary,
    };
  };

  const generateChartData = (): ChartData => {
    const last30Days = timelineData.slice(-30);

    const mood = last30Days
      .filter(d => d.mood !== null)
      .map(d => ({ date: d.formattedDate, value: d.mood! }));

    const energy = last30Days
      .filter(d => d.energy !== null)
      .map(d => ({ date: d.formattedDate, value: d.energy! }));

    const weight = last30Days
      .filter(d => d.weight !== null)
      .map(d => ({ date: d.formattedDate, value: parseFloat(d.weight!) }));

    const sleep = last30Days
      .filter(d => d.sleep !== null)
      .map(d => ({ date: d.formattedDate, value: d.sleep! }));

    // Symptoms frequency including baby data
    const symptomCounts: { [key: string]: number } = {};
    
    // Count symptoms from daily tracking
    dailyEntries.forEach(entry => {
      if (entry.symptoms) {
        entry.symptoms.forEach(symptom => {
          symptomCounts[symptom] = (symptomCounts[symptom] || 0) + 1;
        });
      }
    });

    // Add baby tracking data to symptoms
    babyLogs.forEach(log => {
      if (log.notes && log.notes.trim()) {
        symptomCounts['Baby dokumentation'] = (symptomCounts['Baby dokumentation'] || 0) + 1;
      }
      if (log.mood_rating && log.mood_rating < 5) {
        symptomCounts['Baby utilpasshed'] = (symptomCounts['Baby utilpasshed'] || 0) + 1;
      }
    });

    const symptoms = Object.entries(symptomCounts)
      .map(([symptom, frequency]) => ({ symptom, frequency }))
      .sort((a, b) => b.frequency - a.frequency)
      .slice(0, 10);

    return { mood, energy, weight, sleep, symptoms };
  };

  const generateWeeklySummaryText = (
    symptoms: Array<{ symptom: string; count: number }>,
    moodTrend: string,
    energyTrend: string
  ): string => {
    const topSymptoms = symptoms.slice(0, 3).map(s => s.symptom).join(', ');
    const moodText = moodTrend === 'improving' ? 'forbedret' : moodTrend === 'declining' ? 'forværret' : 'stabilt';
    const energyText = energyTrend === 'improving' ? 'forbedret' : energyTrend === 'declining' ? 'forværret' : 'stabilt';
    
    const babyDataCount = babyLogs.length;
    const babyText = babyDataCount > 0 ? ` ${babyDataCount} baby-logføringer registreret.` : '';

    return `De mest rapporterede symptomer: ${topSymptoms}. Humør har været ${moodText} og energiniveau ${energyText} i løbet af ugen.${babyText}`;
  };

  const generateReport = async () => {
    if (!summaryData || !chartData || !profile) {
      console.error('Manglende data til rapport generation');
      return;
    }

    const { generatePDFReport } = await import('./pdfGenerator');
    const { calculatePregnancyWeek } = await import('../utils/pregnancyCalculations');
    
    const currentWeek = calculatePregnancyWeek(profile.due_date || '');
    
    const reportData: PDFReportData = {
      userProfile: {
        motherName: profile.parent_name || profile.user_name || 'Mor',
        expectedDate: profile.due_date || '',
        babyName: profile.baby_name || 'Baby',
        currentWeek: currentWeek,
      },
      timelineData,
      summaryData,
      chartData,
      generatedDate: new Date().toLocaleDateString('da-DK'),
    };

    try {
      const pdfBlob = await generatePDFReport(reportData);
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `BabyNest-Rapport-${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Fejl ved PDF generation:', error);
    }
  };

  const exportCSV = async () => {
    if (!summaryData || !chartData || !profile) {
      console.error('Manglende data til CSV eksport');
      return;
    }

    const { exportToCSV } = await import('./pdfGenerator');
    const { calculatePregnancyWeek } = await import('../utils/pregnancyCalculations');
    
    const currentWeek = calculatePregnancyWeek(profile.due_date || '');
    
    const reportData: PDFReportData = {
      userProfile: {
        motherName: profile.parent_name || profile.user_name || 'Mor',
        expectedDate: profile.due_date || '',
        babyName: profile.baby_name || 'Baby',
        currentWeek: currentWeek,
      },
      timelineData,
      summaryData,
      chartData,
      generatedDate: new Date().toLocaleDateString('da-DK'),
    };

    try {
      const csvContent = exportToCSV(reportData);
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `BabyNest-Data-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Fejl ved CSV eksport:', error);
    }
  };

  return {
    timelineData,
    summaryData,
    chartData,
    loading,
    generateReport,
    exportCSV,
  };
} 
