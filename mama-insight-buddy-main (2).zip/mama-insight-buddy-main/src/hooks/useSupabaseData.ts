import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthProvider';

export interface UserProfile {
  id: string;
  user_id: string;
  user_name: string;
  email: string;
  parent_name?: string;
  due_date?: string;
  baby_name?: string;
  baby_gender?: string;
  consent_given?: boolean;
  profile_image_url?: string;
  share_data_for_research?: boolean;
  created_at: string;
  updated_at: string;
}

export interface Baby {
  id: string;
  user_id: string;
  baby_name: string;
  birth_date: string | null;
  due_date: string | null;
  gender: string | null;
  is_expecting: boolean;
  created_at: string;
  updated_at: string;
}

export interface DailyEntry {
  id: string;
  user_id: string;
  date: string;
  physical_feelings?: string;
  emotional_state?: string;
  notes?: string;
  energy_level?: number;
  ai_feedback?: string;
  symptoms?: string[];
  source_tab?: string;
  mood?: number;
  sleep?: number;
  weight?: string;
  exercise?: string;
  stress_level?: number;
  sleep_quality?: number;
  nausea_level?: number;
  created_at: string;
  updated_at: string;
}

export interface BabyLog {
  id: string;
  user_id: string;
  baby_id?: string;
  date: string;
  sleep_hours?: number;
  sleep_quality?: number;
  feeding_times?: number;
  feeding_notes?: string;
  diaper_changes?: number;
  weight_grams?: number;
  length_cm?: number;
  notes?: string;
  mood_rating?: number;
  development_notes?: string;
  created_at: string;
  updated_at: string;
}

export function useSupabaseData() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [baby, setBaby] = useState<Baby | null>(null);
  const [dailyEntries, setDailyEntries] = useState<DailyEntry[]>([]);
  const [babyLogs, setBabyLogs] = useState<BabyLog[]>([]);
  const [loading, setLoading] = useState(true);

  // Load user data when authenticated
  useEffect(() => {
    if (user) {
      loadUserData();
    } else {
      setProfile(null);
      setBaby(null);
      setDailyEntries([]);
      setBabyLogs([]);
      setLoading(false);
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;

    setLoading(true);
    try {
      // Load profile
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (profileData) {
        setProfile(profileData);
      }

      // Load baby
      const { data: babyData } = await supabase
        .from('babies')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (babyData) {
        setBaby(babyData);
      }

      // Load daily entries
      const { data: entriesData } = await supabase
        .from('daily_entries')
        .select('*')
        .eq('user_id', user.id)
        .order('date', { ascending: false });

      if (entriesData) {
        setDailyEntries(entriesData);
      }

      // Load baby logs if the baby is born
      if (babyData && babyData.birth_date && !babyData.is_expecting) {
        const { data: babyLogsData } = await supabase
          .from('baby_logs')
          .select('*')
          .eq('user_id', user.id)
          .order('date', { ascending: false });

        if (babyLogsData) {
          setBabyLogs(babyLogsData);
        }
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveDailyEntry = async (data: {
    date: string;
    mood?: number;
    energy?: number;
    energy_level?: number;
    sleep?: number;
    symptoms?: string[];
    weight?: string;
    exercise?: string;
    notes?: string;
    physical_feelings?: string;
    emotional_state?: string;
    source_tab?: string;
    stress_level?: number;
    sleep_quality?: number;
    nausea_level?: number;
  }) => {
    if (!user) return null;

    try {
      // Check if entry exists for this date
      const { data: existingEntry } = await supabase
        .from('daily_entries')
        .select('*')
        .eq('user_id', user.id)
        .eq('date', data.date)
        .single();

      if (existingEntry) {
        // Update existing entry
        const { data: updatedEntry, error } = await supabase
          .from('daily_entries')
          .update({
            ...data,
            energy_level: data.energy_level || data.energy,
          })
          .eq('id', existingEntry.id)
          .select()
          .single();

        if (error) throw error;

        // Update local state
        setDailyEntries(prev => 
          prev.map(entry => 
            entry.id === existingEntry.id 
              ? { ...entry, ...updatedEntry }
              : entry
          )
        );
        
        // Trigger refresh for other components to get updated data
        setTimeout(() => {
          loadUserData();
        }, 100);

        return updatedEntry;
      } else {
        // Create new entry
        const { data: newEntry, error } = await supabase
          .from('daily_entries')
          .insert({
            user_id: user.id,
            ...data,
            energy_level: data.energy_level || data.energy,
          })
          .select()
          .single();

        if (error) throw error;

        // Update local state
        setDailyEntries(prev => [newEntry, ...prev]);
        
        // Trigger refresh for other components to get updated data
        setTimeout(() => {
          loadUserData();
        }, 100);

        return newEntry;
      }
    } catch (error) {
      console.error('Error saving daily entry:', error);
      throw error;
    }
  };

  const saveBabyLog = async (data: {
    date: string;
    sleep_hours?: number;
    sleep_quality?: number;
    feeding_times?: number;
    feeding_notes?: string;
    diaper_changes?: number;
    weight_grams?: number;
    length_cm?: number;
    notes?: string;
    mood_rating?: number;
    development_notes?: string;
  }) => {
    if (!user) return null;

    try {
      // Check if entry exists for this date
      const { data: existingLog } = await supabase
        .from('baby_logs')
        .select('*')
        .eq('user_id', user.id)
        .eq('date', data.date)
        .single();

      if (existingLog) {
        // Update existing log
        const { data: updatedLog, error } = await supabase
          .from('baby_logs')
          .update(data)
          .eq('id', existingLog.id)
          .select()
          .single();

        if (error) throw error;

        // Update local state
        setBabyLogs(prev => 
          prev.map(log => 
            log.id === existingLog.id 
              ? { ...log, ...updatedLog }
              : log
          )
        );

        return updatedLog;
      } else {
        // Create new log
        const { data: newLog, error } = await supabase
          .from('baby_logs')
          .insert({
            user_id: user.id,
            baby_id: baby?.id,
            ...data,
          })
          .select()
          .single();

        if (error) throw error;

        // Update local state
        setBabyLogs(prev => [newLog, ...prev]);

        return newLog;
      }
    } catch (error) {
      console.error('Error saving baby log:', error);
      throw error;
    }
  };

  const updateProfile = async (profileData: Partial<UserProfile>) => {
    if (!user) return null;

    try {
      const { data: updatedProfile, error } = await supabase
        .from('profiles')
        .update(profileData)
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) throw error;

      // Update local state
      setProfile(prev => prev ? { ...prev, ...updatedProfile } : null);

      return updatedProfile;
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  };

  const getTodayEntry = () => {
    const today = new Date().toISOString().split('T')[0];
    return dailyEntries.find(entry => entry.date === today);
  };

  const getTodayBabyLog = () => {
    const today = new Date().toISOString().split('T')[0];
    return babyLogs.find(log => log.date === today);
  };

  return {
    profile,
    baby,
    dailyEntries,
    babyLogs,
    loading,
    saveDailyEntry,
    saveBabyLog,
    updateProfile,
    getTodayEntry,
    getTodayBabyLog,
    refreshData: loadUserData,
  };
}