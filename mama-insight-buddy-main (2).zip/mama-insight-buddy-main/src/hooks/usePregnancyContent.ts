import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface PregnancyWeekContent {
  id: string;
  week_number: number;
  title: string;
  message: string;
  tip: string;
  illustration_url?: string;
  created_at: string;
  updated_at: string;
}

export function usePregnancyContent() {
  const [weekContent, setWeekContent] = useState<PregnancyWeekContent[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadWeekContent();
  }, []);

  const loadWeekContent = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('pregnancy_week_content')
        .select('*')
        .order('week_number', { ascending: true });

      if (error) throw error;
      
      setWeekContent(data || []);
    } catch (error) {
      console.error('Error loading pregnancy week content:', error);
    } finally {
      setLoading(false);
    }
  };

  const getContentForWeek = (weekNumber: number) => {
    return weekContent.find(content => content.week_number === weekNumber);
  };

  return {
    weekContent,
    loading,
    getContentForWeek,
    refreshContent: loadWeekContent,
  };
}