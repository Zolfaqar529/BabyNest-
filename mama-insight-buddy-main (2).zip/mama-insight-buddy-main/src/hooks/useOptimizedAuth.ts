import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/components/auth/AuthProvider';
import { supabase } from '@/integrations/supabase/client';
import { UserProfile, Baby } from './useSupabaseData';

interface CachedUserData {
  profile: UserProfile | null;
  baby: Baby | null;
  timestamp: number;
}

const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
const CACHE_KEY = 'babynest_user_data';

export function useOptimizedAuth() {
  const { user, loading: authLoading } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [baby, setBaby] = useState<Baby | null>(null);
  const [loading, setLoading] = useState(true);
  const [hasShownWelcome, setHasShownWelcome] = useState(false);

  // Get cached data
  const getCachedData = useCallback((): CachedUserData | null => {
    try {
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) {
        const data = JSON.parse(cached) as CachedUserData;
        const isExpired = Date.now() - data.timestamp > CACHE_DURATION;
        return isExpired ? null : data;
      }
    } catch (error) {
      console.error('Error reading cache:', error);
    }
    return null;
  }, []);

  // Set cached data
  const setCachedData = useCallback((profile: UserProfile | null, baby: Baby | null) => {
    try {
      const data: CachedUserData = {
        profile,
        baby,
        timestamp: Date.now()
      };
      localStorage.setItem(CACHE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Error setting cache:', error);
    }
  }, []);

  // Check if welcome popup should be shown
  const checkWelcomeStatus = useCallback(() => {
    if (user) {
      const welcomeKey = `babynest_welcome_shown_${user.id}`;
      const hasShown = localStorage.getItem(welcomeKey) === 'true';
      setHasShownWelcome(hasShown);
    } else {
      setHasShownWelcome(false);
    }
  }, [user]);

  // Mark welcome as shown
  const markWelcomeShown = useCallback(() => {
    if (user) {
      const welcomeKey = `babynest_welcome_shown_${user.id}`;
      localStorage.setItem(welcomeKey, 'true');
      setHasShownWelcome(true);
    }
  }, [user]);

  // Load user data with caching
  const loadUserData = useCallback(async () => {
    if (!user) {
      setProfile(null);
      setBaby(null);
      setLoading(false);
      return;
    }

    // Try to get cached data first
    const cachedData = getCachedData();
    if (cachedData && cachedData.profile && cachedData.baby) {
      setProfile(cachedData.profile);
      setBaby(cachedData.baby);
      setLoading(false);
      return;
    }

    setLoading(true);
    
    try {
      // Load critical data in parallel
      const [profileResult, babyResult] = await Promise.all([
        supabase
          .from('profiles')
          .select('*')
          .eq('user_id', user.id)
          .single(),
        supabase
          .from('babies')
          .select('*')
          .eq('user_id', user.id)
          .single()
      ]);

      const profileData = profileResult.data;
      const babyData = babyResult.data;

      setProfile(profileData);
      setBaby(babyData);

      // Cache the data
      if (profileData && babyData) {
        setCachedData(profileData, babyData);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  }, [user, getCachedData, setCachedData]);

  // Clear cache when user changes
  useEffect(() => {
    if (!user) {
      localStorage.removeItem(CACHE_KEY);
    }
  }, [user]);

  // Load data when user changes
  useEffect(() => {
    loadUserData();
    checkWelcomeStatus();
  }, [loadUserData, checkWelcomeStatus]);

  // Refresh data function
  const refreshData = useCallback(async () => {
    localStorage.removeItem(CACHE_KEY);
    await loadUserData();
  }, [loadUserData]);

  return {
    user,
    profile,
    baby,
    loading: authLoading || loading,
    hasShownWelcome,
    markWelcomeShown,
    refreshData
  };
}