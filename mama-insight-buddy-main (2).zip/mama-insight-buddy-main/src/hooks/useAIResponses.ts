import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthProvider';

export interface AIResponse {
  id: string;
  user_id: string;
  question: string;
  response: string;
  created_at: string;
  updated_at: string;
}

export function useAIResponses() {
  const { user } = useAuth();
  const [aiResponses, setAIResponses] = useState<AIResponse[]>([]);
  const [loading, setLoading] = useState(false);

  // Load AI responses when authenticated
  useEffect(() => {
    if (user) {
      loadAIResponses();
    } else {
      setAIResponses([]);
    }
  }, [user]);

  const loadAIResponses = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('ai_responses')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setAIResponses(data || []);
    } catch (error) {
      console.error('Error loading AI responses:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveAIResponse = async (question: string, response: string) => {
    if (!user) return null;

    try {
      const { data, error } = await supabase
        .from('ai_responses')
        .insert({
          user_id: user.id,
          question,
          response,
        })
        .select()
        .single();

      if (error) throw error;

      // Update local state
      setAIResponses(prev => [data, ...prev]);
      
      return data;
    } catch (error) {
      console.error('Error saving AI response:', error);
      throw error;
    }
  };

  return {
    aiResponses,
    loading,
    saveAIResponse,
    refreshResponses: loadAIResponses,
  };
}