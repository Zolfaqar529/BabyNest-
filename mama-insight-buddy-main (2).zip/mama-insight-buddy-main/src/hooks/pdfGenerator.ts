import jsPDF from 'jspdf';
import { TimelineDay, SummaryData, ChartData } from '@/hooks/useOverviewData';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

export interface PDFReportData {
  userProfile: {
    motherName: string;
    expectedDate: string;
    babyName: string;
    currentWeek: number;
  };
  timelineData: TimelineDay[];
  summaryData: SummaryData;
  chartData: ChartData;
  generatedDate: string;
}

export const generatePDFReport = async (data: PDFReportData): Promise<Blob> => {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let yPos = 20;
  
  // Header
  doc.setFontSize(20);
  doc.text('BabyNest+ Sundhedsrapport', pageWidth / 2, yPos, { align: 'center' });
  yPos += 20;
  
  // Patient info
  doc.setFontSize(12);
  doc.text(`Genereret: ${data.generatedDate}`, 20, yPos);
  yPos += 10;
  doc.text(`Patient: ${data.userProfile.motherName}`, 20, yPos);
  yPos += 10;
  doc.text(`Termin: ${data.userProfile.expectedDate}`, 20, yPos);
  yPos += 10;
  doc.text(`Nuværende uge: ${data.userProfile.currentWeek}`, 20, yPos);
  yPos += 20;
  
  // Summary section
  doc.setFontSize(14);
  doc.text('UGENS OPSUMMERING:', 20, yPos);
  yPos += 15;
  
  doc.setFontSize(10);
  const summaryLines = doc.splitTextToSize(data.summaryData.weeklySummary, pageWidth - 40);
  doc.text(summaryLines, 20, yPos);
  yPos += summaryLines.length * 5 + 10;
  
  // Key metrics
  doc.setFontSize(12);
  doc.text(`Gennemsnit humør: ${data.summaryData.averageMood}/10`, 20, yPos);
  yPos += 10;
  doc.text(`Gennemsnit energi: ${data.summaryData.averageEnergy}/10`, 20, yPos);
  yPos += 10;
  doc.text(`Data dækning: ${data.summaryData.daysWithData} af ${data.summaryData.totalDays} dage`, 20, yPos);
  yPos += 20;
  
  // Symptoms
  if (data.summaryData.mostCommonSymptoms.length > 0) {
    doc.setFontSize(14);
    doc.text('MEST RAPPORTEREDE SYMPTOMER:', 20, yPos);
    yPos += 15;
    
    doc.setFontSize(10);
    data.summaryData.mostCommonSymptoms.forEach(symptom => {
      doc.text(`• ${symptom.symptom}: ${symptom.count} gange`, 25, yPos);
      yPos += 8;
    });
    yPos += 10;
  }
  
  // Timeline summary
  if (yPos > 250) {
    doc.addPage();
    yPos = 20;
  }
  
  doc.setFontSize(14);
  doc.text('DAGLIG OVERSIGT (SIDSTE 7 DAGE):', 20, yPos);
  yPos += 15;
  
  const recentDays = data.timelineData.slice(-7);
  doc.setFontSize(9);
  recentDays.forEach(day => {
    if (yPos > 270) {
      doc.addPage();
      yPos = 20;
    }
    
    const statusText = day.status === 'good' ? 'God' : 
                      day.status === 'warning' ? 'Advarsel' : 
                      day.status === 'critical' ? 'Kritisk' : 'Ingen data';
    
    doc.text(`${day.formattedDate}: ${statusText}`, 25, yPos);
    yPos += 6;
    
    if (day.hasData) {
      if (day.mood) doc.text(`  Humør: ${day.mood}/10`, 30, yPos), yPos += 5;
      if (day.energy) doc.text(`  Energi: ${day.energy}/10`, 30, yPos), yPos += 5;
      if (day.symptoms.length > 0) {
        doc.text(`  Symptomer: ${day.symptoms.join(', ')}`, 30, yPos);
        yPos += 5;
      }
    }
    yPos += 3;
  });
  
  // Disclaimer
  if (yPos > 250) {
    doc.addPage();
    yPos = 20;
  }
  
  yPos += 20;
  doc.setFontSize(12);
  doc.setFont(undefined, 'bold');
  doc.text('VIGTIG BEMÆRKNING:', 20, yPos);
  yPos += 10;
  
  doc.setFont(undefined, 'normal');
  doc.setFontSize(10);
  const disclaimerText = 'Denne rapport er ikke en erstatning for lægefaglig vurdering. Konsulter altid din læge eller jordemoder ved bekymringer.';
  const disclaimerLines = doc.splitTextToSize(disclaimerText, pageWidth - 40);
  doc.text(disclaimerLines, 20, yPos);
  
  return doc.output('blob');
};

export const exportToCSV = (data: PDFReportData): string => {
  const headers = ['Dato', 'Humør', 'Energi', 'Søvn', 'Vægt', 'Symptomer', 'Motion'];
  
  const csvRows = [
    headers.join(','),
    ...data.timelineData.map(day => [
      day.date,
      day.mood || '',
      day.energy || '',
      day.sleep || '',
      day.weight || '',
      day.symptoms.join(';') || '',
      day.exercise || ''
    ].join(','))
  ];
  
  return csvRows.join('\n');
}; 
