// Advanced GPT-4o AI Service for contextual pregnancy guidance
interface GPTMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface GPTResponse {
  choices: {
    message: {
      content: string;
    }
  }[];
}

export class GPTService {
  private static readonly API_KEY = 'PLACEHOLDER_API_KEY'; // To be replaced with actual API key
  private static readonly API_URL = 'https://api.openai.com/v1/chat/completions';

  static async generateContextualResponse(
    userMessage: string,
    userContext: {
      motherName: string;
      expectedDate: string;
      babyName: string;
      babyGender: string;
      isPostpartum: boolean;
      pregnancyWeek: number;
    },
    recentData: any[] = [],
    conversationHistory: string[] = []
  ): Promise<string> {
    
    // For now, return a simulated advanced response until API key is configured
    return this.generateSimulatedAdvancedResponse(userMessage, userContext, recentData);
  }

  private static generateSimulatedAdvancedResponse(
    userMessage: string,
    userContext: any,
    recentData: any[]
  ): string {
    const lowerMessage = userMessage.toLowerCase();
    
    // Advanced contextual understanding
    if (lowerMessage.includes('bekymr') || lowerMessage.includes('angst') || lowerMessage.includes('nervøs')) {
      return `Kære ${userContext.motherName}, jeg forstår din bekymring. Det er helt naturligt at føle usikkerhed under graviditeten. 

I uge ${userContext.pregnancyWeek} er det normalt at tænke på ${userContext.babyName}s udvikling. ${userContext.babyGender === 'dreng' ? 'Han' : 'Hun'} vokser og udvikler sig, og dine følelser viser hvor meget du allerede elsker dit barn.

💡 **Mine råd til dig:**
• Tag dybe vejrtrækninger og fokuser på nuet
• Tal med din partner eller en ven om dine bekymringer  
• Husk at din krop ved hvad den laver
• Kontakt din jordemoder hvis bekymringerne vedvarer

Du gør det fantastisk, og ${userContext.babyName} har det godt! 💚`;
    }

    if (lowerMessage.includes('søvn') || lowerMessage.includes('sove') || lowerMessage.includes('træt')) {
      const recentSleep = recentData.length > 0 ? recentData[recentData.length - 1]?.sleep : null;
      
      return `${userContext.motherName}, søvn er så vigtig for dig og ${userContext.babyName}! 😴

${recentSleep ? `Jeg kan se du har sovet ${recentSleep} timer i den seneste registrering. ` : ''}

I uge ${userContext.pregnancyWeek} er det almindeligt at have søvnudfordringer. Din krop arbejder hårdt, og ${userContext.babyName} påvirker din hvile.

🌙 **Søvntips til dig:**
• Gå i seng på samme tid hver aften
• Undgå skærme 1 time før sengetid
• Brug ekstra puder til støtte
• Tag varmt bad eller drik kamillerte
• Lav let motion tidligere på dagen

Hvis søvnproblemerne vedvarer, tal med din jordemoder. Du har brug for din hvile! ✨`;
    }

    if (lowerMessage.includes('mad') || lowerMessage.includes('spise') || lowerMessage.includes('kost')) {
      return `Rigtig god ernæring er en gave til ${userContext.babyName}, ${userContext.motherName}! 🥗

I uge ${userContext.pregnancyWeek} har ${userContext.babyGender === 'dreng' ? 'han' : 'hun'} brug for de rigtige næringsstoffer til optimal udvikling.

🍎 **Mine anbefalinger:**
• Spis proteinrige fødevarer (fisk, kød, bønner, æg)
• Få folsyre via grønne bladgrøntsager
• Vælg fuldkorns og komplekse kulhydrater  
• Drik rigeligt med vand (2-3 liter dagligt)
• Tag dine vitaminer/mineraler som anbefalet

**Undgå:** Rå fisk, bløde oste, alkohol, for meget koffein

Spis hvad din krop har lyst til - den ved ofte hvad den har brug for! 💛`;
    }

    if (lowerMessage.includes('bevæg') || lowerMessage.includes('motion') || lowerMessage.includes('træn')) {
      return `Motion er fantastisk for dig og ${userContext.babyName}, ${userContext.motherName}! 💪

I uge ${userContext.pregnancyWeek} kan let til moderat aktivitet gavne jer begge enormt.

🚶‍♀️ **Sikre aktiviteter:**
• Gåture (15-30 minutter dagligt)
• Svømning (meget skånsomt for led)
• Graviditetsyoga (styrker og afspænder)
• Let styrketræning med lette vægte
• Vejrtrækningsøvelser

**Undgå:** Kontaktspot, faldrisiko, overophedning

Lyt altid til din krop - den fortæller dig hvad den kan klare. Start stille og roligt! 🌟`;
    }

    // Advanced pattern recognition based on recent data
    if (recentData.length >= 3) {
      const recentMood = recentData.slice(-3).map(d => d.mood).filter(Boolean);
      const recentEnergy = recentData.slice(-3).map(d => d.energy).filter(Boolean);
      
      if (recentMood.length > 0 && recentMood.every(m => m < 5)) {
        return `${userContext.motherName}, jeg kan se at dit humør har været udfordret de sidste dage. Det er helt forståeligt - graviditet påvirker følelserne på mange måder. 🤗

Din krop laver mirakler, og det er okay at have svære dage. ${userContext.babyName} mærker din kærlighed uanset hvordan du har det.

💝 **For at støtte dit velbefindende:**
• Tal med nogen du stoler på om dine følelser
• Få frisk luft og sollys hver dag
• Lav ting der gør dig glad (musik, læsning, varmt bad)
• Husk på at hormoner påvirker dit humør
• Kontakt din jordemoder hvis det bliver værre

Du klarer det så godt, og denne fase går over! ✨`;
      }
    }

    // Fallback with intelligent context
    return `Tak for dit spørgsmål, ${userContext.motherName}! 💭

Jeg er her for at hjælpe dig gennem din graviditet med ${userContext.babyName}. Som din AI-assistent kan jeg guide dig inden for:

🤰 **Graviditetsspørgsmål:** Symptomer, udvikling, bekymringer
👶 **Baby-udvikling:** Hvad sker der i uge ${userContext.pregnancyWeek}
💚 **Velbefindende:** Kost, motion, søvn, stress
🩺 **Hvornår skal jeg kontakte min jordemoder**

Prøv at stille dit spørgsmål på en anden måde, eller fortæl mig mere specifikt hvad du tænker på. Jeg er her for dig! ✨`;
  }

  // Future implementation for actual GPT-4o integration
  private static async callGPTAPI(messages: GPTMessage[]): Promise<string> {
    try {
      const response = await fetch(this.API_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: messages,
          max_tokens: 500,
          temperature: 0.7,
          top_p: 0.9,
        }),
      });

      if (!response.ok) {
        throw new Error(`GPT API error: ${response.status}`);
      }

      const data: GPTResponse = await response.json();
      return data.choices[0]?.message?.content || 'Jeg beklager, jeg kunne ikke generere et svar lige nu.';
    } catch (error) {
      console.error('GPT API call failed:', error);
      return 'Jeg har problemer med at svare lige nu. Prøv igen senere.';
    }
  }

  private static buildSystemPrompt(userContext: any): string {
    return `Du er en empatisk og professionel AI-assistent specialiseret i graviditet og babyudvikling. 

BRUGERINFO:
- Navn: ${userContext.motherName}
- Baby: ${userContext.babyName} (${userContext.babyGender})
- Uge: ${userContext.pregnancyWeek}
- Status: ${userContext.isPostpartum ? 'Efter fødsel' : 'Gravid'}

VIGTIGE RETNINGSLINJER:
1. Vær altid varm, støttende og empatisk
2. Brug brugerens og barnets navn naturligt
3. Giv konkrete, praktiske råd
4. Undgå medicinske diagnoser
5. Anbefalaltid kontakt til jordemoder ved bekymringer
6. Fokuser på hvad der er normalt for den aktuelle uge
7. Svar på dansk med varme og empati

Dine svar skal være personlige, støttende og informative.`;
  }
}