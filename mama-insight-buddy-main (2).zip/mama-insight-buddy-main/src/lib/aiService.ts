// AI Service for enhanced symptom understanding and personalized guidance
import { differenceInWeeks } from "date-fns";

export interface UserContext {
  motherName: string;
  expectedDate: string;
  babyName: string;
  babyGender: string;
  isPostpartum: boolean;
}

export interface SymptomAnalysis {
  symptom: string;
  context: {
    pregnancyWeek: number;
    isEarlyPregnancy: boolean;
    isThirdTrimester: boolean;
    isPostpartum: boolean;
  };
  explanation: string;
  suggestions: string[];
  needsAttention: boolean;
  empathicResponse: string;
}

export interface DailyData {
  date: string;
  mood: number;
  energy: number;
  sleep: number;
  symptoms: string[];
  notes: string;
  weight?: string;
  exercise?: string;
}

export interface CombinedInsight {
  pattern: string;
  observation: string;
  suggestion: string;
  empathicMessage: string;
}

export class AIService {
  static calculatePregnancyWeek(expectedDate: string, isPostpartum: boolean): number {
    const today = new Date();
    const dueDate = new Date(expectedDate);
    
    if (isPostpartum) {
      return Math.max(0, differenceInWeeks(today, dueDate));
    } else {
      const pregnancyStart = new Date(dueDate);
      pregnancyStart.setDate(pregnancyStart.getDate() - 280); // 40 weeks = 280 days
      return Math.max(0, differenceInWeeks(today, pregnancyStart));
    }
  }

  static analyzeSymptom(symptom: string, userContext: UserContext, recentData?: DailyData[]): SymptomAnalysis {
    const pregnancyWeek = this.calculatePregnancyWeek(userContext.expectedDate, userContext.isPostpartum);
    const isEarlyPregnancy = pregnancyWeek <= 12 && !userContext.isPostpartum;
    const isThirdTrimester = pregnancyWeek >= 28 && !userContext.isPostpartum;
    
    const context = {
      pregnancyWeek,
      isEarlyPregnancy,
      isThirdTrimester,
      isPostpartum: userContext.isPostpartum
    };

    const symptomLower = symptom.toLowerCase();
    
    // Enhanced symptom analysis with context
    if (symptomLower.includes('kvalme') || symptomLower.includes('morgenkvalme')) {
      return {
        symptom,
        context,
        explanation: isEarlyPregnancy 
          ? `Kvalme er helt normalt i de første måneder, ${userContext.motherName}. Dine hormoner arbejder hårdt på at støtte ${userContext.babyName}s udvikling.`
          : `Kvalme senere i graviditeten kan skyldes at ${userContext.babyName} tager mere plads og presser på din mavesæk.`,
        suggestions: [
          "Spis små, hyppige måltider i stedet for store portioner",
          "Prøv ingefær-te eller ingefær-drops",
          "Undgå stærke dufte der trigger kvalmen",
          "Spis noget tørt (knækbrød) før du rejser dig om morgenen"
        ],
        needsAttention: false,
        empathicResponse: `Det er hårdt at have kvalme, kære ${userContext.motherName}. Husk at det er et tegn på at din krop tager godt vare om ${userContext.babyName}. Du klarer det fantastisk! 💚`
      };
    }

    if (symptomLower.includes('træt') || symptomLower.includes('udmattet')) {
      const energyPattern = recentData?.map(d => d.energy).slice(-3) || [];
      const averageEnergy = energyPattern.length > 0 ? energyPattern.reduce((a, b) => a + b, 0) / energyPattern.length : 5;
      
      return {
        symptom,
        context,
        explanation: isEarlyPregnancy
          ? "Træthed i starten af graviditeten er helt normalt - din krop bruger meget energi på at bygge en lille menneskelig!"
          : isThirdTrimester
          ? `I det sidste stykke tid er det naturligt at føle sig træt. ${userContext.babyName} vokser hurtigt og du bærer mere vægt.`
          : "Din krop arbejder konstant på at støtte babys vækst, så træthed er helt forventeligt.",
        suggestions: averageEnergy < 4 ? [
          "Prioriter hvile - tag en lur hvis muligt",
          "Bed om hjælp til husarbejde",
          "Spis jernrige fødevarer (spinat, bønner, magert kød)",
          "Tag dine vitaminer - især jern og B12"
        ] : [
          "Lyt til din krop og hvil når du kan",
          "Let motion som gåture kan faktisk give mere energi",
          "Sørg for at få nok protein og komplekse kulhydrater"
        ],
        needsAttention: averageEnergy < 3,
        empathicResponse: `Du gør et kæmpe arbejde, ${userContext.motherName}. Det er okay at være træt - din krop skaber jo liv! 🌟`
      };
    }

    if (symptomLower.includes('ryg') || symptomLower.includes('lænd')) {
      return {
        symptom,
        context,
        explanation: isThirdTrimester
          ? `Rygsmerter er meget almindelige nu hvor ${userContext.babyName} vokser og ændrer din tyngdepunkt.`
          : "Løsnede ledbånd og ændret kropsholdning kan give rygsmerter under graviditet.",
        suggestions: [
          "Brug en støttebælte under maven hvis det hjælper",
          "Sov med en pude mellem benene",
          "Undgå høje hæle - brug støttende sko",
          "Prøv graviditetsyoga eller svømning",
          "Varm bad eller varmepose kan lindre"
        ],
        needsAttention: false,
        empathicResponse: "Rygsmerter kan virkelig være ubehagelige. Du bærer dit lille mirakel med stolthed! 💪"
      };
    }

    if (symptomLower.includes('humør') || symptomLower.includes('trist') || symptomLower.includes('græd')) {
      const moodPattern = recentData?.map(d => d.mood).slice(-5) || [];
      const averageMood = moodPattern.length > 0 ? moodPattern.reduce((a, b) => a + b, 0) / moodPattern.length : 5;
      
      return {
        symptom,
        context,
        explanation: "Hormonelle ændringer påvirker dit humør - det er helt normalt og forståeligt.",
        suggestions: [
          "Tal med din partner eller en ven om dine følelser",
          "Hold fast i rutiner der gør dig glad",
          "Få frisk luft og naturligt lys hver dag",
          "Prioriter god søvn - det påvirker humøret meget"
        ],
        needsAttention: averageMood < 4,
        empathicResponse: `Dine følelser er valid, kære ${userContext.motherName}. Det er okay at have op- og nedture. Du er ikke alene i dette. 🤗`
      };
    }

    // Default response for unknown symptoms
    return {
      symptom,
      context,
      explanation: "Det er vigtigt at lytte til din krop og notere ændringer.",
      suggestions: [
        "Hold øje med symptomet og noter om det ændrer sig",
        "Kontakt din jordemoder hvis du er bekymret",
        "Husk at din krop går gennem store forandringer"
      ],
      needsAttention: false,
      empathicResponse: `Tak fordi du deler dine oplevelser, ${userContext.motherName}. Du kender din krop bedst. 💜`
    };
  }

  static generatePersonalizedDevelopmentText(week: number, userContext: UserContext): string {
    const { babyName, babyGender, isPostpartum } = userContext;
    const pronounHan = babyGender === 'dreng' ? 'han' : 'hun';
    const pronounHam = babyGender === 'dreng' ? 'ham' : 'hende';
    const pronounSin = babyGender === 'dreng' ? 'sin' : 'sin';

    if (isPostpartum) {
      if (week <= 2) {
        return `${babyName} tilpasser sig livet udenfor livmoderen. ${pronounHan} lærer at regulere ${pronounSin} kropstemperatur og udvikler ${pronounSin} første søvnmønstre. Det er en stor overgang for jer begge.`;
      } else if (week <= 6) {
        return `${babyName}s nervesystem modnes hurtigt. ${pronounHan} begynder at fokusere øjnene og kan følge ansigter. Måske ser du ${pronounSin} første rigtige smil snart!`;
      } else {
        return `${babyName} bliver mere vågen og interesseret i verden. ${pronounHan} begynder at holde hovedet oppe i korte perioder og reagerer på din stemme med større opmærksomhed.`;
      }
    }

    // Personalized development texts for pregnancy weeks
    if (week <= 8) {
      return `${babyName}s hjerte banker nu! Små arme og ben begynder at forme sig. ${pronounHan} er stadig meget lille, men alle de vigtigste organer er ved at udvikle sig.`;
    } else if (week <= 12) {
      return `${babyName} bevæger sig nu, selvom du ikke kan mærke det endnu. ${pronounSin} fingre og tæer bliver mere tydelige, og ansigtstræk begynder at tage form.`;
    } else if (week <= 16) {
      return `${babyName}s knogler bliver stærkere, og ${pronounHan} kan måske begynde at sutte tommelfinger. Det køn ${pronounHan} skal have begynder at blive synligt.`;
    } else if (week <= 20) {
      return `Du kan måske snart mærke ${babyName}s bevægelser! ${pronounHan} udvikler ${pronounSin} hørelsessans og kan høre din stemme og dit hjerteslag.`;
    } else if (week <= 24) {
      return `${babyName}s hjerne vokser hurtigt nu. ${pronounHan} reagerer på lyde og lys, og du kan mærke ${pronounHam} reagere når du taler eller der er høje lyde.`;
    } else if (week <= 28) {
      return `${babyName}s øjne åbner sig nu! ${pronounHan} har regelmæssige søvn- og vågenperioder, og du kan mærke forskel på hvornår ${pronounHan} er aktiv.`;
    } else if (week <= 32) {
      return `${babyName} tager hurtigt på i vægt nu. ${pronounSin} lunger udvikles, så ${pronounHan} forbereder sig på at trække vejret på egen hånd.`;
    } else if (week <= 36) {
      return `${babyName} er ved at blive klar til fødslen. ${pronounHan} øver sig på at trække vejret og suge, og ${pronounSin} knogler bliver stærkere.`;
    } else {
      return `${babyName} er nu fuldt udviklet og klar til at møde dig! ${pronounHan} venter bare på det rette øjeblik til at komme ud og hilse på sine forældre.`;
    }
  }

  static generateCombinedInsight(motherData: DailyData[], userContext: UserContext): CombinedInsight | null {
    if (motherData.length < 3) return null;

    const recentData = motherData.slice(-5);
    const avgMood = recentData.reduce((sum, d) => sum + d.mood, 0) / recentData.length;
    const avgEnergy = recentData.reduce((sum, d) => sum + d.energy, 0) / recentData.length;
    const avgSleep = recentData.reduce((sum, d) => sum + d.sleep, 0) / recentData.length;

    // Pattern detection
    if (avgSleep < 6 && avgEnergy < 5) {
      return {
        pattern: "Søvn og energi sammenhæng",
        observation: `De sidste dage har du sovet under 6 timer i gennemsnit, og dit energiniveau har været lavt.`,
        suggestion: "Prøv at prioritere tidligere sengetid og lav en afslappende rutine før sengetid.",
        empathicMessage: `God søvn er så vigtig for dig og ${userContext.babyName}, kære ${userContext.motherName}. Du fortjener hvile! 🌙`
      };
    }

    if (avgMood < 5 && recentData.some(d => d.symptoms.some(s => s.includes('humør') || s.includes('trist')))) {
      return {
        pattern: "Humør og wellbeing",
        observation: "Jeg kan se at dit humør har været presset de sidste dage.",
        suggestion: "Overvej at tale med en ven eller din partner om dine følelser. Små ting som frisk luft kan også hjælpe.",
        empathicMessage: `Det er okay at have svære dage. Du gør det så godt, og du er ikke alene i dette. 💕`
      };
    }

    return null;
  }

  static generateMicroNotification(userContext: UserContext): string {
    const { motherName, babyName, isPostpartum } = userContext;
    const week = this.calculatePregnancyWeek(userContext.expectedDate, isPostpartum);
    
    const notifications = [
      `Husk at trække vejret dybt, ${motherName}. Du gør det fantastisk! 🌸`,
      `${babyName} kan høre din stemme - tal gerne til ${isPostpartum ? 'ham/hende' : 'din mave'}. 💛`,
      `Tag et øjeblik til dig selv i dag. Du fortjener omsorg. ✨`,
      `Din krop laver mirakler. Vær stolt af hvad du opnår hver dag! 🌟`,
      `Små skridt er stadig fremgang. Du klarer det perfekt. 💚`,
      isPostpartum 
        ? `${babyName} lærer hver dag fra dig. Du er den perfekte mor! 👶`
        : `Hver dag vokser ${babyName} stærkere indeni dig. Hvilket mirakel! 🌱`
    ];

    // Week-specific notifications
    if (!isPostpartum) {
      if (week <= 12) {
        notifications.push(`I første trimester sker der så meget! ${babyName}s hjerte banker nu for jer begge. 💗`);
      } else if (week <= 27) {
        notifications.push(`${babyName} bliver mere aktiv nu. Mærk efter små bevægelser! 🦋`);
      } else {
        notifications.push(`${babyName} forbereder sig på at møde dig. I er så tæt på! 🌈`);
      }
    }

    return notifications[Math.floor(Math.random() * notifications.length)];
  }

  static generateWeeklyMessage(currentWeek: number, userContext: UserContext): string {
    const empathicMessages = [
      "Du gør det fantastisk, og baby har det godt ❤️",
      "Din krop og baby udvikler sig perfekt sammen",
      "Hver dag er du et skridt tættere på at møde din lille",
      "Din kærlighed vokser sammen med din baby",
      "Du sørger så godt for jer begge",
      "Baby kan mærke din omsorg og kærlighed"
    ];

    const weekSpecific = {
      12: "Du har nået et vigtigt milepæl - tillykke! ✨",
      20: "Halvvejs! Du gør det utroligt godt 🌟",
      28: "Tredje trimester begynder - du er næsten der!",
      36: "Baby er næsten klar til at møde dig ❤️",
      40: "Hvilken som helst dag nu - du er så stærk! 🌸"
    };

    if (weekSpecific[currentWeek]) {
      return weekSpecific[currentWeek];
    }

    return empathicMessages[currentWeek % empathicMessages.length];
  }

  static generateDiarySummary(data: DailyData[], userContext: UserContext): string {
    if (data.length === 0) return "";

    const recentDays = Math.min(3, data.length);
    const recentData = data.slice(-recentDays);
    
    const avgMood = recentData.reduce((sum, d) => sum + d.mood, 0) / recentData.length;
    const avgEnergy = recentData.reduce((sum, d) => sum + d.energy, 0) / recentData.length;
    const avgSleep = recentData.reduce((sum, d) => sum + d.sleep, 0) / recentData.length;

    const commonSymptoms = recentData
      .flatMap(d => d.symptoms)
      .reduce((acc, symptom) => {
        acc[symptom] = (acc[symptom] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

    const mostCommonSymptom = Object.entries(commonSymptoms)
      .sort(([,a], [,b]) => b - a)[0]?.[0];

    let summary = `De sidste ${recentDays} dage har `;
    
    if (avgMood >= 7) {
      summary += "dit humør været godt, ";
    } else if (avgMood >= 5) {
      summary += "dit humør været okay, ";
    } else {
      summary += "dit humør været udfordret, ";
    }

    if (avgEnergy >= 7) {
      summary += "og du har haft god energi.";
    } else if (avgEnergy >= 5) {
      summary += "og dit energiniveau har været moderat.";
    } else {
      summary += "og du har følt dig træt.";
    }

    if (avgSleep < 6) {
      summary += ` Du har sovet under 6 timer i gennemsnit - husk at prioritere hvile, ${userContext.motherName}.`;
    }

    if (mostCommonSymptom) {
      summary += ` Det mest almindelige symptom har været: ${mostCommonSymptom.toLowerCase()}.`;
    }

    return summary;
  }
}