import React, { useState, useEffect } from "react";
import OnboardingWelcome from "@/components/OnboardingWelcome";
import OnboardingFlow from "@/components/onboarding/OnboardingFlow";
import LoginPage from "@/components/auth/LoginPage";
import { AuthProvider } from "@/components/auth/AuthProvider";
import { useOptimizedAuth } from "@/hooks/useOptimizedAuth";
import { useSupabaseData } from "@/hooks/useSupabaseData";
import Dashboard from "@/components/Dashboard";
import DailyTracking from "@/components/DailyTracking";
import AIChat from "@/components/AIChat";
import BabyDevelopment from "@/components/BabyDevelopment";
import BabyDevelopmentDetail from "@/components/BabyDevelopmentDetail";
import Wellbeing from "@/components/Wellbeing";
import Profile from "@/components/Profile";
import OverviewPage from "@/components/OverviewPage";
import BabyTracking from "@/components/BabyTracking";
import Settings from "@/components/Settings";
import DataHistory from "@/components/DataHistory";
import BottomTabNavigation from "@/components/BottomTabNavigation";
import { Heart } from "lucide-react";

interface UserProfile {
  motherName: string;
  expectedDate: string;
  babyName: string;
  babyGender: string;
  isPostpartum: boolean;
  profileImage?: string;
  language?: string;
}

interface TrackingData {
  mood: number;
  energy: number;
  sleep: number;
  symptoms: string[];
  weight: string;
  exercise: string;
  notes: string;
  stress_level: number;
  sleep_quality: number;
  nausea_level: number;
  date?: string;
}

function AppContent() {
  const { user, profile, baby, loading, refreshData } = useOptimizedAuth();
  const { updateProfile } = useSupabaseData();
  const [currentPage, setCurrentPage] = useState<string>("dashboard");
  const [activeTab, setActiveTab] = useState<"dashboard" | "wellbeing" | "profile" | "development" | "insights" | "history" | "settings" | "baby-tracking">("dashboard");
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [onboardingStep, setOnboardingStep] = useState<'welcome' | 'flow' | 'login' | null>(null);
  const [selectedUserType, setSelectedUserType] = useState<'expecting' | 'hasChild' | null>(null);

  // Update user profile when Supabase data changes - this ensures dynamic updates
  useEffect(() => {
    if (user && !loading && profile && baby) {
      // User has completed profile setup
      const updatedProfile = {
        motherName: profile.parent_name || profile.user_name || 'Mor',
        expectedDate: baby.due_date || baby.birth_date || "",
        babyName: baby.baby_name,
        babyGender: baby.gender || "",
        isPostpartum: !baby.is_expecting,
        profileImage: profile.profile_image_url || undefined,
        language: "da"
      };
      setUserProfile(updatedProfile);
      setOnboardingStep(null);
    } else if (!user && !loading) {
      // No user authenticated - show welcome
      setOnboardingStep('welcome');
      setUserProfile(null);
    } else if (user && !loading && (!profile || !baby)) {
      // User authenticated but no profile data - show welcome to complete setup
      setOnboardingStep('welcome');
      setUserProfile(null);
    }
  }, [user, profile, baby, loading]);

  const handleUserChoice = (choice: 'expecting' | 'hasChild') => {
    setSelectedUserType(choice);
    setOnboardingStep('flow');
  };

  const handleLoginRequest = () => {
    setOnboardingStep('login');
  };

  const handleOnboardingComplete = () => {
    setOnboardingStep(null);
    setCurrentPage("dashboard");
  };

  const handleBackToWelcome = () => {
    setOnboardingStep('welcome');
    setSelectedUserType(null);
  };

  const handleProfileUpdate = async (data: UserProfile) => {
    // Update the database profile
    if (user) {
      try {
        await updateProfile({
          user_name: data.motherName,
          parent_name: data.motherName,
          profile_image_url: data.profileImage || null,
        });
        // Refresh the data to update the UI
        await refreshData();
      } catch (error) {
        console.error('Error updating profile in database:', error);
      }
    }
  };

  const handleTrackingSave = (data: TrackingData) => {
    // Data is now handled by Supabase in the DailyTracking component
    // This callback is optional now
  };

  const navigateToPage = (page: string) => {
    setCurrentPage(page);
  };

  const handleTabChange = (tab: "dashboard" | "wellbeing" | "profile" | "development" | "insights" | "history" | "settings" | "baby-tracking") => {
    setActiveTab(tab);
    setCurrentPage(tab);
  };

  // Show loading while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-accent/10 flex items-center justify-center">
        <div className="text-center animate-fade-in">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-primary to-primary-glow flex items-center justify-center shadow-warm animate-pulse">
            <Heart className="w-10 h-10 text-primary-foreground fill-primary-foreground animate-scale-in" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-center space-x-1">
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
            </div>
            <p className="text-muted-foreground font-nunito animate-fade-in" style={{ animationDelay: '500ms' }}>
              Indlæser din profil...
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Show onboarding flow based on current step and user authentication status
  if (onboardingStep === 'login') {
    return <LoginPage onBack={handleBackToWelcome} />;
  }
  
  if (onboardingStep === 'flow' && selectedUserType) {
    return (
      <OnboardingFlow 
        userType={selectedUserType}
        onComplete={handleOnboardingComplete}
        onBack={handleBackToWelcome}
      />
    );
  }
  
  if (onboardingStep === 'welcome') {
    return (
      <OnboardingWelcome 
        onUserChoice={handleUserChoice}
        onLoginRequest={handleLoginRequest}
      />
    );
  }

  // Must have a valid user profile to proceed to the app
  if (!userProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-accent/10 flex items-center justify-center">
        <div className="text-center animate-fade-in">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-primary to-primary-glow flex items-center justify-center shadow-warm">
            <Heart className="w-10 h-10 text-primary-foreground fill-primary-foreground animate-scale-in" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-center space-x-1">
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
            </div>
            <p className="text-muted-foreground font-nunito animate-fade-in" style={{ animationDelay: '500ms' }}>
              Forbereder din profil...
            </p>
            <p className="text-xs text-muted-foreground/70 font-nunito animate-fade-in" style={{ animationDelay: '750ms' }}>
              Dette tager kun et øjeblik
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Main tab pages show bottom navigation
  const isMainTabPage = ["dashboard", "wellbeing", "development", "insights", "settings"].includes(currentPage);

  switch (currentPage) {
    case "dashboard":
      return (
        <div className="pb-20 animate-fade-in">
          <Dashboard userProfile={userProfile} onNavigate={navigateToPage} />
          <BottomTabNavigation activeTab={activeTab} onTabChange={handleTabChange} />
        </div>
      );
    
    case "wellbeing":
      return (
        <div className="pb-20 animate-slide-in-right">
          <DailyTracking 
            onBack={() => handleTabChange("dashboard")} 
            onSave={handleTrackingSave}
          />
          <BottomTabNavigation activeTab={activeTab} onTabChange={handleTabChange} />
        </div>
      );
    
    case "development":
      return (
        <div className="pb-20">
          <BabyDevelopment 
            userProfile={userProfile}
            onBack={() => handleTabChange("dashboard")}
          />
          <BottomTabNavigation activeTab={activeTab} onTabChange={handleTabChange} />
        </div>
      );
    
    case "insights":
      return (
        <div className="pb-20">
          <OverviewPage 
            onBack={() => handleTabChange("dashboard")} 
          />
          <BottomTabNavigation activeTab={activeTab} onTabChange={handleTabChange} />
        </div>
      );
    
    case "history":
      return (
        <div className="pb-20">
          <DataHistory 
            onBack={() => handleTabChange("dashboard")} 
          />
        </div>
      );
    
    case "baby-tracking":
      return (
        <div className="pb-20">
          <BabyTracking 
            onBack={() => handleTabChange("dashboard")} 
          />
        </div>
      );
    
    case "settings":
      return (
        <div className="pb-20">
          <Settings 
            onBack={() => handleTabChange("dashboard")} 
          />
          <BottomTabNavigation activeTab={activeTab} onTabChange={handleTabChange} />
        </div>
      );
    
    case "profile":
      return (
        <div className="pb-20">
          <Profile 
            onBack={() => handleTabChange("dashboard")} 
          />
        </div>
      );
    
    case "daily-tracking":
      return (
        <div className="animate-scale-in">
          <DailyTracking 
            onBack={() => setCurrentPage("dashboard")} 
            onSave={handleTrackingSave}
          />
        </div>
      );
    
    case "chat":
      return (
        <div className="animate-scale-in">
          <AIChat 
            onBack={() => handleTabChange("dashboard")} 
            userProfile={userProfile}
          />
        </div>
      );
    
    case "baby-detail":
      return (
        <div className="animate-fade-in">
          <BabyDevelopmentDetail 
            userProfile={userProfile}
            onBack={() => handleTabChange("dashboard")}
          />
        </div>
      );
    
    default:
      return (
        <div className="pb-20 animate-fade-in">
          <Dashboard userProfile={userProfile} onNavigate={navigateToPage} />
          <BottomTabNavigation activeTab={activeTab} onTabChange={handleTabChange} />
        </div>
      );
  }
}

export default function Index() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}