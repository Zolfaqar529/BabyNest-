import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Calendar, Heart, Activity, Moon } from 'lucide-react';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { format, parseISO } from 'date-fns';

interface DataHistoryProps {
  onBack: () => void;
}

export default function DataHistory({ onBack }: DataHistoryProps) {
  const { dailyEntries, babyLogs, loading } = useSupabaseData();

  const formatDate = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), 'dd/MM/yyyy');
    } catch {
      return dateStr;
    }
  };

  const getMoodEmoji = (mood: number) => {
    if (mood <= 3) return "😔";
    if (mood <= 7) return "😊";
    return "😃";
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-2xl mx-auto space-y-6">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="h-8 w-32 bg-muted animate-pulse rounded"></div>
          </div>
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-muted animate-pulse rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Mine data & historik</h1>
            <p className="text-sm text-muted-foreground">Se dine tidligere logninger</p>
          </div>
        </div>

        {/* Daily Entries */}
        {dailyEntries.length > 0 ? (
          <div className="space-y-4">
            <h2 className="text-base font-medium">Daglige logninger</h2>
            {dailyEntries
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .map((entry) => (
                <Card key={entry.id}>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center text-sm">
                      <Calendar className="w-4 h-4 mr-2 text-primary" />
                      {formatDate(entry.date)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      {entry.mood && (
                        <div className="flex items-center space-x-2">
                          <Heart className="w-4 h-4 text-primary" />
                          <span className="text-sm">Humør: {getMoodEmoji(entry.mood)} ({entry.mood}/10)</span>
                        </div>
                      )}
                      {entry.energy_level && (
                        <div className="flex items-center space-x-2">
                          <Activity className="w-4 h-4 text-success" />
                          <span className="text-sm">Energi: {entry.energy_level}/10</span>
                        </div>
                      )}
                      {entry.sleep && (
                        <div className="flex items-center space-x-2">
                          <Moon className="w-4 h-4 text-accent" />
                          <span className="text-sm">Søvn: {entry.sleep} timer</span>
                        </div>
                      )}
                      {entry.weight && (
                        <div className="text-sm">
                          <span className="font-medium">Vægt:</span> {entry.weight}kg
                        </div>
                      )}
                    </div>
                    
                    {entry.symptoms && entry.symptoms.length > 0 && (
                      <div>
                        <span className="text-sm font-medium">Symptomer: </span>
                        <span className="text-sm text-muted-foreground">
                          {entry.symptoms.join(', ')}
                        </span>
                      </div>
                    )}
                    
                    {entry.exercise && (
                      <div>
                        <span className="text-sm font-medium">Motion: </span>
                        <span className="text-sm text-muted-foreground">{entry.exercise}</span>
                      </div>
                    )}
                    
                    {entry.notes && (
                      <div>
                        <span className="text-sm font-medium">Noter: </span>
                        <span className="text-sm text-muted-foreground">{entry.notes}</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            }
          </div>
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">
                Ingen daglige logninger endnu. Start med at logge dine oplevelser for at se historik.
              </p>
            </CardContent>
          </Card>
        )}

        {/* Baby Logs */}
        {babyLogs.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-base font-medium">Baby logninger</h2>
            {babyLogs
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .map((log) => (
                <Card key={log.id}>
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center text-sm">
                      <Calendar className="w-4 h-4 mr-2 text-accent" />
                      {formatDate(log.date)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-4">
                      {log.sleep_hours && (
                        <div className="text-sm">
                          <span className="font-medium">Søvn:</span> {log.sleep_hours} timer
                        </div>
                      )}
                      {log.feeding_times && (
                        <div className="text-sm">
                          <span className="font-medium">Måltider:</span> {log.feeding_times}
                        </div>
                      )}
                      {log.diaper_changes && (
                        <div className="text-sm">
                          <span className="font-medium">Blesskift:</span> {log.diaper_changes}
                        </div>
                      )}
                      {log.weight_grams && (
                        <div className="text-sm">
                          <span className="font-medium">Vægt:</span> {log.weight_grams}g
                        </div>
                      )}
                    </div>
                    
                    {log.notes && (
                      <div>
                        <span className="text-sm font-medium">Noter: </span>
                        <span className="text-sm text-muted-foreground">{log.notes}</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            }
          </div>
        )}
      </div>
    </div>
  );
}