import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, FileText, FileSpreadsheet, AlertTriangle } from 'lucide-react';

interface DownloadWidgetProps {
  onGenerateReport: () => Promise<void>;
  onExportCSV: () => Promise<void>;
}

export function DownloadWidget({ onGenerateReport, onExportCSV }: DownloadWidgetProps) {
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [isExportingCSV, setIsExportingCSV] = useState(false);

  const handlePDFGeneration = async () => {
    setIsGeneratingPDF(true);
    try {
      await onGenerateReport();
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const handleCSVExport = async () => {
    setIsExportingCSV(true);
    try {
      await onExportCSV();
    } catch (error) {
      console.error('Error exporting CSV:', error);
    } finally {
      setIsExportingCSV(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Download className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">Eksporter data</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {/* PDF Report */}
          <div className="p-4 border rounded-lg">
            <div className="flex items-start space-x-3">
              <FileText className="w-5 h-5 text-primary mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium mb-1">PDF Rapport</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Komplet rapport med grafer, opsummering og kliniske noter
                </p>
                <Button 
                  onClick={handlePDFGeneration}
                  disabled={isGeneratingPDF}
                  className="w-full"
                >
                  {isGeneratingPDF ? 'Genererer...' : 'Download PDF'}
                </Button>
              </div>
            </div>
          </div>

          {/* CSV Export */}
          <div className="p-4 border rounded-lg">
            <div className="flex items-start space-x-3">
              <FileSpreadsheet className="w-5 h-5 text-primary mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium mb-1">CSV Data</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Rådata i CSV-format til videre analyse
                </p>
                <Button 
                  onClick={handleCSVExport}
                  disabled={isExportingCSV}
                  variant="outline"
                  className="w-full"
                >
                  {isExportingCSV ? 'Eksporterer...' : 'Eksporter CSV'}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-yellow-800 font-medium mb-1">
                Vigtig bemærkning
              </p>
              <p className="text-xs text-yellow-700">
                Denne rapport er ikke en erstatning for lægefaglig vurdering. 
                Konsulter altid din læge eller jordemoder ved bekymringer.
              </p>
            </div>
          </div>
        </div>

        {/* Report Info */}
        <div className="text-xs text-muted-foreground space-y-1">
          <p>• PDF-rapporten inkluderer alle grafer og opsummeringer</p>
          <p>• CSV-filen indeholder rådata for videre analyse</p>
          <p>• Rapporter er dateret og indeholder brugerinformation</p>
        </div>
      </CardContent>
    </Card>
  );
} 
