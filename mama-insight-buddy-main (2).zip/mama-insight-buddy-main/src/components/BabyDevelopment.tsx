import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Baby, ChevronLeft, ChevronRight, Brain, Heart, Eye, Dumbbell, Apple, Bed, Smile, Activity, Lightbulb } from "lucide-react";
import { AIService } from "@/lib/aiService";

interface BabyDevelopmentProps {
  userProfile: {
    motherName: string;
    expectedDate: string;
    babyName: string;
    babyGender: string;
    isPostpartum: boolean;
  };
  onBack: () => void;
}

export default function BabyDevelopment({ userProfile, onBack }: BabyDevelopmentProps) {
  const [currentWeek, setCurrentWeek] = useState(0);
  const [daysLeft, setDaysLeft] = useState(0);
  const [weekData, setWeekData] = useState<any>(null);
  const [showSupportTips, setShowSupportTips] = useState(false);
  const [weeklyFeeling, setWeeklyFeeling] = useState("");
  const [showFeelingInput, setShowFeelingInput] = useState(false);

  useEffect(() => {
    const calculatePregnancyData = () => {
      const expectedDate = new Date(userProfile.expectedDate);
      const today = new Date();
      const timeDiff = expectedDate.getTime() - today.getTime();
      const daysRemaining = Math.ceil(timeDiff / (1000 * 3600 * 24));
      
      if (userProfile.isPostpartum) {
        const daysSinceBirth = Math.abs(daysRemaining);
        const weeksSinceBirth = Math.floor(daysSinceBirth / 7);
        setCurrentWeek(weeksSinceBirth);
        setDaysLeft(0);
      } else {
        // Calculate pregnancy weeks from conception (280 days total pregnancy)
        const pregnancyWeeks = Math.max(0, Math.floor((280 - daysRemaining) / 7));
        setCurrentWeek(pregnancyWeeks);
        setDaysLeft(Math.max(0, daysRemaining));
      }
    };

    calculatePregnancyData();
  }, [userProfile]);

  useEffect(() => {
    const loadBabyDevelopment = async () => {
      try {
        const response = await fetch('/src/data/babyDevelopment.json');
        const developmentData = await response.json();
        const data = developmentData[currentWeek.toString()];
        setWeekData(data);
      } catch (error) {
        console.error("Could not load baby development data:", error);
      }
    };

    if (currentWeek >= 0) {
      loadBabyDevelopment();
    }
  }, [currentWeek]);

  const handleWeekChange = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && currentWeek > 1) {
      setCurrentWeek(currentWeek - 1);
    } else if (direction === 'next' && currentWeek < 42) {
      setCurrentWeek(currentWeek + 1);
    }
    // Force reload of week data
    setWeekData(null);
  };

  const handleSaveFeeling = () => {
    if (weeklyFeeling.trim()) {
      localStorage.setItem(`weekly_feeling_${currentWeek}`, JSON.stringify({
        week: currentWeek,
        feeling: weeklyFeeling,
        date: new Date().toISOString(),
        userProfile: userProfile.motherName
      }));
      setWeeklyFeeling("");
      setShowFeelingInput(false);
    }
  };

  const getDevelopmentIconData = () => {
    const baseData = [
      { icon: Brain, label: "Hjerne", progress: Math.min(100, (currentWeek / 36) * 100) },
      { icon: Heart, label: "Hjerte", progress: Math.min(100, (currentWeek / 8) * 100) },
      { icon: Eye, label: "Sanser", progress: Math.min(100, (currentWeek / 28) * 100) },
    ];

    if (currentWeek >= 16) {
      baseData.push({ icon: Baby, label: "Vægt", progress: Math.min(100, ((currentWeek - 16) / 24) * 100) });
    }

    return baseData;
  };

  const getProgressPercentage = () => {
    if (userProfile.isPostpartum) return 100;
    return Math.min(100, (currentWeek / 40) * 100);
  };

  const getFruitSize = () => {
    if (weekData?.size) return weekData.size;
    
    // Fallback fruit sizes
    const fruitSizes = [
      "frø", "frø", "sesam", "blåbær", "ærtebælle", "linse", "blåbær",
      "hindbær", "kirsebær", "jordgulvet", "dadel", "lime", "fersken",
      "citron", "nektarin", "avocado", "løg", "paprika", "banan", 
      "grapefrugt", "broccoli", "aubergine", "majskolbe", "blomkål",
      "agurk", "rød kål", "honningdynte", "cocos", "græskar", "ananas",
      "savoy kål", "butternut squash", "honningmelon", "cantaloupe melon",
      "romaine salat", "schweizer kål", "vandmelon", "babymelon", "græskar", "vandmelon"
    ];
    
    return fruitSizes[currentWeek] || "frugt";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-primary-glow/10 p-4 pb-20">
      <div className="max-w-sm mx-auto space-y-4">
        
        {/* Header - Simple Baby Info */}
        <div className="bg-gradient-to-br from-primary to-primary-glow text-white rounded-2xl p-4 relative overflow-hidden">
          {/* Back button and title */}
          <div className="flex items-center justify-between mb-3">
            <Button variant="ghost" size="sm" onClick={onBack} className="text-white/80 hover:text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-base font-medium">Baby Udvikling</h1>
            <div className="w-8" /> {/* Spacer */}
          </div>

          {/* Simple Baby Display */}
          <div className="text-center">
            <div className="text-lg font-semibold text-white mb-1">
              {userProfile.isPostpartum ? 'Mor til' : 'Gravid med'} {userProfile.babyName} 👶
            </div>
            <div className="text-sm text-white/90 mb-3">
              Uge {currentWeek}
            </div>
            
            {/* Progress Bar Only */}
            {!userProfile.isPostpartum && (
              <div>
                <div className="w-full bg-white/20 rounded-full h-2 mb-2">
                  <div 
                    className="bg-white rounded-full h-2 transition-all duration-300" 
                    style={{ width: `${getProgressPercentage()}%` }}
                  />
                </div>
                <div className="text-xs text-white/70">
                  {Math.round(getProgressPercentage())}% gennemført • {daysLeft} dage tilbage
                </div>
              </div>
            )}
          </div>
        </div>
        {/* Week Navigation */}
        <div className="flex items-center justify-between mb-4">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handleWeekChange('prev')}
            disabled={currentWeek <= 4}
          >
            <ChevronLeft className="w-4 h-4 mr-1" />
            Forrige
          </Button>
          
          <div className="text-center">
            <h2 className="text-base font-bold">Uge {currentWeek}</h2>
            <p className="text-xs text-muted-foreground">{Math.round(getProgressPercentage())}% gennemført</p>
          </div>
          
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handleWeekChange('next')}
            disabled={currentWeek >= 42}
          >
            Næste
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>

        {/* Ugentlig udvikling - Focus on content */}
        <Card>
          <CardContent className="p-4">
            <div className="text-center space-y-4">
              {/* Size comparison - Clear and prominent */}
              <div className="bg-gradient-to-br from-primary/10 to-primary-glow/20 rounded-2xl p-4 border border-primary/20">
                <div className="text-xs text-muted-foreground uppercase tracking-wide mb-2">
                  {userProfile.babyName} er nu på størrelse med
                </div>
                <div className="text-2xl font-bold text-foreground capitalize mb-4">
                  {getFruitSize()}
                </div>
                
                {/* Development text */}
                <div className="text-sm text-muted-foreground">
                  {AIService.generatePersonalizedDevelopmentText(currentWeek, userProfile)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Development Icons */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-base">
              <Brain className="w-4 h-4 mr-2 text-primary" />
              Nøgleudviklingstrin
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {getDevelopmentIconData().map((item, index) => (
                <div key={index} className="text-center p-3 rounded-lg bg-muted/30">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <h4 className="font-medium text-xs mb-1">{item.label}</h4>
                  <div className="w-full bg-muted rounded-full h-1 mb-1">
                    <div 
                      className="bg-primary rounded-full h-1 transition-all duration-300" 
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground">{Math.round(item.progress)}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Support Tips */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center text-sm">
                <Lightbulb className="w-4 h-4 mr-2 text-warning" />
                Støtte udviklingen
              </CardTitle>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowSupportTips(!showSupportTips)}
                className="text-xs px-2 py-1"
              >
                {showSupportTips ? 'Skjul' : 'Vis'}
              </Button>
            </div>
          </CardHeader>
          
          {showSupportTips && (
            <CardContent>
              <div className="grid grid-cols-1 gap-3">
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-3">
                    <Apple className="w-5 h-5 text-green-600" />
                    <h4 className="font-medium text-green-800">Kost</h4>
                  </div>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• Spis proteinrige fødevarer</li>
                    <li>• Få tilstrækkelig folsyre</li>
                    <li>• Vælg fuldkorn og grøntsager</li>
                  </ul>
                </div>
                
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-3">
                    <Dumbbell className="w-5 h-5 text-blue-600" />
                    <h4 className="font-medium text-blue-800">Motion</h4>
                  </div>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Gåture 20-30 minutter</li>
                    <li>• Svømning er skånsomt</li>
                    <li>• Graviditetsyoga</li>
                  </ul>
                </div>
                
                <div className="p-3 bg-purple-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-3">
                    <Bed className="w-5 h-5 text-purple-600" />
                    <h4 className="font-medium text-purple-800">Hvile</h4>
                  </div>
                  <ul className="text-sm text-purple-700 space-y-1">
                    <li>• 7-9 timers søvn</li>
                    <li>• Brug ekstra puder</li>
                    <li>• Tag pauser i løbet af dagen</li>
                  </ul>
                </div>
                
                <div className="p-3 bg-pink-50 rounded-lg">
                  <div className="flex items-center space-x-2 mb-3">
                    <Smile className="w-5 h-5 text-pink-600" />
                    <h4 className="font-medium text-pink-800">Velvære</h4>
                  </div>
                  <ul className="text-sm text-pink-700 space-y-1">
                    <li>• Mindfulness øvelser</li>
                    <li>• Reducer stress</li>
                    <li>• Tal med andre gravide</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          )}
        </Card>

        {/* Weekly Feeling */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-sm">
              <Heart className="w-4 h-4 mr-2 text-accent" />
              Ugentligt notat
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!showFeelingInput ? (
              <Button 
                onClick={() => setShowFeelingInput(true)}
                className="w-full"
              >
                Tilføj ugentligt notat
              </Button>
            ) : (
              <div className="space-y-3">
                <Textarea
                  placeholder="Fortæl om dine følelser, oplevelser eller bekymringer denne uge..."
                  value={weeklyFeeling}
                  onChange={(e) => setWeeklyFeeling(e.target.value)}
                  rows={3}
                />
                <div className="flex space-x-2">
                  <Button onClick={handleSaveFeeling} className="flex-1">
                    Gem notat
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setShowFeelingInput(false);
                      setWeeklyFeeling("");
                    }}
                  >
                    Annuller
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}