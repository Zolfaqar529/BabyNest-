import { useState, useEffect } from "react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import WelcomeModal from "./WelcomeModal";
import WeekInfoWidget from "./WeekInfoWidget";
import DailyReminderWidget from "./DailyReminderWidget";
import TodayWidget from "./TodayWidget";
import QuickActionsWidget from "./QuickActionsWidget";
import DevelopmentHealthWidget from "./DevelopmentHealthWidget";
import { useSupabaseData } from "@/hooks/useSupabaseData";
import { useOptimizedAuth } from "@/hooks/useOptimizedAuth";
import { calculatePregnancyInfo } from "@/utils/pregnancyCalculations";
import { 
  Heart, 
  Baby,
  Calendar, 
  TrendingUp, 
  MessageCircle,
  Plus,
  Scale,
  Moon,
  Activity,
  User
} from "lucide-react";

interface DashboardProps {
  userProfile: {
    motherName: string;
    expectedDate: string;
    babyName: string;
    babyGender: string;
    isPostpartum: boolean;
    profileImage?: string;
    language?: string;
  };
  onNavigate: (page: string) => void;
}

export default function Dashboard({ userProfile, onNavigate }: DashboardProps) {
  const { getTodayEntry, dailyEntries } = useSupabaseData();
  const { user, hasShownWelcome, markWelcomeShown } = useOptimizedAuth();
  const [pregnancyInfo, setPregnancyInfo] = useState({
    currentWeek: 0,
    daysLeft: 0,
    babySize: "",
    isPostpartum: false
  });
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const [modalShownThisSession, setModalShownThisSession] = useState(false);

  // Calculate pregnancy info
  useEffect(() => {
    if (userProfile.expectedDate) {
      const info = calculatePregnancyInfo(userProfile.expectedDate, userProfile.isPostpartum);
      setPregnancyInfo(info);
    }
  }, [userProfile]);

  // Show welcome modal for new users (only once per session)
  useEffect(() => {
    // Tjek direkte i localStorage for at sikre welcome ikke er vist før
    if (user && userProfile.motherName && !modalShownThisSession) {
      const welcomeKey = `babynest_welcome_shown_${user.id}`;
      const hasShownBefore = localStorage.getItem(welcomeKey) === 'true';
      
      if (!hasShownBefore) {
        console.log('Showing welcome modal for NEW user:', user.id);
        setShowWelcomeModal(true);
        setModalShownThisSession(true);
      } else {
        console.log('User has seen welcome before, skipping:', user.id);
        setModalShownThisSession(true);
      }
    }
  }, [user, userProfile.motherName, modalShownThisSession]);

  const handleWelcomeModalClose = () => {
    if (user) {
      const welcomeKey = `babynest_welcome_shown_${user.id}`;
      localStorage.setItem(welcomeKey, 'true');
      console.log('Welcome modal closed and marked as shown for user:', user.id);
    }
    setShowWelcomeModal(false);
  };

  // Load baby development data (deferred for performance)
  useEffect(() => {
    const loadBabyDevelopment = async () => {
      // Defer this to not block initial render
      setTimeout(async () => {
        try {
          const response = await fetch('/src/data/babyDevelopment.json');
          const developmentData = await response.json();
          const weekData = developmentData[pregnancyInfo.currentWeek.toString()];
          
          if (weekData && weekData.size !== pregnancyInfo.babySize) {
            setPregnancyInfo(prev => ({ ...prev, babySize: weekData.size }));
          }
        } catch (error) {
          console.error("Could not load baby development data:", error);
        }
      }, 100);
    };

    if (pregnancyInfo.currentWeek >= 0) {
      loadBabyDevelopment();
    }
  }, [pregnancyInfo.currentWeek, pregnancyInfo.babySize]);

  const [todayStats, setTodayStats] = useState([
    { label: "Humør", value: "−", icon: Heart },
    { label: "Søvn", value: "−", icon: Moon },
    { label: "Aktivitet", value: "−", icon: Activity },
    { label: "Vægt", value: "−", icon: Scale }
  ]);

  // Load today's tracking data
  useEffect(() => {
    const todayEntry = getTodayEntry();
    
    if (todayEntry) {
      const getMoodEmoji = (mood: number) => {
        if (mood <= 3) return "😔";
        if (mood <= 7) return "😊";
        return "😃";
      };

      setTodayStats([
        { label: "Humør", value: getMoodEmoji(todayEntry.mood || 5), icon: Heart },
        { label: "Søvn", value: `${todayEntry.sleep || 0}t`, icon: Moon },
        { label: "Aktivitet", value: todayEntry.exercise || "−", icon: Activity },
        { label: "Vægt", value: todayEntry.weight ? `${todayEntry.weight}kg` : "−", icon: Scale }
      ]);
    }
  }, [dailyEntries]);

  const hasLoggedToday = !!getTodayEntry();
  const todayEntry = getTodayEntry();
  const hasLoggedMood = todayEntry?.mood !== undefined;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/10 to-accent/5 p-4 pb-20 text-nordic">
      <div className="max-w-sm mx-auto space-nordic-y">
        {/* Header Section */}
        <div className="pt-2 space-y-4">
          {/* Date */}
          <p className="text-sm text-muted-foreground font-normal">
            {new Date().toLocaleDateString('da-DK', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </p>

          {/* Greeting */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-medium text-foreground leading-tight">
                {new Date().getHours() < 12 ? "God morgen, " : 
                 new Date().getHours() < 17 ? "God dag, " : "God aften, "}
                {userProfile.motherName || "Mor"}
              </h1>
            </div>
            <Avatar 
              className="w-12 h-12 cursor-pointer ring-2 ring-border/30 hover:ring-primary/30 transition-all duration-300"
              onClick={() => onNavigate("profile")}
            >
              <AvatarImage src={userProfile.profileImage} alt="Profilbillede" />
              <AvatarFallback className="bg-primary/5 text-sm font-medium text-primary">
                {userProfile.motherName ? userProfile.motherName.charAt(0).toUpperCase() : <User className="w-5 h-5" />}
              </AvatarFallback>
            </Avatar>
          </div>
        </div>

        {/* Week Info */}
        <WeekInfoWidget 
          currentWeek={pregnancyInfo.currentWeek}
          babySize={pregnancyInfo.babySize}
          isPostpartum={pregnancyInfo.isPostpartum}
        />


        {/* Quick Actions */}
        <QuickActionsWidget onNavigate={onNavigate} />

        {/* Combined Development & Health Goals */}
        <DevelopmentHealthWidget
          userProfile={userProfile}
          currentWeek={pregnancyInfo.currentWeek}
          daysLeft={pregnancyInfo.daysLeft}
          babySize={pregnancyInfo.babySize}
          todayEntry={todayEntry}
          onNavigate={onNavigate}
        />

        {/* Today Stats */}
        <TodayWidget 
          todayStats={todayStats}
          onNavigateToTracking={() => onNavigate("daily-tracking")}
        />

        {/* Bottom 4 Widgets Grid */}
        <div className="grid grid-cols-2 gap-3">
          {/* AI Rådgiver */}
          <div 
            className="nordic-card cursor-pointer transition-all duration-300 hover:shadow-sm hover:scale-[1.01] border-0"
            onClick={() => onNavigate("chat")}
          >
            <div className="p-4 flex flex-col items-center text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xs font-medium text-foreground">AI Rådgiver</h3>
            </div>
          </div>

          {/* Baby udvikling */}
          <div 
            className="nordic-card cursor-pointer transition-all duration-300 hover:shadow-sm hover:scale-[1.01] border-0"
            onClick={() => onNavigate("development")}
          >
            <div className="p-4 flex flex-col items-center text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-success/10 flex items-center justify-center">
                <Baby className="w-6 h-6 text-success-foreground" />
              </div>
              <h3 className="text-xs font-medium text-foreground">Baby udvikling</h3>
            </div>
          </div>

          {/* Mine data */}
          <div 
            className="nordic-card cursor-pointer transition-all duration-300 hover:shadow-sm hover:scale-[1.01] border-0"
            onClick={() => onNavigate("insights")}
          >
            <div className="p-4 flex flex-col items-center text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-accent-foreground" />
              </div>
              <h3 className="text-xs font-medium text-foreground">Mine data</h3>
            </div>
          </div>

          {/* Velbefinden */}
          <div 
            className="nordic-card cursor-pointer transition-all duration-300 hover:shadow-sm hover:scale-[1.01] border-0"
            onClick={() => onNavigate("wellbeing")}
          >
            <div className="p-4 flex flex-col items-center text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center">
                <Heart className="w-6 h-6 text-secondary-foreground" />
              </div>
              <h3 className="text-xs font-medium text-foreground">Velbefinden</h3>
            </div>
          </div>
        </div>
      </div>

      {/* Welcome Modal */}
      <WelcomeModal 
        isOpen={showWelcomeModal}
        onClose={handleWelcomeModalClose}
        userName={userProfile.motherName}
      />
    </div>
  );
}