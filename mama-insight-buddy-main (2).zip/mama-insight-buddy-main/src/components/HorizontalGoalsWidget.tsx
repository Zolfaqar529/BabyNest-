import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface HorizontalGoalsWidgetProps {
  todayEntry: any;
  onNavigate: (page: string) => void;
}

export default function HorizontalGoalsWidget({ todayEntry, onNavigate }: HorizontalGoalsWidgetProps) {
  const goals = [
    { 
      label: "Humør", 
      completed: todayEntry?.mood !== undefined,
      emoji: "😊"
    },
    { 
      label: "Søvn", 
      completed: todayEntry?.sleep !== undefined,
      emoji: "💤"
    },
    { 
      label: "Symptomer", 
      completed: todayEntry?.symptoms && todayEntry.symptoms.length > 0,
      emoji: "📝"
    },
    { 
      label: "Motion", 
      completed: todayEntry?.exercise !== undefined,
      emoji: "🏃‍♀️"
    }
  ];

  const completedCount = goals.filter(goal => goal.completed).length;

  return (
    <Card className="nordic-card border-0">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-medium text-foreground">Dagens mål</h2>
          <span className="text-sm text-muted-foreground">
            {completedCount}/{goals.length}
          </span>
        </div>

        <div className="flex flex-wrap gap-2 mb-6">
          {goals.map((goal, index) => (
            <Badge
              key={index}
              variant={goal.completed ? "default" : "outline"}
              className={`px-3 py-2 rounded-full text-sm font-normal transition-all duration-200 ${
                goal.completed 
                  ? "bg-primary/10 text-primary border-primary/20" 
                  : "bg-muted/30 text-muted-foreground border-muted/40"
              }`}
            >
              <span className="mr-2">{goal.emoji}</span>
              {goal.label}
            </Badge>
          ))}
        </div>

        <Button
          variant="ghost"
          onClick={() => onNavigate("development")}
          className="text-sm text-muted-foreground hover:text-foreground transition-colors p-0 h-auto font-normal"
        >
          Se udvikling
          <ArrowRight className="w-3 h-3 ml-1" />
        </Button>
      </CardContent>
    </Card>
  );
}