import { MessageWidget } from "@/components/ui/message-widget";

interface WeekInfoWidgetProps {
  currentWeek: number;
  babySize: string;
  isPostpartum: boolean;
}

export default function WeekInfoWidget({ currentWeek, babySize, isPostpartum }: WeekInfoWidgetProps) {
  const message = isPostpartum 
    ? `Du er i uge ${currentWeek} efter fødslen`
    : `Du er i uge ${currentWeek} – din baby er cirka på størrelse med ${babySize}`;

  return (
    <MessageWidget 
      type="info"
      message={message}
      className="mb-4"
    />
  );
}