import { Home, Heart, User, Baby, BarChart3, History, Settings } from "lucide-react";

interface BottomTabNavigationProps {
  activeTab: "dashboard" | "wellbeing" | "profile" | "development" | "insights" | "history" | "settings" | "baby-tracking";
  onTabChange: (tab: "dashboard" | "wellbeing" | "profile" | "development" | "insights" | "history" | "settings" | "baby-tracking") => void;
}

export default function BottomTabNavigation({ activeTab, onTabChange }: BottomTabNavigationProps) {
  const tabs = [
    { id: "dashboard", icon: Home, label: "Hjem" },
    { id: "wellbeing", icon: Heart, label: "Tracking" },
    { id: "development", icon: Baby, label: "Baby" },
    { id: "insights", icon: BarChart3, label: "Overblik" },
    { id: "settings", icon: Settings, label: "Indstillinger" }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background/98 backdrop-blur-xl border-t border-border/10 px-3 py-2 shadow-soft rounded-t-2xl">
      <div className="max-w-sm mx-auto flex justify-around items-end">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id as any)}
              className={`flex flex-col items-center justify-center transition-all duration-300 ease-out ${
                isActive
                  ? "transform scale-110" 
                  : "hover:scale-105"
              }`}
            >
              <div className={`relative flex items-center justify-center rounded-xl transition-all duration-300 ${
                isActive 
                  ? "w-12 h-12 bg-primary/10 shadow-[0_0_15px_rgba(var(--primary),0.3)]" 
                  : "w-10 h-10 hover:bg-muted/50"
              }`}>
                <Icon className={`transition-all duration-300 ${
                  isActive 
                    ? "w-6 h-6 text-primary" 
                    : "w-5 h-5 text-muted-foreground hover:text-foreground"
                }`} />
                {isActive && (
                  <div className="absolute inset-0 rounded-xl bg-gradient-to-b from-primary/5 to-primary/10 animate-gentle-pulse" />
                )}
              </div>
              <span className={`text-xs font-medium mt-1 transition-all duration-300 ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
