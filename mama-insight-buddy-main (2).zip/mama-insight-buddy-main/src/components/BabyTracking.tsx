import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { 
  ArrowLeft, 
  Baby, 
  Clock, 
  Utensils, 
  Scale, 
  Ruler,
  Heart,
  Save
} from 'lucide-react';
import { AnimatedButton } from '@/components/ui/animated-button';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { useToast } from '@/hooks/use-toast';

interface BabyTrackingProps {
  onBack: () => void;
}

export default function BabyTracking({ onBack }: BabyTrackingProps) {
  const { saveBabyLog, getTodayBabyLog, baby } = useSupabaseData();
  const { toast } = useToast();
  
  const todayLog = getTodayBabyLog();
  const today = new Date().toISOString().split('T')[0];

  const [formData, setFormData] = useState({
    sleep_hours: todayLog?.sleep_hours || 0,
    sleep_quality: todayLog?.sleep_quality || 5,
    feeding_times: todayLog?.feeding_times || 0,
    feeding_notes: todayLog?.feeding_notes || '',
    diaper_changes: todayLog?.diaper_changes || 0,
    weight_grams: todayLog?.weight_grams || 0,
    length_cm: todayLog?.length_cm || 0,
    notes: todayLog?.notes || '',
    mood_rating: todayLog?.mood_rating || 5,
    development_notes: todayLog?.development_notes || ''
  });

  

  const handleSave = async () => {
    await saveBabyLog({
      date: today,
      ...formData
    });
  };

  const updateField = (field: keyof typeof formData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Baby tracking</h1>
            <p className="text-sm text-muted-foreground">
              Log {baby?.baby_name || 'babyens'} udvikling i dag
            </p>
          </div>
        </div>

        {/* Sleep Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Clock className="w-4 h-4 mr-2 text-primary" />
              Søvn
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="sleep_hours">Antal timer søvn</Label>
              <Input
                id="sleep_hours"
                type="number"
                step="0.5"
                value={formData.sleep_hours}
                onChange={(e) => updateField('sleep_hours', parseFloat(e.target.value) || 0)}
                placeholder="0"
              />
            </div>
            <div>
              <Label>Søvnkvalitet (1-10)</Label>
              <div className="mt-2">
                <Slider
                  value={[formData.sleep_quality]}
                  onValueChange={(value) => updateField('sleep_quality', value[0])}
                  max={10}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>Dårlig</span>
                  <span>{formData.sleep_quality}</span>
                  <span>Excellent</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Feeding Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Utensils className="w-4 h-4 mr-2 text-accent" />
              Måltider
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="feeding_times">Antal måltider</Label>
              <Input
                id="feeding_times"
                type="number"
                value={formData.feeding_times}
                onChange={(e) => updateField('feeding_times', parseInt(e.target.value) || 0)}
                placeholder="0"
              />
            </div>
            <div>
              <Label htmlFor="feeding_notes">Noter om måltider</Label>
              <Textarea
                id="feeding_notes"
                value={formData.feeding_notes}
                onChange={(e) => updateField('feeding_notes', e.target.value)}
                placeholder="Fx type af mad, appetit, reaktioner..."
              />
            </div>
          </CardContent>
        </Card>

        {/* Physical Development */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Scale className="w-4 h-4 mr-2 text-success" />
              Fysisk udvikling
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="diaper_changes">Blesskift i dag</Label>
              <Input
                id="diaper_changes"
                type="number"
                value={formData.diaper_changes}
                onChange={(e) => updateField('diaper_changes', parseInt(e.target.value) || 0)}
                placeholder="0"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="weight_grams">Vægt (gram)</Label>
                <Input
                  id="weight_grams"
                  type="number"
                  value={formData.weight_grams}
                  onChange={(e) => updateField('weight_grams', parseInt(e.target.value) || 0)}
                  placeholder="0"
                />
              </div>
              <div>
                <Label htmlFor="length_cm">Længde (cm)</Label>
                <Input
                  id="length_cm"
                  type="number"
                  step="0.1"
                  value={formData.length_cm}
                  onChange={(e) => updateField('length_cm', parseFloat(e.target.value) || 0)}
                  placeholder="0"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Mood & Development */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Heart className="w-4 h-4 mr-2 text-primary" />
              Humør og udvikling
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Generelt humør (1-10)</Label>
              <div className="mt-2">
                <Slider
                  value={[formData.mood_rating]}
                  onValueChange={(value) => updateField('mood_rating', value[0])}
                  max={10}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-muted-foreground mt-1">
                  <span>Utilfreds</span>
                  <span>{formData.mood_rating}</span>
                  <span>Glad</span>
                </div>
              </div>
            </div>
            <div>
              <Label htmlFor="development_notes">Udviklingsnoter</Label>
              <Textarea
                id="development_notes"
                value={formData.development_notes}
                onChange={(e) => updateField('development_notes', e.target.value)}
                placeholder="Nye færdigheder, reaktioner, opførsel..."
              />
            </div>
          </CardContent>
        </Card>

        {/* General Notes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Baby className="w-4 h-4 mr-2 text-accent" />
              Generelle noter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={formData.notes}
              onChange={(e) => updateField('notes', e.target.value)}
              placeholder="Andre observationer eller noter fra i dag..."
            />
          </CardContent>
        </Card>

        {/* Save Button */}
        <AnimatedButton 
          onSave={handleSave}
          className="w-full"
          successMessage="Babyens data gemt!"
        >
          <Save className="w-4 h-4 mr-2" />
          Gem dagens data
        </AnimatedButton>
      </div>
    </div>
  );
}