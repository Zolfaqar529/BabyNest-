import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { 
  ArrowLeft, 
  User, 
  Calendar,
  Upload,
  Download,
  Shield,
  BarChart3,
  Trash2,
  LogOut,
  Key
} from 'lucide-react';
import { AnimatedButton } from '@/components/ui/animated-button';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { useOptimizedAuth } from '@/hooks/useOptimizedAuth';
import { useAuth } from '@/components/auth/AuthProvider';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface ProfileProps {
  onBack: () => void;
}

export default function Profile({ onBack }: ProfileProps) {
  const { profile, updateProfile, baby, dailyEntries } = useSupabaseData();
  const { refreshData } = useOptimizedAuth();
  const { signOut, user } = useAuth();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    user_name: '',
    parent_name: '',
    email: '',
    due_date: '',
    baby_name: '',
    baby_gender: ''
  });

  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // Update form data when profile/baby data loads
  useEffect(() => {
    if (profile || baby) {
      setFormData({
        user_name: profile?.user_name || '',
        parent_name: profile?.parent_name || '',
        email: profile?.email || '',
        due_date: profile?.due_date || baby?.due_date || '',
        baby_name: profile?.baby_name || baby?.baby_name || '',
        baby_gender: profile?.baby_gender || baby?.gender || ''
      });
    }
  }, [profile, baby]);

  const handleSave = async () => {
    try {
      const cleanedData = {
        ...formData,
        due_date: formData.due_date || null
      };
      
      await updateProfile(cleanedData);
      
      // Also update baby information if baby name changed
      if (baby && formData.baby_name !== baby.baby_name) {
        const { error: babyError } = await supabase
          .from('babies')
          .update({ baby_name: formData.baby_name })
          .eq('user_id', user?.id);
          
        if (babyError) {
          console.error('Baby update error:', babyError);
        }
      }
      
      // Refresh data to update all components dynamically
      await refreshData();
      
      toast({
        title: "Profil opdateret",
        description: "Dine ændringer er blevet gemt.",
      });
    } catch (error) {
      console.error('Save error:', error);
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved lagring af dine ændringer.",
        variant: "destructive",
      });
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    try {
      setUploading(true);
      
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/profile.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('profiles')
        .upload(fileName, file, { 
          upsert: true,
          contentType: file.type 
        });

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('profiles')
        .getPublicUrl(fileName);

      await updateProfile({ profile_image_url: urlData.publicUrl });
      
      // Refresh data to update all components dynamically
      await refreshData();
      
      toast({
        title: "Profilbillede opdateret",
        description: "Dit profilbillede er blevet uploadet.",
      });
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved upload af billedet.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteProfile = async () => {
    setDeleting(true);
    try {
      const { error: entriesError } = await supabase
        .from('daily_entries')
        .delete()
        .eq('user_id', profile?.user_id);

      const { error: logsError } = await supabase
        .from('baby_logs')
        .delete()
        .eq('user_id', profile?.user_id);

      const { error: aiError } = await supabase
        .from('ai_responses')
        .delete()
        .eq('user_id', profile?.user_id);

      const { error: babiesError } = await supabase
        .from('babies')
        .delete()
        .eq('user_id', profile?.user_id);

      const { error: profileError } = await supabase
        .from('profiles')
        .delete()
        .eq('user_id', profile?.user_id);

      if (entriesError || logsError || aiError || babiesError || profileError) {
        throw new Error('Failed to delete profile data');
      }

      await signOut();
      
      toast({
        title: "Profil slettet",
        description: "Alle dine data er blevet permanent slettet.",
      });

      window.location.reload();
    } catch (error) {
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved sletning af profilen.",
        variant: "destructive"
      });
    } finally {
      setDeleting(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
      window.location.reload();
    } catch (error) {
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved log ud.",
        variant: "destructive"
      });
    }
  };

  const updateField = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Calculate statistics
  const totalDaysLogged = dailyEntries?.length || 0;
  const topSymptoms = dailyEntries?.reduce((acc, entry) => {
    if (entry.symptoms) {
      entry.symptoms.forEach(symptom => {
        acc[symptom] = (acc[symptom] || 0) + 1;
      });
    }
    return acc;
  }, {} as Record<string, number>);

  const topThreeSymptoms = Object.entries(topSymptoms || {})
    .sort(([,a], [,b]) => b - a)
    .slice(0, 3);

  const handleDownloadData = () => {
    // Simple CSV export
    const csvData = [
      ['Dato', 'Humør', 'Søvn', 'Energi', 'Symptomer', 'Noter'],
      ...(dailyEntries?.map(entry => [
        entry.date,
        entry.mood || '',
        entry.sleep || '',
        entry.energy_level || '',
        entry.symptoms?.join(', ') || '',
        entry.notes || ''
      ]) || [])
    ];

    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mine-graviditetsdata.csv';
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast({
      title: "Data downloadet",
      description: "Dine data er blevet downloadet som CSV-fil.",
    });
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Min profil</h1>
            <p className="text-sm text-muted-foreground">Administrer dine personlige oplysninger og konto</p>
          </div>
        </div>

        {/* Profile Image Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Upload className="w-4 h-4 mr-2 text-primary" />
              Profilbillede
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-4">
              {profile?.profile_image_url ? (
                <img 
                  src={profile.profile_image_url} 
                  alt="Profilbillede" 
                  className="w-16 h-16 rounded-full object-cover border-2 border-border"
                />
              ) : (
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                  <User className="w-8 h-8 text-muted-foreground" />
                </div>
              )}
              <div className="flex-1">
                <p className="text-sm text-muted-foreground mb-2">
                  {profile?.profile_image_url ? 'Profilbillede uploadet' : 'Ingen profilbillede uploadet'}
                </p>
                <label htmlFor="profile-image" className="cursor-pointer">
                  <Button variant="outline" size="sm" disabled={uploading} asChild>
                    <span>
                      {uploading ? 'Uploader...' : 'Vælg billede'}
                    </span>
                  </Button>
                </label>
                <input
                  id="profile-image"
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Personal Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <User className="w-4 h-4 mr-2 text-primary" />
              Personlige oplysninger
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="parent_name">Forældrenavn</Label>
                <Input
                  id="parent_name"
                  value={formData.parent_name}
                  onChange={(e) => updateField('parent_name', e.target.value)}
                  placeholder="Dit fulde navn"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateField('email', e.target.value)}
                  placeholder="din@email.dk"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="due_date">Termin</Label>
              <Input
                id="due_date"
                type="date"
                value={formData.due_date}
                onChange={(e) => updateField('due_date', e.target.value)}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="baby_name">Barnets navn</Label>
                <Input
                  id="baby_name"
                  value={formData.baby_name}
                  onChange={(e) => updateField('baby_name', e.target.value)}
                  placeholder="Barnets navn"
                />
              </div>
              <div>
                <Label htmlFor="baby_gender">Barnets køn</Label>
                <Select value={formData.baby_gender} onValueChange={(value) => updateField('baby_gender', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg køn" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dreng">Dreng</SelectItem>
                    <SelectItem value="pige">Pige</SelectItem>
                    <SelectItem value="ukendt">Ved ikke endnu</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data Statistics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <BarChart3 className="w-4 h-4 mr-2 text-accent" />
              Dine data-statistikker
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Dage logget</p>
                <p className="text-2xl font-semibold">{totalDaysLogged}</p>
              </div>
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">Mest almindelige symptomer</p>
                <div className="mt-2 space-y-1">
                  {topThreeSymptoms.slice(0, 3).map(([symptom, count], index) => (
                    <p key={symptom} className="text-sm">
                      {index + 1}. {symptom} ({count} gange)
                    </p>
                  ))}
                  {topThreeSymptoms.length === 0 && (
                    <p className="text-sm text-muted-foreground">Ingen symptomer logget endnu</p>
                  )}
                </div>
              </div>
            </div>
            
            <Button onClick={handleDownloadData} variant="outline" className="w-full">
              <Download className="w-4 h-4 mr-2" />
              Download mine data som CSV
            </Button>
          </CardContent>
        </Card>

        {/* Consent Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Shield className="w-4 h-4 mr-2 text-success" />
              Samtykke-status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${profile?.consent_given ? 'bg-success' : 'bg-muted'}`} />
              <span className="text-sm">
                {profile?.consent_given ? 'Vilkår og betingelser accepteret' : 'Vilkår og betingelser ikke accepteret'}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Account Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Key className="w-4 h-4 mr-2 text-warning" />
              Kontoindstillinger
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full" disabled>
              <Key className="w-4 h-4 mr-2" />
              Skift adgangskode (kommer snart)
            </Button>
            
            <Button 
              onClick={handleLogout}
              variant="outline"
              className="w-full"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Log ud
            </Button>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-destructive/20">
          <CardHeader>
            <CardTitle className="flex items-center text-sm text-destructive">
              <Trash2 className="w-4 h-4 mr-2" />
              Farezone
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Permanent sletning af din profil og alle tilknyttede data. Denne handling kan ikke fortrydes.
              </p>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Slet profil og al data
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Er du sikker?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Denne handling sletter permanent din profil og alle dine data, herunder:
                      <br />• Daglige logninger
                      <br />• Baby tracking data
                      <br />• AI samtaler
                      <br />• Personlige oplysninger
                      <br /><br />
                      Denne handling kan ikke fortrydes.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Annuller</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleDeleteProfile}
                      disabled={deleting}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      {deleting ? 'Sletter...' : 'Slet alt'}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <AnimatedButton 
          onSave={handleSave}
          className="w-full"
          successMessage="Profil opdateret!"
        >
          Gem ændringer
        </AnimatedButton>
      </div>
    </div>
  );
}