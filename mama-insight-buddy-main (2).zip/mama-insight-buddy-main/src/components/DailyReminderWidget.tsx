import { useState } from "react";
import { MessageWidget } from "@/components/ui/message-widget";
import { X } from "lucide-react";

interface DailyReminderWidgetProps {
  hasLoggedMood: boolean;
  hasLoggedToday: boolean;
  onClose?: () => void;
}

export default function DailyReminderWidget({ hasLoggedMood, hasLoggedToday, onClose }: DailyReminderWidgetProps) {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const handleClose = () => {
    setIsVisible(false);
    onClose?.();
  };

  const getReminderMessage = () => {
    if (!hasLoggedToday) {
      return "Du har ikke logget dine data i dag - vil du gøre det nu?";
    }
    if (!hasLoggedMood) {
      return "Du har ikke logget dit humør i dag";
    }
    // Could add more dynamic reminders based on user data
    return "Husk at drikke nok vand i dag 💧";
  };

  return (
    <div className="relative">
      <MessageWidget 
        type="info"
        message={getReminderMessage()}
        className="mb-4"
      />
      <button 
        onClick={handleClose}
        className="absolute top-2 right-2 p-1 rounded-full hover:bg-muted/20 transition-colors"
        aria-label="Luk reminder"
      >
        <X className="w-4 h-4 text-muted-foreground" />
      </button>
    </div>
  );
}