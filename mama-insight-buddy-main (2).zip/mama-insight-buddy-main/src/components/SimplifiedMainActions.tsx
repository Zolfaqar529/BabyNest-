import { MessageCircle, Baby, MoreHorizontal } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface SimplifiedMainActionsProps {
  onNavigate: (page: string) => void;
}

export default function SimplifiedMainActions({ onNavigate }: SimplifiedMainActionsProps) {
  return (
    <div className="space-y-4">
      {/* Primary Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Card 
          className="nordic-card cursor-pointer transition-all duration-300 hover:shadow-md hover:scale-[1.02] border-0"
          onClick={() => onNavigate("chat")}
        >
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-6 h-6 text-accent-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">AI Rådgiver</p>
            <p className="text-xs text-muted-foreground mt-1">Stil spørgsmål om graviditet</p>
          </CardContent>
        </Card>

        <Card 
          className="nordic-card cursor-pointer transition-all duration-300 hover:shadow-md hover:scale-[1.02] border-0"
          onClick={() => onNavigate("development")}
        >
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4">
              <Baby className="w-6 h-6 text-success-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">Baby udvikling</p>
            <p className="text-xs text-muted-foreground mt-1">Se hvordan baby vokser</p>
          </CardContent>
        </Card>
      </div>

      {/* See More */}
      <Card 
        className="nordic-card cursor-pointer transition-all duration-300 hover:shadow-sm hover:scale-[1.01] border-0"
        onClick={() => onNavigate("insights")}
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-center gap-3">
            <MoreHorizontal className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm font-medium text-muted-foreground">Se mere</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}