import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAIResponses } from "@/hooks/useAIResponses";
import { useSupabaseData } from "@/hooks/useSupabaseData";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Send, Loader2, Heart, AlertCircle, CheckCircle } from "lucide-react";

interface AIAssistantProps {
  context: {
    currentWeek: number;
    isPostpartum: boolean;
    symptoms?: string[];
    mood?: number;
    userQuestion?: string;
  };
  onResponse?: (response: string) => void;
}

export default function AIAssistant({ context, onResponse }: AIAssistantProps) {
  const { saveAIResponse } = useAIResponses();
  const { dailyEntries, getTodayEntry } = useSupabaseData();
  const { toast } = useToast();
  const [userInput, setUserInput] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showResponse, setShowResponse] = useState(false);

  const generateAIResponse = async (input: string) => {
    setIsLoading(true);
    setShowResponse(false);

    try {
      // Debug logging
      console.log('🤖 AI Input received:', input);
      console.log('🤖 Input length:', input.length);
      console.log('🤖 Input toLowerCase:', input.toLowerCase());
      
      // Get user's recent data for more context
      const todayEntry = getTodayEntry();
      const recentEntries = dailyEntries.slice(0, 7); // Last 7 entries
      
      // Intelligent response generation based on message analysis
      const analyzeMessage = (text: string) => {
        const words = text.split(' ').length;
        const isQuestion = text.includes('?') || text.toLowerCase().match(/^(hvad|hvordan|hvor|hvornår|kan|må|skal|er det)/);
        const isGreeting = text.toLowerCase().match(/^(hej|hallo|hi|godmorgen|goddag|godaften)$/);
        const isShortStatement = words <= 3 && !isQuestion;
        const containsConcern = text.toLowerCase().match(/(ondt|smerter|bekymret|bange|alene|trist|ked|dårligt|kvalme)/);
        const containsFood = text.toLowerCase().match(/(spise|mad|drikke|tun|kaffe|ost|alkohol)/);
        const containsSleep = text.toLowerCase().match(/(sov|søvn|træt|vågen|sover)/);
        
        console.log('🔍 Message Analysis:', { words, isQuestion, isGreeting, isShortStatement, containsConcern, containsFood, containsSleep });
        
        return { words, isQuestion, isGreeting, isShortStatement, containsConcern, containsFood, containsSleep };
      };

      const analysis = analyzeMessage(input);
      let response = "";

      // Generate contextual response based on analysis
      console.log('🎯 Generating response for analysis:', analysis);
      
      if (analysis.isGreeting) {
        console.log('✅ Detected greeting, sending short response');
        response = `Hej! 😊 Hvordan har du det?`;
        
      } else if (analysis.isShortStatement && analysis.words <= 2) {
        // Very short messages get brief acknowledgment
        response = `Jeg forstår 💙 Vil du fortælle lidt mere?`;
        
      } else if (analysis.containsConcern) {
        // Handle concerns with empathy
        const concernType = input.toLowerCase().includes('ondt') || input.toLowerCase().includes('smerter') ? 'physical' :
                           input.toLowerCase().includes('alene') || input.toLowerCase().includes('trist') ? 'emotional' : 'general';
        
        if (concernType === 'physical') {
          response = `Det lyder ubehageligt 😔 ${context.isPostpartum ? 'Efter fødslen' : 'Under graviditeten'} er smerter ret almindelige. 

Prøv at hvile og kontakt din jordemoder hvis det bliver værre. Du kan logge det i appen! 💡`;
        } else if (concernType === 'emotional') {
          response = `Jeg forstår godt at du har det sådan 💙 ${context.isPostpartum ? 'Tiden efter fødslen' : 'Graviditeten'} kan være følelsesmæssigt udfordrende.

Det er helt normalt! Du er ikke alene 🤗`;
        } else {
          response = `Jeg hører din bekymring 💛 Som ${context.isPostpartum ? 'nybagt mor' : 'gravid'} er det naturligt at have bekymringer.

Hvad tænker du på lige nu?`;
        }
        
      } else if (analysis.containsFood) {
        // Food-related questions
        const foodItem = input.toLowerCase().includes('tun') ? 'Tun er ok i små mængder' :
                         input.toLowerCase().includes('kaffe') ? 'Kaffe er ok, max 1-2 kopper' :
                         input.toLowerCase().includes('alkohol') ? 'Alkohol skal undgås' :
                         'Spis varieret og sundt';
        
        response = `${foodItem} ${context.isPostpartum ? 'når du ammer' : 'under graviditeten'} 🥗 

Ved tvivl spørg din jordemoder!`;
        
      } else if (analysis.containsSleep) {
        // Sleep-related issues
        response = `Søvnproblemer er hårde! 😴 ${context.isPostpartum ? 'Prøv at hvile når baby sover' : 'Søvn kan være svær når maven vokser'}.

${todayEntry?.sleep_quality ? `Din søvnkvalitet i dag: ${todayEntry.sleep_quality}/10` : 'Husk at logge din søvn i appen!'}`;
        
      } else if (analysis.isQuestion && analysis.words > 5) {
        // Longer questions deserve detailed answers
        response = `Det er et godt spørgsmål! ${context.isPostpartum ? 'Som nybagt mor' : 'Under graviditeten'} er det vigtigt at få svar.

${context.isPostpartum ? 
  `I uge ${context.currentWeek} efter fødslen sker der meget med din krop og baby.` :
  `I graviditetsuge ${context.currentWeek} udvikler din baby sig hurtigt.`
}

Kan du fortælle lidt mere om hvad du tænker på? Så kan jeg give et mere specifikt svar 💕`;

      } else if (analysis.words <= 4) {
        // Short messages get short, encouraging responses
        const encouragements = [
          `Jeg er her for dig 💙`,
          `Fortæl gerne mere 🤗`,
          `Hvordan kan jeg hjælpe? 💕`,
          `Jeg lytter 😊`
        ];
        response = encouragements[Math.floor(Math.random() * encouragements.length)];
        
      } else {
        // Default contextual response for medium-length messages
        response = `${context.isPostpartum ? 'Som nybagt mor' : 'Under graviditeten'} er det vigtigt at lytte til din krop 🌸

${todayEntry?.mood && todayEntry.mood <= 5 ? 
  `Dit humør i dag: ${todayEntry.mood}/10 - helt ok at have svære dage! ` : 
  'Hvordan har du det lige nu? '
}

Jeg er her for at hjælpe 💕`;
      }
      
      console.log('🎤 Final AI Response:', response);
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Save AI response to database
      try {
        await saveAIResponse(input, response);
        toast({
          title: "Svar gemt",
          description: "Dit AI-svar er gemt i din historik",
        });
      } catch (error) {
        console.error('Error saving AI response:', error);
        // Don't show error to user, just log it
      }
      
      setAiResponse(response);
      setShowResponse(true);
      onResponse?.(response);
      
    } catch (error) {
      setAiResponse("Beklager, jeg kan ikke svare lige nu. Prøv igen senere eller kontakt din sundhedsperson ved presserende spørgsmål.");
      setShowResponse(true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = () => {
    if (userInput.trim()) {
      generateAIResponse(userInput);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="space-y-6">
      <Card className="nordic-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="text-base font-playfair font-medium">AI Rådgiver</h3>
              <p className="text-xs text-muted-foreground font-normal">
                Specialiseret i graviditet og postpartum sundhed
              </p>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <label htmlFor="ai-input" className="text-xs font-medium">
              Hvordan kan jeg hjælpe dig i dag?
            </label>
            <Textarea
              id="ai-input"
              placeholder="F.eks. 'Jeg føler mig træt hele tiden' eller 'Er det normalt at have rygsmerter?'"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyPress={handleKeyPress}
              className="nordic-input min-h-[100px] resize-none"
              disabled={isLoading}
            />
          </div>

          <Button
            onClick={handleSubmit}
            disabled={!userInput.trim() || isLoading}
            className="w-full nordic-button"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Tænker...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Få AI råd
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {showResponse && aiResponse && (
        <Card className="nordic-card bg-gradient-to-br from-primary/5 to-primary-glow/10 border-primary/20 animate-fade-in">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-primary">
              <Heart className="w-5 h-5" />
              Mit råd til dig
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm max-w-none">
              <div className="whitespace-pre-wrap text-foreground leading-relaxed">
                {aiResponse}
              </div>
            </div>
            <div className="mt-4 p-3 bg-muted/30 rounded-2xl border border-border/40">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                <p className="text-xs text-muted-foreground">
                  <strong>Vigtigt:</strong> Dette er generelle råd. Kontakt altid din jordemoder, læge eller sundhedsperson ved bekymringer eller presserende spørgsmål.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}