import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Apple } from "lucide-react";

// Baby development stages for SVG animation
const BabyDevelopmentStages = {
  early: (size: number) => (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} viewBox="0 0 100 100" className="animate-baby-breathe">
        <defs>
          <radialGradient id="seedGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.8" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.2" />
          </radialGradient>
        </defs>
        <circle cx="50" cy="50" r="8" fill="url(#seedGradient)" className="animate-pulse" />
        <circle cx="50" cy="50" r="12" fill="none" stroke="hsl(var(--primary))" strokeWidth="1" opacity="0.4" className="animate-ping" />
      </svg>
    </div>
  ),
  
  sprouting: (size: number) => (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} viewBox="0 0 100 100" className="animate-baby-breathe">
        <defs>
          <linearGradient id="sproutGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="hsl(var(--success))" />
            <stop offset="100%" stopColor="hsl(var(--primary))" />
          </linearGradient>
        </defs>
        <circle cx="50" cy="70" r="6" fill="hsl(var(--primary))" opacity="0.8" />
        <path d="M50 70 Q45 50 40 35 Q45 30 50 35 Q55 30 60 35 Q55 50 50 70" 
              fill="url(#sproutGradient)" opacity="0.9" className="animate-float" />
        <circle cx="50" cy="50" r="20" fill="none" stroke="hsl(var(--primary))" strokeWidth="1" opacity="0.2" className="animate-pulse" />
      </svg>
    </div>
  ),
  
  growing: (size: number) => (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} viewBox="0 0 100 100" className="animate-baby-breathe">
        <defs>
          <radialGradient id="growthGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.9" />
            <stop offset="70%" stopColor="hsl(var(--accent))" stopOpacity="0.6" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.2" />
          </radialGradient>
        </defs>
        <ellipse cx="50" cy="55" rx="20" ry="25" fill="url(#growthGradient)" className="animate-gentle-pulse" />
        <circle cx="45" cy="45" r="3" fill="hsl(var(--foreground))" opacity="0.6" />
        <circle cx="55" cy="45" r="3" fill="hsl(var(--foreground))" opacity="0.6" />
        <circle cx="50" cy="50" r="35" fill="none" stroke="hsl(var(--primary))" strokeWidth="1" opacity="0.15" className="animate-pulse" />
      </svg>
    </div>
  ),
  
  developing: (size: number) => (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} viewBox="0 0 100 100" className="animate-baby-breathe">
        <defs>
          <radialGradient id="babyGradient" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor="hsl(var(--accent))" stopOpacity="0.9" />
            <stop offset="50%" stopColor="hsl(var(--primary))" stopOpacity="0.7" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
          </radialGradient>
        </defs>
        {/* Head */}
        <ellipse cx="50" cy="35" rx="18" ry="20" fill="url(#babyGradient)" />
        {/* Body */}
        <ellipse cx="50" cy="65" rx="15" ry="22" fill="url(#babyGradient)" opacity="0.8" />
        {/* Arms */}
        <ellipse cx="35" cy="55" rx="4" ry="12" fill="url(#babyGradient)" opacity="0.7" />
        <ellipse cx="65" cy="55" rx="4" ry="12" fill="url(#babyGradient)" opacity="0.7" />
        {/* Legs */}
        <ellipse cx="42" cy="82" rx="4" ry="10" fill="url(#babyGradient)" opacity="0.7" />
        <ellipse cx="58" cy="82" rx="4" ry="10" fill="url(#babyGradient)" opacity="0.7" />
        {/* Glow effect */}
        <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--primary))" strokeWidth="0.5" opacity="0.1" className="animate-pulse" />
      </svg>
    </div>
  )
};

interface WeeklyBabyDisplayProps {
  userProfile: {
    motherName: string;
    expectedDate: string;
    babyName: string;
    babyGender: string;
    isPostpartum: boolean;
  };
  currentWeek: number;
  daysLeft: number;
  babySize: string;
  todayEntry?: any;
  onNavigate?: (page: string) => void;
}

// Map weeks to development stages
const getBabyVisualization = (week: number, size: number) => {
  if (week <= 8) return BabyDevelopmentStages.early(size);
  if (week <= 16) return BabyDevelopmentStages.sprouting(size);
  if (week <= 28) return BabyDevelopmentStages.growing(size);
  return BabyDevelopmentStages.developing(size);
};

export default function WeeklyBabyDisplay({ 
  userProfile, 
  currentWeek, 
  daysLeft, 
  babySize,
  todayEntry,
  onNavigate
}: WeeklyBabyDisplayProps) {
  const [weekData, setWeekData] = useState<any>(null);

  // Dynamic greeting based on tracking data
  const getDynamicGreeting = () => {
    if (!todayEntry) {
      return `Se ${userProfile.babyName || "din baby"}s udvikling`;
    }

    const mood = todayEntry.mood;
    const energy = todayEntry.energy_level;
    const symptoms = todayEntry.symptoms || [];

    // Positive mood messages
    if (mood >= 8) {
      return `Du har det godt i dag! ${userProfile.babyName || "Baby"} nyder også din gode energi ✨`;
    }
    
    // Medium mood with good energy
    if (mood >= 6 && energy >= 7) {
      return `God energi i dag! ${userProfile.babyName || "Baby"} vokser stærkt 💪`;
    }
    
    // Low energy or many symptoms
    if (energy <= 4 || symptoms.length >= 3) {
      return `Tag det roligt i dag. ${userProfile.babyName || "Baby"} og du skal bare hvile 🤗`;
    }
    
    // Medium mood
    if (mood >= 5) {
      return `En almindelig dag. ${userProfile.babyName || "Baby"} udvikler sig fint 🌱`;
    }
    
    // Low mood
    return `Nogle dage er svære. ${userProfile.babyName || "Baby"} er der for dig 💝`;
  };

  useEffect(() => {
    const loadBabyDevelopment = async () => {
      try {
        const response = await fetch('/src/data/babyDevelopment.json');
        const developmentData = await response.json();
        const data = developmentData[currentWeek.toString()];
        setWeekData(data);
      } catch (error) {
        console.error("Could not load baby development data:", error);
      }
    };

    if (currentWeek >= 0) {
      loadBabyDevelopment();
    }
  }, [currentWeek]);

  const getWeekTitle = () => {
    if (userProfile.isPostpartum) {
      return `Uge ${currentWeek} efter fødslen`;
    } else {
      return `Graviditetsuge ${currentWeek}`;
    }
  };

  const getProgressPercentage = () => {
    if (userProfile.isPostpartum) return 100;
    return Math.min(100, (currentWeek / 40) * 100);
  };

  const getBabyVisualizationComponent = () => {
    // Scale baby size proportionally with pregnancy week
    // Week 5-8: Small (120-140px)
    // Week 9-16: Medium (140-180px) 
    // Week 17-28: Large (180-220px)
    // Week 29-40: Very Large (220-280px)
    const minSize = 120;
    const maxSize = 280;
    const sizeRange = maxSize - minSize;
    const weekProgress = Math.min(currentWeek / 40, 1); // Cap at week 40
    const scaledSize = minSize + (sizeRange * weekProgress);
    
    return getBabyVisualization(currentWeek, scaledSize);
  };

  return (
    <div className="relative">
      {/* Week info at bottom */}
      <div className="absolute bottom-4 left-4 z-10">
        <div className="bg-white/90 backdrop-blur-sm rounded-full px-4 py-2 shadow-gentle">
          <span className="text-sm font-semibold text-warm-text">
            {userProfile.isPostpartum ? `Uge ${currentWeek}` : `Dag ${Math.max(0, currentWeek * 7)}`}
          </span>
        </div>
      </div>

      {/* Open button */}
      <div className="absolute bottom-4 right-4 z-10">
        <button 
          onClick={() => onNavigate?.("baby-detail")}
          className="bg-white/90 backdrop-blur-sm rounded-full px-6 py-2 shadow-gentle hover:bg-white transition-colors duration-200 flex items-center gap-2"
        >
          <span className="text-sm font-medium text-warm-text">Åbn</span>
          <svg className="w-4 h-4 text-warm-text" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
        
      {/* Main baby development visualization */}
      {!userProfile.isPostpartum && (
        <div className="relative pt-4 pb-20 px-8">
          {/* Central baby visualization */}
          <div className="flex justify-center items-center min-h-[280px]">
            <div className="relative">
              {/* Enhanced breathing glow */}
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/30 rounded-full blur-3xl animate-baby-breathe scale-150" />
              <div className="relative drop-shadow-2xl hover:scale-105 transition-transform duration-500">
                {getBabyVisualizationComponent()}
              </div>
            </div>
          </div>
        </div>
      )}

      {userProfile.babyName && (
        <div className="absolute top-16 left-4 right-16">
          <p className="text-mobile-sm text-warm-text/80 font-medium leading-relaxed">
            {userProfile.isPostpartum ? 
              `${userProfile.babyName} er nu ${currentWeek} uger gammel! 🍼` : 
              getDynamicGreeting()
            }
          </p>
        </div>
      )}
    </div>
  );
}