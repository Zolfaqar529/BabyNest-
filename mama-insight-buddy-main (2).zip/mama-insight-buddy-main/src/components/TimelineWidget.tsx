import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, ChevronLeft, ChevronRight, AlertCircle, CheckCircle, Minus } from 'lucide-react';
import { TimelineDay } from '@/hooks/useOverviewData';
import { format, subDays, addDays } from 'date-fns';
import { da } from 'date-fns/locale';

interface TimelineWidgetProps {
  data: TimelineDay[];
}

export function TimelineWidget({ data }: TimelineWidgetProps) {
  const [selectedDay, setSelectedDay] = useState<TimelineDay | null>(null);
  const [currentPeriod, setCurrentPeriod] = useState(0); // 0 = last 7 days, 1 = 8-14 days ago, etc.

  const periods = [
    { label: 'Sidste 7 dage', days: 7 },
    { label: '8-14 dage siden', days: 7 },
    { label: '15-21 dage siden', days: 7 },
    { label: '22-30 dage siden', days: 9 },
  ];

  const itemsPerPeriod = currentPeriod === 3 ? 9 : 7; // Last period shows 9 days to complete 30 days
  const startIndex = currentPeriod === 3 ? 21 : currentPeriod * 7;
  const endIndex = currentPeriod === 3 ? 30 : (currentPeriod + 1) * 7;
  const currentData = data.slice(startIndex, endIndex);

  const getStatusIcon = (status: TimelineDay['status']) => {
    switch (status) {
      case 'good':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      case 'critical':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: TimelineDay['status']) => {
    switch (status) {
      case 'good':
        return 'bg-green-100 border-green-200 hover:bg-green-50';
      case 'warning':
        return 'bg-yellow-100 border-yellow-200 hover:bg-yellow-50';
      case 'critical':
        return 'bg-red-100 border-red-200 hover:bg-red-50';
      default:
        return 'bg-gray-100 border-gray-200 hover:bg-gray-50';
    }
  };

  const getStatusText = (status: TimelineDay['status']) => {
    switch (status) {
      case 'good':
        return 'God';
      case 'warning':
        return 'Advarsel';
      case 'critical':
        return 'Kritisk';
      default:
        return 'Ingen data';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-primary" />
            <CardTitle className="text-lg">Tidslinje</CardTitle>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentPeriod(Math.max(0, currentPeriod - 1))}
              disabled={currentPeriod === 0}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-sm text-muted-foreground min-w-[120px] text-center">
              {periods[currentPeriod]?.label}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setCurrentPeriod(Math.min(3, currentPeriod + 1))}
              disabled={currentPeriod === 3}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className={`grid gap-2 ${currentPeriod === 3 ? 'grid-cols-3' : 'grid-cols-7'}`}>
          {currentData.map((day, index) => (
            <Button
              key={day.date}
              variant="outline"
              size="sm"
              className={`h-16 flex flex-col items-center justify-center p-2 ${getStatusColor(day.status)}`}
              onClick={() => setSelectedDay(selectedDay?.date === day.date ? null : day)}
            >
              <div className="text-xs font-medium">{day.formattedDate}</div>
              {getStatusIcon(day.status)}
              <div className="text-xs text-muted-foreground mt-1">
                {day.hasData ? `${day.symptoms.length} symptomer` : 'Ingen data'}
              </div>
            </Button>
          ))}
        </div>

        {/* Selected Day Details */}
        {selectedDay && (
          <div className="mt-4 p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium">{selectedDay.formattedDate}</h4>
              <div className="flex items-center space-x-2">
                {getStatusIcon(selectedDay.status)}
                <span className="text-sm font-medium">{getStatusText(selectedDay.status)}</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Humør:</span>
                <span className="ml-2 font-medium">
                  {selectedDay.mood ? `${selectedDay.mood}/10` : 'Ikke registreret'}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Energi:</span>
                <span className="ml-2 font-medium">
                  {selectedDay.energy ? `${selectedDay.energy}/10` : 'Ikke registreret'}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Søvn:</span>
                <span className="ml-2 font-medium">
                  {selectedDay.sleep ? `${selectedDay.sleep} timer` : 'Ikke registreret'}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Vægt:</span>
                <span className="ml-2 font-medium">
                  {selectedDay.weight ? `${selectedDay.weight} kg` : 'Ikke registreret'}
                </span>
              </div>
            </div>

            {selectedDay.symptoms.length > 0 && (
              <div className="mt-3">
                <span className="text-muted-foreground text-sm">Symptomer:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {selectedDay.symptoms.map((symptom, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full"
                    >
                      {symptom}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {selectedDay.exercise && (
              <div className="mt-3">
                <span className="text-muted-foreground text-sm">Motion:</span>
                <span className="ml-2 text-sm">{selectedDay.exercise}</span>
              </div>
            )}
          </div>
        )}

        {/* Legend */}
        <div className="mt-4 flex items-center justify-center space-x-4 text-xs">
          <div className="flex items-center space-x-1">
            <CheckCircle className="w-3 h-3 text-green-500" />
            <span>God</span>
          </div>
          <div className="flex items-center space-x-1">
            <AlertCircle className="w-3 h-3 text-yellow-500" />
            <span>Advarsel</span>
          </div>
          <div className="flex items-center space-x-1">
            <AlertCircle className="w-3 h-3 text-red-500" />
            <span>Kritisk</span>
          </div>
          <div className="flex items-center space-x-1">
            <Minus className="w-3 h-3 text-gray-400" />
            <span>Ingen data</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
} 
