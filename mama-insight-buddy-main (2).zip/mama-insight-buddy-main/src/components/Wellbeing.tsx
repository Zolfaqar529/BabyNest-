import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Heart, Brain, MessageCircle } from "lucide-react";
import { AIService } from "@/lib/aiService";

interface WellbeingData {
  date: string;
  physicalSymptoms: string[];
  otherPhysical: string;
  emotionalState: string[];
  otherEmotional: string;
  comment: string;
  aiResponse: string;
}

interface WellbeingProps {
  onBack: () => void;
  userProfile?: {
    motherName: string;
    expectedDate: string;
    babyName: string;
    babyGender: string;
    isPostpartum: boolean;
  };
}

export default function Wellbeing({ onBack, userProfile }: WellbeingProps) {
  const [physicalSymptoms, setPhysicalSymptoms] = useState<string[]>([]);
  const [otherPhysical, setOtherPhysical] = useState("");
  const [emotionalState, setEmotionalState] = useState<string[]>([]);
  const [otherEmotional, setOtherEmotional] = useState("");
  const [comment, setComment] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [showAiResponse, setShowAiResponse] = useState(false);

  const physicalOptions = [
    "Trykken i underliv",
    "Hævelse (hænder, fødder, ansigt)",
    "Hovedpine eller synsforstyrrelser", 
    "Hjertebanken eller åndenød",
    "Smerter i lænd eller bækken",
    "Svimmelhed eller følelsen af at 'besvime'"
  ];

  const emotionalOptions = [
    "Føler mig rolig 😌",
    "Let til tårer 😢",
    "Bekymret uden grund 😰",
    "Føler mig nedtrykt 😔",
    "Overvældet 😵",
    "Har tankemylder 🧠"
  ];

  // Load today's data if it exists
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const savedWellbeing = localStorage.getItem("beenest_wellbeing") || localStorage.getItem("mammatracker_wellbeing");
    
    if (savedWellbeing) {
      const wellbeingHistory = JSON.parse(savedWellbeing);
      const todayData = wellbeingHistory.find((entry: WellbeingData) => entry.date === today);
      
      if (todayData) {
        setPhysicalSymptoms(todayData.physicalSymptoms);
        setOtherPhysical(todayData.otherPhysical);
        setEmotionalState(todayData.emotionalState);
        setOtherEmotional(todayData.otherEmotional);
        setComment(todayData.comment);
        if (todayData.aiResponse) {
          setAiResponse(todayData.aiResponse);
          setShowAiResponse(true);
        }
      }
    }
  }, []);

  const handlePhysicalChange = (symptom: string, checked: boolean) => {
    if (checked) {
      setPhysicalSymptoms([...physicalSymptoms, symptom]);
    } else {
      setPhysicalSymptoms(physicalSymptoms.filter(s => s !== symptom));
    }
  };

  const handleEmotionalChange = (emotion: string, checked: boolean) => {
    if (checked) {
      setEmotionalState([...emotionalState, emotion]);
    } else {
      setEmotionalState(emotionalState.filter(e => e !== emotion));
    }
  };

  const generateAiResponse = () => {
    if (!userProfile) {
      return "Tak for at du deler dine oplevelser. Jeg er her for at støtte dig! 💕";
    }

    // Load recent tracking data for enhanced analysis
    const existingHistory = localStorage.getItem("babynest_history") || "[]";
    const recentData = JSON.parse(existingHistory).slice(-5);
    
    // Enhanced AI analysis using the new service
    let combinedSymptoms = [...physicalSymptoms];
    if (otherPhysical) combinedSymptoms.push(otherPhysical);
    if (emotionalState.length > 0) combinedSymptoms.push(...emotionalState);
    if (otherEmotional) combinedSymptoms.push(otherEmotional);

    if (combinedSymptoms.length > 0) {
      const analysis = AIService.analyzeSymptom(combinedSymptoms[0], userProfile, recentData);
      let response = `${analysis.empathicResponse}\n\n${analysis.explanation}`;
      
      if (analysis.suggestions.length > 0) {
        response += `\n\n**Mine forslag:**\n${analysis.suggestions.slice(0, 3).map(s => `• ${s}`).join('\n')}`;
      }
      
      return response;
    }

    // Generate micro-notification if no specific symptoms
    const microNotification = AIService.generateMicroNotification(userProfile);
    return `${microNotification}\n\nDet er dejligt at høre fra dig, ${userProfile.motherName}. Fortsæt med at lytte til din krop og noter dine oplevelser. 💚`;
  };

  const handleSubmit = () => {
    const today = new Date().toISOString().split('T')[0];
    const response = generateAiResponse();
    
    const wellbeingData: WellbeingData = {
      date: today,
      physicalSymptoms,
      otherPhysical,
      emotionalState,
      otherEmotional,
      comment,
      aiResponse: response
    };

    // Save to localStorage
    const savedWellbeing = localStorage.getItem("beenest_wellbeing") || localStorage.getItem("mammatracker_wellbeing");
    let wellbeingHistory: WellbeingData[] = savedWellbeing ? JSON.parse(savedWellbeing) : [];
    
    // Update or add today's entry
    const existingIndex = wellbeingHistory.findIndex(entry => entry.date === today);
    if (existingIndex >= 0) {
      wellbeingHistory[existingIndex] = wellbeingData;
    } else {
      wellbeingHistory.push(wellbeingData);
    }
    
    localStorage.setItem("beenest_wellbeing", JSON.stringify(wellbeingHistory));
    
    setAiResponse(response);
    setShowAiResponse(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-primary-glow/10 p-4 pb-20">
      <div className="max-w-sm mx-auto space-y-4">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={onBack} className="p-2">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-lg font-bold">Mit velbefindende</h1>
            <p className="text-sm text-muted-foreground">Hvordan har du det i dag?</p>
          </div>
        </div>

        {/* Physical symptoms */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Heart className="w-4 h-4 mr-2 text-primary" />
              Kropsfornemmelser
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3">
              {physicalOptions.map((symptom) => (
                <div key={symptom} className="flex items-center space-x-2">
                  <Checkbox
                    id={symptom}
                    checked={physicalSymptoms.includes(symptom)}
                    onCheckedChange={(checked) => handlePhysicalChange(symptom, checked as boolean)}
                  />
                  <label htmlFor={symptom} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    {symptom}
                  </label>
                </div>
              ))}
            </div>
            <Textarea
              placeholder="Andet (beskriv gerne)..."
              value={otherPhysical}
              onChange={(e) => setOtherPhysical(e.target.value)}
              className="mt-3"
            />
          </CardContent>
        </Card>

        {/* Emotional wellbeing */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Brain className="w-4 h-4 mr-2 text-accent" />
              Følelsesmæssigt velbefindende
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3">
              {emotionalOptions.map((emotion) => (
                <div key={emotion} className="flex items-center space-x-2">
                  <Checkbox
                    id={emotion}
                    checked={emotionalState.includes(emotion)}
                    onCheckedChange={(checked) => handleEmotionalChange(emotion, checked as boolean)}
                  />
                  <label htmlFor={emotion} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    {emotion}
                  </label>
                </div>
              ))}
            </div>
            <Textarea
              placeholder="Andet (beskriv gerne)..."
              value={otherEmotional}
              onChange={(e) => setOtherEmotional(e.target.value)}
              className="mt-3"
            />
          </CardContent>
        </Card>

        {/* Comment/diary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <MessageCircle className="w-4 h-4 mr-2 text-success" />
              Dine tanker i dag
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Hvordan har du det i dag? Skriv gerne dine tanker og følelser..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="min-h-[100px]"
            />
          </CardContent>
        </Card>

        {/* AI Response */}
        {showAiResponse && (
          <Card className="border-primary/20 bg-gradient-to-r from-primary/5 to-accent/5">
            <CardHeader>
              <CardTitle className="flex items-center text-primary">
                <Heart className="w-5 h-5 mr-2" />
                Din personlige rådgiver
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-gradient-to-r from-background/80 to-primary-glow/10 rounded-lg border border-primary/10">
                <p className="text-sm leading-relaxed">{aiResponse}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Submit button */}
        <Button 
          onClick={handleSubmit}
          className="w-full bg-gradient-to-r from-primary to-primary-glow text-white py-6 text-lg font-semibold"
          size="lg"
        >
          {showAiResponse ? "Opdater velbefindende" : "Få personlig vejledning"} ✨
        </Button>
      </div>
    </div>
  );
}