import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useSupabaseData } from "@/hooks/useSupabaseData";
import { useAIResponses } from "@/hooks/useAIResponses";
import { 
  Calendar,
  Heart,
  Moon,
  Activity,
  Scale,
  Brain,
  TrendingUp,
  MessageSquare,
  Target
} from "lucide-react";

interface DailyReportCompleteProps {
  selectedDate?: string;
}

export default function DailyReportComplete({ selectedDate }: DailyReportCompleteProps) {
  const { dailyEntries } = useSupabaseData();
  const { aiResponses } = useAIResponses();
  const [reportDate, setReportDate] = useState(selectedDate || new Date().toISOString().split('T')[0]);

  const todayEntry = dailyEntries.find(entry => entry.date === reportDate);
  const todayAIResponses = aiResponses.filter(response => 
    response.created_at.split('T')[0] === reportDate
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("da-DK", { 
      weekday: "long", 
      year: "numeric", 
      month: "long", 
      day: "numeric" 
    });
  };

  if (!todayEntry && todayAIResponses.length === 0) {
    return (
      <Card className="nordic-card">
        <CardHeader>
          <CardTitle className="flex items-center text-sm">
            <Calendar className="w-4 h-4 mr-2 text-primary" />
            Daglig rapport - {formatDate(reportDate)}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <p className="text-muted-foreground">
            Ingen data registreret for denne dag.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="nordic-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-primary" />
            Komplet dagrapport - {formatDate(reportDate)}
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Samlet oversigt over dine registreringer
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Tracking Data */}
          {todayEntry && (
            <>
              {/* Wellbeing Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-3 p-4 bg-muted/30 rounded-2xl">
                  <Heart className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Humør</p>
                    <p className="font-semibold">{todayEntry.mood || '-'}/10</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 p-4 bg-muted/30 rounded-2xl">
                  <Activity className="w-5 h-5 text-success" />
                  <div>
                    <p className="text-sm text-muted-foreground">Energi</p>
                    <p className="font-semibold">{todayEntry.energy_level || '-'}/10</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 p-4 bg-muted/30 rounded-2xl">
                  <Moon className="w-5 h-5 text-accent" />
                  <div>
                    <p className="text-sm text-muted-foreground">Søvn</p>
                    <p className="font-semibold">{todayEntry.sleep || '-'}t</p>
                  </div>
                </div>

                {todayEntry.stress_level && (
                  <div className="flex items-center space-x-3 p-4 bg-muted/30 rounded-2xl">
                    <Brain className="w-5 h-5 text-warning" />
                    <div>
                      <p className="text-sm text-muted-foreground">Stress</p>
                      <p className="font-semibold">{todayEntry.stress_level}/10</p>
                    </div>
                  </div>
                )}

                {todayEntry.sleep_quality && (
                  <div className="flex items-center space-x-3 p-4 bg-muted/30 rounded-2xl">
                    <Moon className="w-5 h-5 text-success" />
                    <div>
                      <p className="text-sm text-muted-foreground">Søvnkvalitet</p>
                      <p className="font-semibold">{todayEntry.sleep_quality}/10</p>
                    </div>
                  </div>
                )}

                {todayEntry.nausea_level && (
                  <div className="flex items-center space-x-3 p-4 bg-muted/30 rounded-2xl">
                    <Target className="w-5 h-5 text-destructive" />
                    <div>
                      <p className="text-sm text-muted-foreground">Kvalme</p>
                      <p className="font-semibold">{todayEntry.nausea_level}/10</p>
                    </div>
                  </div>
                )}

                {todayEntry.weight && (
                  <div className="flex items-center space-x-3 p-4 bg-muted/30 rounded-2xl">
                    <Scale className="w-5 h-5 text-warning" />
                    <div>
                      <p className="text-sm text-muted-foreground">Vægt</p>
                      <p className="font-semibold">{todayEntry.weight}kg</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Symptoms */}
              {todayEntry.symptoms && todayEntry.symptoms.length > 0 && (
                <div>
                  <h4 className="font-medium mb-3 flex items-center">
                    <TrendingUp className="w-4 h-4 mr-2 text-primary" />
                    Symptomer registreret
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {todayEntry.symptoms.map((symptom, idx) => (
                      <Badge key={idx} variant="secondary">
                        {symptom}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Exercise */}
              {todayEntry.exercise && (
                <div>
                  <h4 className="font-medium mb-2 flex items-center">
                    <Activity className="w-4 h-4 mr-2 text-success" />
                    Motion og aktivitet
                  </h4>
                  <p className="text-muted-foreground bg-muted/30 p-3 rounded-2xl">
                    {todayEntry.exercise}
                  </p>
                </div>
              )}

              {/* Notes */}
              {todayEntry.notes && (
                <div>
                  <h4 className="font-medium mb-2 flex items-center">
                    <MessageSquare className="w-4 h-4 mr-2 text-accent" />
                    Dagbog
                  </h4>
                  <p className="text-muted-foreground bg-muted/30 p-3 rounded-2xl">
                    {todayEntry.notes}
                  </p>
                </div>
              )}

              {/* Physical/Emotional feelings from wellbeing */}
              {(todayEntry.physical_feelings || todayEntry.emotional_state) && (
                <div className="space-y-3">
                  {todayEntry.physical_feelings && (
                    <div>
                      <h4 className="font-medium mb-2 flex items-center">
                        <Heart className="w-4 h-4 mr-2 text-primary" />
                        Fysiske følelser
                      </h4>
                      <p className="text-muted-foreground bg-muted/30 p-3 rounded-2xl">
                        {todayEntry.physical_feelings}
                      </p>
                    </div>
                  )}
                  
                  {todayEntry.emotional_state && (
                    <div>
                      <h4 className="font-medium mb-2 flex items-center">
                        <Brain className="w-4 h-4 mr-2 text-accent" />
                        Følelsesmæssig tilstand
                      </h4>
                      <p className="text-muted-foreground bg-muted/30 p-3 rounded-2xl">
                        {todayEntry.emotional_state}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* AI Feedback from daily entry */}
              {todayEntry.ai_feedback && (
                <div className="p-4 bg-gradient-to-r from-primary/5 to-primary-glow/10 rounded-2xl border border-primary/20">
                  <h4 className="font-medium mb-2 text-primary flex items-center">
                    <Brain className="w-4 h-4 mr-2" />
                    AI feedback fra velbefindende
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {todayEntry.ai_feedback}
                  </p>
                </div>
              )}
            </>
          )}

          {/* AI Conversations */}
          {todayAIResponses.length > 0 && (
            <div>
              <h4 className="font-medium mb-3 flex items-center">
                <MessageSquare className="w-4 h-4 mr-2 text-primary" />
                AI samtaler ({todayAIResponses.length})
              </h4>
              <div className="space-y-3">
                {todayAIResponses.map((response, idx) => (
                  <div key={response.id} className="p-4 bg-gradient-to-r from-success/5 to-accent/5 rounded-2xl border border-success/20">
                    <div className="space-y-2">
                      <div>
                        <p className="font-medium text-sm mb-1">Dit spørgsmål:</p>
                        <p className="text-sm text-muted-foreground">
                          {response.question}
                        </p>
                      </div>
                      <div>
                        <p className="font-medium text-sm mb-1 text-success">AI's svar:</p>
                        <p className="text-sm text-muted-foreground">
                          {response.response.length > 200 
                            ? `${response.response.substring(0, 200)}...` 
                            : response.response
                          }
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}