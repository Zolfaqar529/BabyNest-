import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, TrendingUp, Heart, Brain, Zap } from 'lucide-react';
import { useSupabaseData } from '@/hooks/useSupabaseData';
import { format, subDays } from 'date-fns';

interface AnalyticsProps {
  onBack: () => void;
}

export default function Analytics({ onBack }: AnalyticsProps) {
  const { dailyEntries, loading, refreshData } = useSupabaseData();
  
  // Refresh data when component mounts to ensure latest data
  React.useEffect(() => {
    refreshData();
  }, []);

  // Prepare data for calculations only
  const prepareData = () => {
    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const date = subDays(new Date(), 29 - i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const entry = dailyEntries.find(e => e.date === dateStr);
      
      return {
        date: format(date, 'dd/MM'),
        fullDate: dateStr,
        energy: entry?.energy_level || null,
        mood: entry?.mood || null,
        sleep: entry?.sleep || null,
        sleep_quality: entry?.sleep_quality || null,
        stress: entry?.stress_level || null,
        nausea: entry?.nausea_level || null,
        weight: entry?.weight ? parseFloat(entry.weight) : null,
        hasData: !!entry,
        symptoms_count: entry?.symptoms?.length || 0
      };
    });

    return last30Days;
  };

  const prepareSymptomData = () => {
    const symptomCounts: { [key: string]: number } = {};
    
    dailyEntries.forEach(entry => {
      if (entry.symptoms) {
        entry.symptoms.forEach(symptom => {
          symptomCounts[symptom] = (symptomCounts[symptom] || 0) + 1;
        });
      }
    });

    return Object.entries(symptomCounts)
      .map(([symptom, count]) => ({ symptom, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  };

  const data = prepareData();
  const symptomData = prepareSymptomData();

  // Calculate averages
  const calculateAverage = (field: keyof typeof data[0]) => {
    const values = data
      .map(d => d[field])
      .filter(v => v !== null && typeof v === 'number') as number[];
    
    if (values.length === 0) return 0;
    return Math.round((values.reduce((sum, v) => sum + v, 0) / values.length) * 10) / 10;
  };

  const avgEnergy = calculateAverage('energy');
  const avgMood = calculateAverage('mood');
  const avgSleep = calculateAverage('sleep');
  const avgSleepQuality = calculateAverage('sleep_quality');
  const avgStress = calculateAverage('stress');
  const avgNausea = calculateAverage('nausea');
  
  // Calculate trends
  const recentData = data.slice(-7); // Last 7 days
  const olderData = data.slice(-14, -7); // Previous 7 days
  
  const getMoodTrend = () => {
    const recentAvg = recentData.filter(d => d.mood).reduce((sum, d) => sum + (d.mood || 0), 0) / recentData.filter(d => d.mood).length;
    const olderAvg = olderData.filter(d => d.mood).reduce((sum, d) => sum + (d.mood || 0), 0) / olderData.filter(d => d.mood).length;
    return recentAvg > olderAvg ? "forbedret" : recentAvg < olderAvg ? "forværret" : "stabilt";
  };
  
  const moodTrend = getMoodTrend();

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="h-8 w-32 bg-muted animate-pulse rounded"></div>
          </div>
          <div className="grid gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-64 bg-muted animate-pulse rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Indsigter</h1>
            <p className="text-sm text-muted-foreground">Dine gennemsnitsværdier og trends</p>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Zap className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Gennemsnitlig energi</p>
                  <p className="text-lg font-semibold">{avgEnergy}/10</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-accent/10 rounded-lg">
                  <Brain className="w-4 h-4 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Gennemsnitlig humør</p>
                  <p className="text-lg font-semibold">{avgMood}/10</p>
                  <p className="text-xs text-muted-foreground">Trend: {moodTrend}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-success/10 rounded-lg">
                  <Heart className="w-4 h-4 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Gennemsnitlig søvn</p>
                  <p className="text-lg font-semibold">{avgSleep}t</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-warning/10 rounded-lg">
                  <TrendingUp className="w-4 h-4 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Stress niveau</p>
                  <p className="text-lg font-semibold">{avgStress}/10</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Top Symptoms */}
        {symptomData.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-sm">
                <Heart className="w-4 h-4 mr-2 text-primary" />
                Hyppigste symptomer
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {symptomData.slice(0, 5).map((item, index) => (
                  <div key={item.symptom} className="flex justify-between items-center">
                    <span className="text-sm">{item.symptom}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-20 bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${(item.count / symptomData[0].count) * 100}%` }}
                        />
                      </div>
                      <span className="text-sm text-muted-foreground">{item.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {dailyEntries.length === 0 && !loading && (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">
                Ingen data tilgængelig endnu. Start med at logge dine daglige oplevelser for at se indsigter.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}