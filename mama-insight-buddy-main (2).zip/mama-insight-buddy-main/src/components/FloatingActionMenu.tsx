import { useState } from "react";
import { Plus, X, Heart, MessageCircle, Baby, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FloatingActionMenuProps {
  onNavigate: (page: string) => void;
}

export default function FloatingActionMenu({ onNavigate }: FloatingActionMenuProps) {
  const [isOpen, setIsOpen] = useState(false);

  const actions = [
    {
      label: "Log i dag",
      icon: Heart,
      action: () => onNavigate("daily-tracking"),
      color: "bg-primary/10 text-primary"
    },
    {
      label: "Stil AI-spørgsmål",
      icon: MessageCircle,
      action: () => onNavigate("chat"),
      color: "bg-accent/10 text-accent-foreground"
    },
    {
      label: "Se babyudvikling",
      icon: Baby,
      action: () => onNavigate("development"),
      color: "bg-success/10 text-success-foreground"
    },
    {
      label: "Se dine grafer",
      icon: TrendingUp,
      action: () => onNavigate("insights"),
      color: "bg-secondary/10 text-secondary-foreground"
    }
  ];

  const handleActionClick = (actionFn: () => void) => {
    actionFn();
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-32 right-6 z-50">
      {/* Action Items */}
      {isOpen && (
        <div className="mb-4 space-y-3 animate-fade-in">
          {actions.map((action, index) => (
            <div
              key={index}
              className="flex items-center gap-3 animate-scale-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <span className="text-xs font-medium text-muted-foreground bg-background/95 backdrop-blur-sm px-3 py-1.5 rounded-full border shadow-sm">
                {action.label}
              </span>
              <Button
                onClick={() => handleActionClick(action.action)}
                size="sm"
                className={`w-12 h-12 rounded-full shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105 ${action.color} border-0`}
              >
                <action.icon className="w-5 h-5" />
              </Button>
            </div>
          ))}
        </div>
      )}

      {/* Main FAB */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        size="lg"
        className="w-16 h-16 rounded-full bg-gradient-to-r from-primary to-primary-glow shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105"
      >
        {isOpen ? (
          <X className="w-8 h-8 transition-transform duration-200" />
        ) : (
          <Plus className="w-8 h-8 transition-transform duration-200" />
        )}
      </Button>
    </div>
  );
}