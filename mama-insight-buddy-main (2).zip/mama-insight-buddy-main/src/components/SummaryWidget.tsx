import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, CheckCircle } from 'lucide-react';
import { SummaryData } from '@/hooks/useOverviewData';

interface SummaryWidgetProps {
  data: SummaryData;
}

export function SummaryWidget({ data }: SummaryWidgetProps) {
  const getTrendIcon = (trend: 'improving' | 'declining' | 'stable') => {
    switch (trend) {
      case 'improving':
        return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'declining':
        return <TrendingDown className="w-4 h-4 text-red-500" />;
      default:
        return <Minus className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTrendText = (trend: 'improving' | 'declining' | 'stable') => {
    switch (trend) {
      case 'improving':
        return 'Forbedret';
      case 'declining':
        return 'Forværret';
      default:
        return 'Stabilt';
    }
  };

  const getTrendColor = (trend: 'improving' | 'declining' | 'stable') => {
    switch (trend) {
      case 'improving':
        return 'text-green-600';
      case 'declining':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <CheckCircle className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">Ugens opsummering</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Weekly Summary Text */}
        <div className="p-4 bg-muted/50 rounded-lg">
          <p className="text-sm leading-relaxed text-foreground">
            {data.weeklySummary}
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Mood Trend */}
          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Humør</span>
              <div className="flex items-center space-x-1">
                {getTrendIcon(data.moodTrend)}
                <span className={`text-xs font-medium ${getTrendColor(data.moodTrend)}`}>
                  {getTrendText(data.moodTrend)}
                </span>
              </div>
            </div>
            <div className="text-2xl font-bold">{data.averageMood}/10</div>
            <div className="text-xs text-muted-foreground">
              Gennemsnit sidste 7 dage
            </div>
          </div>

          {/* Energy Trend */}
          <div className="p-4 border rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Energi</span>
              <div className="flex items-center space-x-1">
                {getTrendIcon(data.energyTrend)}
                <span className={`text-xs font-medium ${getTrendColor(data.energyTrend)}`}>
                  {getTrendText(data.energyTrend)}
                </span>
              </div>
            </div>
            <div className="text-2xl font-bold">{data.averageEnergy}/10</div>
            <div className="text-xs text-muted-foreground">
              Gennemsnit sidste 7 dage
            </div>
          </div>
        </div>

        {/* Most Common Symptoms */}
        <div>
          <h4 className="text-sm font-medium mb-3">Mest rapporterede symptomer</h4>
          <div className="space-y-2">
            {data.mostCommonSymptoms.length > 0 ? (
              data.mostCommonSymptoms.map((symptom, index) => (
                <div key={symptom.symptom} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center">
                      <span className="text-xs font-medium text-primary">{index + 1}</span>
                    </div>
                    <span className="text-sm font-medium">{symptom.symptom}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground">
                      {symptom.count} {symptom.count === 1 ? 'gang' : 'gange'}
                    </span>
                    <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary transition-all duration-300"
                        style={{ 
                          width: `${Math.min((symptom.count / data.totalDays) * 100, 100)}%` 
                        }}
                      />
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-muted-foreground">
                <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-muted-foreground/50" />
                <p className="text-sm">Ingen symptomer registreret denne uge</p>
              </div>
            )}
          </div>
        </div>

        {/* Data Coverage */}
        <div className="p-4 bg-primary/5 rounded-lg">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Data dækning</span>
            <span className="text-sm text-muted-foreground">
              {data.daysWithData} af {data.totalDays} dage
            </span>
          </div>
          <div className="mt-2 w-full h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-primary transition-all duration-300"
              style={{ width: `${(data.daysWithData / data.totalDays) * 100}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {data.daysWithData >= 5 ? 'God dækning' : data.daysWithData >= 3 ? 'Moderat dækning' : 'Lav dækning'}
          </p>
        </div>
      </CardContent>
    </Card>
  );
} 
