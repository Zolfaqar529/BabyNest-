import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, ArrowRight, Heart, Baby, User, Mail, Calendar, CheckCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/auth/AuthProvider";
import { useToast } from "@/hooks/use-toast";

interface OnboardingFlowProps {
  userType: 'expecting' | 'hasChild';
  onComplete: () => void;
  onBack: () => void;
}

interface OnboardingData {
  babyName: string;
  userName: string;
  email: string;
  password: string;
  birthDate: string;
  dueDate: string;
  gender: string;
  consentAccepted: boolean;
}

export default function OnboardingFlow({ userType, onComplete, onBack }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const { signUp, signIn } = useAuth();
  const { toast } = useToast();
  
  const [data, setData] = useState<OnboardingData>({
    babyName: "",
    userName: "",
    email: "",
    password: "",
    birthDate: "",
    dueDate: "",
    gender: "",
    consentAccepted: false,
  });

  const totalSteps = 5;
  const isExpecting = userType === 'expecting';

  const updateData = (field: keyof OnboardingData, value: string | boolean) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const validateStep = () => {
    switch (currentStep) {
      case 1:
        return data.babyName.trim().length > 0;
      case 2:
        return data.userName.trim().length > 0;
      case 3:
        return data.email.trim().length > 0 && data.password.length >= 6;
      case 4:
        return isExpecting ? data.dueDate.length > 0 : data.birthDate.length > 0;
      case 5:
        return data.consentAccepted;
      default:
        return false;
    }
  };

  const handleComplete = async () => {
    if (!validateStep()) return;

    setLoading(true);

    try {
      // 1. Try to create user account, or sign in if exists
      let user = null;
      const { error: signUpError } = await signUp(data.email, data.password);
      
      if (signUpError) {
        console.error('SignUp error:', signUpError);
        
        if (signUpError.message?.includes("User already registered") || 
            signUpError.message?.includes("already registered") ||
            signUpError.message?.includes("user_repeated_signup")) {
          // User exists, try to sign in instead
          const { error: signInError } = await signIn(data.email, data.password);
          
          if (signInError) {
            if (signInError.message?.includes("Invalid login credentials")) {
              toast({
                title: "Login fejl",
                description: "Email findes allerede med en anden adgangskode. Prøv med den rigtige adgangskode eller brug en anden email.",
                variant: "destructive",
              });
            } else {
              toast({
                title: "Login fejl", 
                description: signInError.message,
                variant: "destructive",
              });
            }
            setLoading(false);
            return;
          }
          
          // Wait for auth state to update after sign in
          await new Promise(resolve => setTimeout(resolve, 1500));
        } else if (signUpError.message?.includes("rate limit") || 
                   signUpError.message?.includes("too many")) {
          toast({
            title: "Vent venligst",
            description: "Du har forsøgt for mange gange. Vent et øjeblik og prøv igen.",
            variant: "destructive",
          });
          setLoading(false);
          return;
        } else {
          toast({
            title: "Fejl ved oprettelse af bruger",
            description: signUpError.message,
            variant: "destructive",
          });
          setLoading(false);
          return;
        }
      } else {
        // New user created, wait for confirmation/auth state
        await new Promise(resolve => setTimeout(resolve, 2000));
      }

      // 2. Get the current session to ensure we have the user
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.user) {
        toast({
          title: "Der opstod en fejl",
          description: "Kunne ikke oprette din bruger. Prøv igen eller kontakt support.",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      user = session.user;

      // 3. Check if profile already exists (for existing users)
      const { data: existingProfile } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!existingProfile) {
        // Create profile only if it doesn't exist
        const { error: profileError } = await supabase
          .from('profiles')
          .insert({
            user_id: user.id,
            user_name: data.userName,
            email: data.email,
          });

        if (profileError) {
          console.error('Profile creation error:', profileError);
          toast({
            title: "Fejl ved oprettelse af profil",
            description: `Database fejl: ${profileError.message}`,
            variant: "destructive",
          });
          setLoading(false);
          return;
        }
      }

      // 4. Check if baby record already exists
      const { data: existingBaby } = await supabase
        .from('babies')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!existingBaby) {
        // Create baby record only if it doesn't exist
        const { error: babyError } = await supabase
          .from('babies')
          .insert({
            user_id: user.id,
            baby_name: data.babyName,
            birth_date: isExpecting ? null : data.birthDate,
            due_date: isExpecting ? data.dueDate : null,
            gender: data.gender || null,
            is_expecting: isExpecting,
          });

        if (babyError) {
          console.error('Baby creation error:', babyError);
          toast({
            title: "Fejl ved oprettelse af barn",
            description: "Der opstod en fejl ved oprettelse af barnets oplysninger",
            variant: "destructive",
          });
          setLoading(false);
          return;
        }
      }

      toast({
        title: "Velkommen til BabyNest+!",
        description: "Din profil er oprettet succesfuldt",
      });

      onComplete();
    } catch (error) {
      console.error('Onboarding error:', error);
      toast({
        title: "Fejl",
        description: "Der opstod en uventet fejl. Prøv igen.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Baby className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-xl font-playfair font-medium mb-2">
                Hvad skal dit barn hedde?
              </h2>
              <p className="text-muted-foreground text-sm">
                {isExpecting ? "Hvad tænker I at barnet skal hedde?" : "Hvad hedder dit barn?"}
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="babyName">Barnets navn</Label>
              <Input
                id="babyName"
                value={data.babyName}
                onChange={(e) => updateData('babyName', e.target.value)}
                placeholder="Skriv barnets navn"
                className="text-center text-lg"
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <User className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-xl font-playfair font-medium mb-2">
                Hvad hedder du?
              </h2>
              <p className="text-muted-foreground text-sm">
                Dit navn bruges til at personalisere din oplevelse
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="userName">Dit navn</Label>
              <Input
                id="userName"
                value={data.userName}
                onChange={(e) => updateData('userName', e.target.value)}
                placeholder="Skriv dit navn"
                className="text-center text-lg"
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Mail className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-xl font-playfair font-medium mb-2">
                Opret din konto
              </h2>
              <p className="text-muted-foreground text-sm">
                Vi skal bruge din email og en adgangskode
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={data.email}
                  onChange={(e) => updateData('email', e.target.value)}
                  placeholder="din@email.dk"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Adgangskode</Label>
                <Input
                  id="password"
                  type="password"
                  value={data.password}
                  onChange={(e) => updateData('password', e.target.value)}
                  placeholder="••••••••"
                  minLength={6}
                />
                <p className="text-xs text-muted-foreground">Mindst 6 tegn</p>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <Calendar className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-xl font-playfair font-medium mb-2">
                {isExpecting ? "Hvornår er terminen?" : "Hvornår blev barnet født?"}
              </h2>
              <p className="text-muted-foreground text-sm">
                Dette hjælper os med at give dig den rette vejledning
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="date">
                  {isExpecting ? "Termin" : "Fødselsdato"}
                </Label>
                <Input
                  id="date"
                  type="date"
                  value={isExpecting ? data.dueDate : data.birthDate}
                  onChange={(e) => updateData(isExpecting ? 'dueDate' : 'birthDate', e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="gender">Barnets køn (valgfri)</Label>
                <Select onValueChange={(value) => updateData('gender', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg køn" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dreng">Dreng</SelectItem>
                    <SelectItem value="pige">Pige</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <CheckCircle className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-xl font-playfair font-medium mb-2">
                Næsten færdig!
              </h2>
              <p className="text-muted-foreground text-sm">
                Gennemgå og godkend din information
              </p>
            </div>
            
            <div className="space-y-4 p-4 bg-muted/30 rounded-lg">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Barn:</span>
                <span className="text-sm font-medium">{data.babyName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Dit navn:</span>
                <span className="text-sm font-medium">{data.userName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Email:</span>
                <span className="text-sm font-medium">{data.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">
                  {isExpecting ? "Termin:" : "Fødselsdato:"}
                </span>
                <span className="text-sm font-medium">
                  {isExpecting ? data.dueDate : data.birthDate}
                </span>
              </div>
              {data.gender && (
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Køn:</span>
                  <span className="text-sm font-medium capitalize">{data.gender}</span>
                </div>
              )}
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start space-x-2">
                <Checkbox
                  id="consent"
                  checked={data.consentAccepted}
                  onCheckedChange={(checked) => updateData('consentAccepted', !!checked)}
                />
                <Label htmlFor="consent" className="text-sm leading-relaxed">
                  Jeg godkender{" "}
                  <button className="text-primary hover:underline">
                    brugervilkårene
                  </button>
                  {" "}og{" "}
                  <button className="text-primary hover:underline">
                    privatlivspolitikken
                  </button>
                  {" "}for BabyNest+
                </Label>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-accent/10 p-4">
      <div className="max-w-sm mx-auto min-h-screen flex flex-col">
        
        {/* Header */}
        <div className="pt-8 pb-6">
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={currentStep === 1 ? onBack : prevStep}
              className="p-2 hover:bg-muted/50"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-12 h-12 rounded-full bg-gradient-to-r from-primary to-primary-glow flex items-center justify-center shadow-warm">
              <Heart className="w-6 h-6 text-primary-foreground fill-primary-foreground" />
            </div>
            <h1 className="text-2xl font-playfair font-bold text-foreground">
              BabyNest<span className="text-primary">+</span>
            </h1>
          </div>
          
          {/* Progress bar */}
          <div className="w-full bg-muted/30 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-primary to-primary-glow h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / totalSteps) * 100}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            Trin {currentStep} af {totalSteps}
          </p>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col justify-center">
          <Card className="border-border/50 shadow-warm">
            <CardContent className="p-6">
              {renderStepContent()}
            </CardContent>
          </Card>
        </div>

        {/* Navigation */}
        <div className="py-6">
          <div className="flex gap-3">
            {currentStep > 1 && (
              <Button 
                variant="outline" 
                onClick={prevStep}
                className="flex-1"
              >
                Tilbage
              </Button>
            )}
            
            {currentStep < totalSteps ? (
              <Button 
                onClick={nextStep}
                disabled={!validateStep()}
                className="flex-1"
              >
                Næste
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button 
                onClick={handleComplete}
                disabled={!validateStep() || loading}
                className="flex-1"
              >
                {loading ? "Opretter..." : "Fuldfør"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}