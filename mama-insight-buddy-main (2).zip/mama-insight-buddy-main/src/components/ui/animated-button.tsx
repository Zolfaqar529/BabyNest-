import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface AnimatedButtonProps extends React.ComponentProps<typeof Button> {
  onSave?: () => Promise<void> | void;
  children: React.ReactNode;
  successMessage?: string;
}

export function AnimatedButton({ 
  onSave, 
  children, 
  successMessage = "Ændringer gemt!",
  className,
  disabled,
  ...props 
}: AnimatedButtonProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const { toast } = useToast();

  const handleClick = async () => {
    if (!onSave || disabled) return;

    setIsLoading(true);
    try {
      await onSave();
      setShowSuccess(true);
      
      // Show toast notification
      toast({
        title: "✅ Gemt!",
        description: successMessage,
        duration: 3000,
      });
      
      setTimeout(() => setShowSuccess(false), 2000);
    } catch (error) {
      console.error('Save error:', error);
      
      // Show error toast
      toast({
        title: "❌ Fejl",
        description: "Der opstod en fejl ved gemning.",
        variant: "destructive",
        duration: 4000,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button
      {...props}
      onClick={handleClick}
      disabled={disabled || isLoading}
      className={cn(
        "relative overflow-hidden transition-all duration-300",
        showSuccess && "bg-success hover:bg-success text-success-foreground",
        className
      )}
    >
      <span 
        className={cn(
          "flex items-center justify-center transition-all duration-300",
          showSuccess && "scale-110"
        )}
      >
        {showSuccess ? (
          <>
            <Check className="w-4 h-4 mr-2" />
            {successMessage}
          </>
        ) : isLoading ? (
          "Gemmer..."
        ) : (
          children
        )}
      </span>
      
      {showSuccess && (
        <div className="absolute inset-0 bg-gradient-to-r from-success/20 via-success/40 to-success/20 animate-ping" />
      )}
    </Button>
  );
}