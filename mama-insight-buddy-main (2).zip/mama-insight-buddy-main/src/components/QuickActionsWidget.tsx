import { Heart, MessageCircle, Baby, TrendingUp } from "lucide-react";

interface QuickActionsWidgetProps {
  onNavigate: (page: string) => void;
}

export default function QuickActionsWidget({ onNavigate }: QuickActionsWidgetProps) {
  const quickActions = [
    {
      label: "Log i dag",
      icon: Heart,
      action: () => onNavigate("daily-tracking"),
      color: "bg-pink-50 hover:bg-pink-100 border-pink-200 text-pink-600"
    },
    {
      label: "Stil AI-spørgsmål",
      icon: MessageCircle,
      action: () => onNavigate("chat"),
      color: "bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-600"
    },
    {
      label: "Se babyudvikling",
      icon: Baby,
      action: () => onNavigate("development"),
      color: "bg-green-50 hover:bg-green-100 border-green-200 text-green-600"
    },
    {
      label: "Se dine grafer",
      icon: TrendingUp,
      action: () => onNavigate("insights"),
      color: "bg-purple-50 hover:bg-purple-100 border-purple-200 text-purple-600"
    }
  ];

  return (
    <div className="grid grid-cols-4 gap-3">
      {quickActions.map((action, index) => (
        <button
          key={index}
          onClick={action.action}
          className="flex flex-col items-center space-y-1.5 group"
        >
          <div className={`w-10 h-10 rounded-full ${action.color} border flex items-center justify-center transition-all duration-200 hover:scale-105 shadow-sm`}>
            <action.icon className="w-4 h-4" />
          </div>
          <span className="text-xs font-medium text-center text-muted-foreground leading-tight">
            {action.label}
          </span>
        </button>
      ))}
    </div>
  );
}