import { Droplet, Calendar } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface CombinedReminderWidgetProps {
  currentWeek: number;
  babySize: string;
  isPostpartum: boolean;
  hasLoggedToday: boolean;
}

export default function CombinedReminderWidget({ 
  currentWeek, 
  babySize, 
  isPostpartum, 
  hasLoggedToday 
}: CombinedReminderWidgetProps) {
  const weekMessage = isPostpartum 
    ? `Du er i uge ${currentWeek} efter fødslen`
    : `Du er i uge ${currentWeek} – din baby er cirka på størrelse med ${babySize}`;

  return (
    <Card className="nordic-card-soft border-0">
      <CardContent className="p-4 space-y-3">
        {/* Week Info */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/5 flex items-center justify-center">
            <Calendar className="w-4 h-4 text-primary/70" />
          </div>
          <p className="text-sm font-normal text-foreground/80 leading-relaxed">
            {weekMessage}
          </p>
        </div>

        {/* Water Reminder */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-blue-500/5 flex items-center justify-center">
            <Droplet className="w-4 h-4 text-blue-500/70" />
          </div>
          <p className="text-sm font-normal text-foreground/80 leading-relaxed">
            Husk at drikke nok vand i dag 💧
          </p>
        </div>
      </CardContent>
    </Card>
  );
}