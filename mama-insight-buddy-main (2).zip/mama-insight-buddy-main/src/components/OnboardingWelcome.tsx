import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Heart, Smile } from "lucide-react";

interface OnboardingWelcomeProps {
  onUserChoice: (choice: 'expecting' | 'hasChild') => void;
  onLoginRequest: () => void;
}

export default function OnboardingWelcome({ onUserChoice, onLoginRequest }: OnboardingWelcomeProps) {
  const [selectedChoice, setSelectedChoice] = useState<'expecting' | 'hasChild' | null>(null);

  const handleChoiceSelect = (choice: 'expecting' | 'hasChild') => {
    setSelectedChoice(choice);
    // Small delay for visual feedback before proceeding
    setTimeout(() => {
      onUserChoice(choice);
    }, 150);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-accent/10 p-4">
      <div className="max-w-sm mx-auto min-h-screen flex flex-col">
        
        {/* Main Content */}
        <div className="flex-1 flex flex-col justify-center space-y-12 py-8">
          
          {/* App Logo with Heart Icon */}
          <div className="text-center space-y-6">
            <div className="animate-float">
              <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-primary to-primary-glow flex items-center justify-center shadow-warm">
                <Heart className="w-10 h-10 text-primary-foreground fill-primary-foreground" />
              </div>
              <h1 className="text-4xl font-playfair font-bold text-foreground tracking-tight">
                BabyNest<span className="text-primary">+</span>
              </h1>
            </div>
            <p className="text-lg text-muted-foreground font-nunito leading-relaxed px-4">
              Din personlige følgesvend gennem moderrejsen
            </p>
          </div>

          {/* Main Question */}
          <div className="text-center space-y-8">
            <h2 className="text-2xl font-playfair font-medium text-foreground px-4">
              Hvilket udsagn passer bedst?
            </h2>

            {/* Choice Buttons */}
            <div className="space-y-4 px-2">
              {/* Primary Choice - Expecting */}
              <Button
                variant="default"
                size="lg"
                className={`w-full h-16 text-left justify-start gap-4 text-lg font-medium ${
                  selectedChoice === 'expecting' ? 'ring-2 ring-primary/50 scale-105' : ''
                }`}
                onClick={() => handleChoiceSelect('expecting')}
              >
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                  <Smile className="w-5 h-5 text-primary-foreground" />
                </div>
                <span>JEG VENTER BARN</span>
              </Button>

              {/* Secondary Choice - Has Child */}
              <Button
                variant="outline"
                size="lg" 
                className={`w-full h-16 text-left justify-start gap-4 text-lg font-medium ${
                  selectedChoice === 'hasChild' ? 'ring-2 ring-primary/50 scale-105' : ''
                }`}
                onClick={() => handleChoiceSelect('hasChild')}
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Heart className="w-5 h-5 text-primary" />
                </div>
                <span>JEG HAR ET BARN</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Login and Footer Section */}
        <div className="space-y-6 pb-8">
          {/* Login Section */}
          <div className="text-center space-y-4">
            <p className="text-lg text-foreground font-nunito font-medium">
              Har du allerede en konto?
            </p>
            <button
              onClick={onLoginRequest}
              className="text-xl font-medium text-foreground hover:text-primary transition-colors duration-200 underline underline-offset-4"
            >
              Log ind her
            </button>
          </div>


          {/* Footer */}
          <div className="text-center">
            <p className="text-xs text-muted-foreground/70 font-nunito leading-relaxed px-4">
              Ved at anvende BabyNest+ godkender du vores{" "}
              <button className="text-muted-foreground hover:text-foreground transition-colors underline underline-offset-2">
                brugervilkår
              </button>
              {" "}og{" "}
              <button className="text-muted-foreground hover:text-foreground transition-colors underline underline-offset-2">
                privatlivspolitik
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
