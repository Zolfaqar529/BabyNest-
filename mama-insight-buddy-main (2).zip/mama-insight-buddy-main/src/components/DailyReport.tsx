import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AIService, UserContext } from "@/lib/aiService";
import { 
  Calendar,
  Heart,
  Moon,
  Activity,
  Scale,
  Brain,
  MessageSquare,
  Trash2,
  ChevronLeft,
  ChevronRight
} from "lucide-react";

interface DailyData {
  date: string;
  mood?: number;
  energy?: number;
  sleep?: number;
  symptoms?: string[];
  weight?: string;
  exercise?: string;
  notes?: string;
  physicalSymptoms?: string[];
  emotionalState?: string[];
  comment?: string;
  aiResponse?: string;
  weeklyNotes?: string[];
  chatMessages?: any[];
}

interface DailyReportProps {
  userProfile: UserContext;
}

export default function DailyReport({ userProfile }: DailyReportProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [dailyData, setDailyData] = useState<DailyData | null>(null);
  const [allData, setAllData] = useState<DailyData[]>([]);

  useEffect(() => {
    loadAllData();
  }, []);

  useEffect(() => {
    const dayData = getAllDataForDate(selectedDate);
    setDailyData(dayData);
  }, [selectedDate, allData]);

  const loadAllData = () => {
    // Load all data sources
    const trackingData = JSON.parse(localStorage.getItem("babynest_history") || "[]");
    const wellbeingData = JSON.parse(localStorage.getItem("babynest_wellbeing") || "[]");
    const chatData = JSON.parse(localStorage.getItem("babynest_chat") || "[]");
    const weeklyNotes = JSON.parse(localStorage.getItem("babynest_weekly_notes") || "[]");

    // Combine all data by date
    const combinedData: Record<string, DailyData> = {};

    trackingData.forEach((entry: any) => {
      const date = entry.date;
      if (!combinedData[date]) combinedData[date] = { date };
      combinedData[date] = { ...combinedData[date], ...entry };
    });

    wellbeingData.forEach((entry: any) => {
      const date = entry.date;
      if (!combinedData[date]) combinedData[date] = { date };
      combinedData[date] = { ...combinedData[date], ...entry };
    });

    weeklyNotes.forEach((note: any) => {
      const date = note.date;
      if (!combinedData[date]) combinedData[date] = { date };
      if (!combinedData[date].weeklyNotes) combinedData[date].weeklyNotes = [];
      combinedData[date].weeklyNotes!.push(note.note);
    });

    // Group chat messages by date
    const chatByDate: Record<string, any[]> = {};
    chatData.forEach((message: any) => {
      const date = new Date(message.timestamp).toISOString().split('T')[0];
      if (!chatByDate[date]) chatByDate[date] = [];
      chatByDate[date].push(message);
    });

    Object.entries(chatByDate).forEach(([date, messages]) => {
      if (!combinedData[date]) combinedData[date] = { date };
      combinedData[date].chatMessages = messages;
    });

    const dataArray = Object.values(combinedData).sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    setAllData(dataArray);
  };

  const getAllDataForDate = (date: string): DailyData | null => {
    return allData.find(entry => entry.date === date) || null;
  };

  const deleteDataForDate = (date: string, dataType: string) => {
    switch (dataType) {
      case 'tracking':
        const trackingData = JSON.parse(localStorage.getItem("babynest_history") || "[]");
        const updatedTracking = trackingData.filter((entry: any) => entry.date !== date);
        localStorage.setItem("babynest_history", JSON.stringify(updatedTracking));
        break;
      case 'wellbeing':
        const wellbeingData = JSON.parse(localStorage.getItem("babynest_wellbeing") || "[]");
        const updatedWellbeing = wellbeingData.filter((entry: any) => entry.date !== date);
        localStorage.setItem("babynest_wellbeing", JSON.stringify(updatedWellbeing));
        break;
      case 'weekly_notes':
        const weeklyNotes = JSON.parse(localStorage.getItem("babynest_weekly_notes") || "[]");
        const updatedNotes = weeklyNotes.filter((entry: any) => entry.date !== date);
        localStorage.setItem("babynest_weekly_notes", JSON.stringify(updatedNotes));
        break;
    }
    loadAllData();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("da-DK", { 
      weekday: "long", 
      year: "numeric", 
      month: "long", 
      day: "numeric" 
    });
  };

  const navigateDate = (direction: 'prev' | 'next') => {
    const currentDate = new Date(selectedDate);
    const newDate = new Date(currentDate);
    newDate.setDate(currentDate.getDate() + (direction === 'next' ? 1 : -1));
    setSelectedDate(newDate.toISOString().split('T')[0]);
  };

  const generateAISummary = (data: DailyData): string => {
    if (!data || Object.keys(data).length <= 1) return "";
    
    // Convert to AIService DailyData format
    const aiData = {
      date: data.date,
      mood: data.mood || 5,
      energy: data.energy || 5,
      sleep: data.sleep || 7,
      symptoms: data.symptoms || [],
      notes: data.notes || '',
      weight: data.weight,
      exercise: data.exercise
    };
    
    const summary = AIService.generateDiarySummary([aiData], userProfile);
    return summary || `${userProfile.motherName}, denne dag havde du registreret forskellige data om dit velbefindende.`;
  };

  const getMoodIcon = (mood: number) => {
    if (mood <= 3) return "😔";
    if (mood <= 7) return "😐";
    return "😊";
  };

  const hasDataForDate = (data: DailyData | null): boolean => {
    if (!data) return false;
    const { date, ...rest } = data;
    return Object.keys(rest).length > 0;
  };

  return (
    <div className="w-full space-y-3">
      {/* Date Navigation */}
      <Card>
        <CardHeader className="p-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center text-sm">
              <Calendar className="w-4 h-4 mr-2 text-primary" />
              Daglig rapport
            </CardTitle>
            <div className="flex items-center space-x-1">
              <Button variant="outline" size="sm" onClick={() => navigateDate('prev')} className="h-7 w-7 p-0">
                <ChevronLeft className="w-3 h-3" />
              </Button>
              <div className="text-center min-w-[140px] px-2">
                <p className="font-medium text-xs leading-tight">{formatDate(selectedDate)}</p>
                <p className="text-xs text-muted-foreground">
                  {selectedDate === new Date().toISOString().split('T')[0] ? "I dag" : 
                   new Date(selectedDate) > new Date() ? "Fremtid" : ""}
                </p>
              </div>
              <Button variant="outline" size="sm" onClick={() => navigateDate('next')} className="h-7 w-7 p-0">
                <ChevronRight className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Daily Data Display */}
      {!hasDataForDate(dailyData) ? (
        <Card>
          <CardContent className="p-6 text-center">
            <Calendar className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
            <h3 className="text-sm font-medium mb-2">Ingen data for denne dag</h3>
            <p className="text-xs text-muted-foreground">
              Der er ikke registreret nogen data for {formatDate(selectedDate)}.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {/* AI Summary */}
          {dailyData && (
            <Card className="border-primary/20">
              <CardHeader className="p-3">
                <CardTitle className="flex items-center text-primary text-sm">
                  <Brain className="w-4 h-4 mr-2" />
                  AI Sammenfatning
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3">
                <p className="text-xs text-muted-foreground bg-primary/5 p-3 rounded-lg">
                  {generateAISummary(dailyData)}
                </p>
              </CardContent>
            </Card>
          )}

          {/* Tracking Data */}
          {(dailyData?.mood || dailyData?.energy || dailyData?.sleep) && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between p-3">
                <CardTitle className="flex items-center text-sm">
                  <Activity className="w-4 h-4 mr-2 text-primary" />
                  Daglig tracking
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteDataForDate(selectedDate, 'tracking')}
                  className="text-muted-foreground hover:text-destructive h-6 w-6 p-0"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </CardHeader>
              <CardContent className="p-3">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {dailyData.mood && (
                    <div className="flex items-center space-x-2 p-3 bg-muted/50 rounded-lg">
                      <span className="text-lg">{getMoodIcon(dailyData.mood)}</span>
                      <div>
                        <p className="text-sm text-muted-foreground">Humør</p>
                        <p className="font-medium">{dailyData.mood}/10</p>
                      </div>
                    </div>
                  )}
                  
                  {dailyData.energy && (
                    <div className="flex items-center space-x-2 p-3 bg-muted/50 rounded-lg">
                      <Activity className="w-4 h-4 text-success" />
                      <div>
                        <p className="text-sm text-muted-foreground">Energi</p>
                        <p className="font-medium">{dailyData.energy}/10</p>
                      </div>
                    </div>
                  )}
                  
                  {dailyData.sleep && (
                    <div className="flex items-center space-x-2 p-3 bg-muted/50 rounded-lg">
                      <Moon className="w-4 h-4 text-accent" />
                      <div>
                        <p className="text-sm text-muted-foreground">Søvn</p>
                        <p className="font-medium">{dailyData.sleep}t</p>
                      </div>
                    </div>
                  )}
                  
                  {dailyData.weight && (
                    <div className="flex items-center space-x-2 p-3 bg-muted/50 rounded-lg">
                      <Scale className="w-4 h-4 text-warning" />
                      <div>
                        <p className="text-sm text-muted-foreground">Vægt</p>
                        <p className="font-medium">{dailyData.weight}kg</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Symptoms */}
                {dailyData.symptoms && dailyData.symptoms.length > 0 && (
                  <div className="mt-4">
                    <p className="font-medium mb-2">Symptomer:</p>
                    <div className="flex flex-wrap gap-2">
                      {dailyData.symptoms.map((symptom, idx) => (
                        <Badge key={idx} variant="secondary">
                          {symptom}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Exercise & Notes */}
                {dailyData.exercise && (
                  <div className="mt-4">
                    <p className="font-medium mb-1">Aktivitet:</p>
                    <p className="text-muted-foreground">{dailyData.exercise}</p>
                  </div>
                )}

                {dailyData.notes && (
                  <div className="mt-4">
                    <p className="font-medium mb-1">Dagbog:</p>
                    <p className="text-muted-foreground bg-muted/30 p-3 rounded-lg">
                      {dailyData.notes}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Wellbeing Data */}
          {(dailyData?.physicalSymptoms || dailyData?.emotionalState) && (
            <Card className="border-success/20">
              <CardHeader className="flex flex-row items-center justify-between p-3">
                <CardTitle className="flex items-center text-sm">
                  <Heart className="w-4 h-4 mr-2 text-success" />
                  Velbefindende
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteDataForDate(selectedDate, 'wellbeing')}
                  className="text-muted-foreground hover:text-destructive h-6 w-6 p-0"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </CardHeader>
              <CardContent className="p-3 space-y-3">
                {dailyData.physicalSymptoms && dailyData.physicalSymptoms.length > 0 && (
                  <div>
                    <p className="font-medium mb-2 text-sm">Kropsfornemmelser:</p>
                    <div className="flex flex-wrap gap-2">
                      {dailyData.physicalSymptoms.map((symptom, idx) => (
                        <Badge key={idx} variant="outline" className="border-primary/20 text-primary">
                          {symptom}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {dailyData.emotionalState && dailyData.emotionalState.length > 0 && (
                  <div>
                    <p className="font-medium mb-2">Følelsesmæssigt:</p>
                    <div className="flex flex-wrap gap-2">
                      {dailyData.emotionalState.map((emotion, idx) => (
                        <Badge key={idx} variant="outline" className="border-accent/20 text-accent">
                          {emotion}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {dailyData.comment && (
                  <div>
                    <p className="font-medium mb-1">Dine tanker:</p>
                    <p className="text-muted-foreground bg-muted/30 p-3 rounded-lg">
                      {dailyData.comment}
                    </p>
                  </div>
                )}

                {dailyData.aiResponse && (
                  <div className="p-3 bg-gradient-to-r from-success/5 to-accent/5 rounded-lg border border-success/20">
                    <p className="font-medium mb-1 text-success">AI Rådgiver:</p>
                    <p className="text-sm text-muted-foreground">{dailyData.aiResponse}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Weekly Notes */}
          {dailyData?.weeklyNotes && dailyData.weeklyNotes.length > 0 && (
            <Card className="border-accent/20">
              <CardHeader className="flex flex-row items-center justify-between p-3">
                <CardTitle className="flex items-center text-sm">
                  <MessageSquare className="w-4 h-4 mr-2 text-accent" />
                  Ugentlige noter
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteDataForDate(selectedDate, 'weekly_notes')}
                  className="text-muted-foreground hover:text-destructive h-6 w-6 p-0"
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </CardHeader>
              <CardContent className="p-3">
                <div className="space-y-2">
                  {dailyData.weeklyNotes.map((note, idx) => (
                    <p key={idx} className="text-xs text-muted-foreground bg-accent/5 p-3 rounded-lg">
                      {note}
                    </p>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Chat Messages */}
          {dailyData?.chatMessages && dailyData.chatMessages.length > 0 && (
            <Card className="border-warning/20">
              <CardHeader className="p-3">
                <CardTitle className="flex items-center text-sm">
                  <MessageSquare className="w-4 h-4 mr-2 text-warning" />
                  AI Samtaler ({dailyData.chatMessages.length} beskeder)
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3">
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {dailyData.chatMessages.map((message, idx) => (
                    <div
                      key={idx}
                      className={`p-2 rounded-lg text-sm ${
                        message.isUser 
                          ? "bg-primary/10 text-right" 
                          : "bg-muted/50"
                      }`}
                    >
                      <p className="text-xs text-muted-foreground mb-1">
                        {message.isUser ? "Dig" : "AI"} - {
                          new Date(message.timestamp).toLocaleTimeString("da-DK", {
                            hour: "2-digit",
                            minute: "2-digit"
                          })
                        }
                      </p>
                      <p>{message.text}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}