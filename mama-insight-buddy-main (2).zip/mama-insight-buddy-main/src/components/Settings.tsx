import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  ArrowLeft, 
  Bell, 
  Palette, 
  Globe, 
  Info,
  ExternalLink,
  Mail
} from 'lucide-react';

interface SettingsProps {
  onBack: () => void;
}

export default function Settings({ onBack }: SettingsProps) {
  const [notifications, setNotifications] = useState({
    dailyReminder: true,
    weeklyUpdate: false,
  });

  const [theme, setTheme] = useState('system');
  const [language, setLanguage] = useState('da');

  const handleNotificationChange = (key: keyof typeof notifications, value: boolean) => {
    setNotifications(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold">Indstillinger</h1>
            <p className="text-sm text-muted-foreground">Tilpas app-præferencer og visning</p>
          </div>
        </div>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Bell className="w-4 h-4 mr-2 text-primary" />
              Notifikationer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="daily-reminder">Daglig påmindelse</Label>
                <p className="text-sm text-muted-foreground">
                  Modtag påmindelse om at logge dine data hver dag
                </p>
              </div>
              <Switch
                id="daily-reminder"
                checked={notifications.dailyReminder}
                onCheckedChange={(checked) => handleNotificationChange('dailyReminder', checked)}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="weekly-update">Ugentlig opdatering</Label>
                <p className="text-sm text-muted-foreground">
                  Få ugentlige sammendrag af din graviditet
                </p>
              </div>
              <Switch
                id="weekly-update"
                checked={notifications.weeklyUpdate}
                onCheckedChange={(checked) => handleNotificationChange('weeklyUpdate', checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Visual Preferences */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Palette className="w-4 h-4 mr-2 text-accent" />
              Visuelle præferencer
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="theme">Tema</Label>
              <Select value={theme} onValueChange={setTheme}>
                <SelectTrigger>
                  <SelectValue placeholder="Vælg tema" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Lyst</SelectItem>
                  <SelectItem value="dark">Mørkt</SelectItem>
                  <SelectItem value="system">System (automatisk)</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground">
                Vælg dit foretrukne farvetema for appen
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Language */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Globe className="w-4 h-4 mr-2 text-success" />
              Sprog
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="language">App-sprog</Label>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger>
                  <SelectValue placeholder="Vælg sprog" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="da">Dansk</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground">
                Vælg dit foretrukne sprog for appen
              </p>
            </div>
          </CardContent>
        </Card>

        {/* App Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-sm">
              <Info className="w-4 h-4 mr-2 text-warning" />
              App-information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">App-version</span>
              <span className="text-sm text-muted-foreground">1.0.0</span>
            </div>
            
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start" asChild>
                <a href="#" className="flex items-center">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Vilkår og betingelser
                </a>
              </Button>
              
              <Button variant="outline" className="w-full justify-start" asChild>
                <a href="#" className="flex items-center">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Privatlivspolitik
                </a>
              </Button>
              
              <Button variant="outline" className="w-full justify-start" asChild>
                <a href="mailto:support@graviditetsapp.dk" className="flex items-center">
                  <Mail className="w-4 h-4 mr-2" />
                  Kontakt support
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Note about functionality */}
        <Card className="bg-muted/30">
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground text-center">
              Visse funktioner er under udvikling og vil blive tilgængelige i fremtidige opdateringer.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}