import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Heart, X } from "lucide-react";

interface WelcomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  userName: string;
}

export default function WelcomeModal({ isOpen, onClose, userName }: WelcomeModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-sm mx-auto bg-gradient-to-br from-warm-beige to-warm-sand border-border/20 shadow-xl" aria-describedby="welcome-description">
        <DialogHeader className="relative">
          <div className="text-center pt-4">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-primary to-primary-glow flex items-center justify-center shadow-warm">
              <Heart className="w-8 h-8 text-primary-foreground fill-primary-foreground" />
            </div>
            
            <DialogTitle className="text-lg font-playfair font-medium text-warm-text mb-2">
              Velkommen til, {userName}! 🎉
            </DialogTitle>
          </div>
        </DialogHeader>
        
        <div id="welcome-description" className="text-center space-y-4 pb-2">
          <p className="text-warm-text/80 leading-relaxed font-nunito">
            Vi glæder os til at følge dig og din babys rejse uge for uge. 
          </p>
          
          <p className="text-warm-text/80 leading-relaxed font-nunito">
            Husk at tjekke dine daglige rapporter og AI-rådgiver!
          </p>
          
          <div className="pt-4">
            <Button 
              onClick={onClose}
              className="w-full bg-gradient-to-r from-primary to-primary-glow hover:opacity-90 shadow-warm"
            >
              Kom i gang
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}