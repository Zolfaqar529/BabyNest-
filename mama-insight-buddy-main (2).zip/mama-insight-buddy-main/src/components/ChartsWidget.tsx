import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart3, TrendingUp, Activity, Weight, Moon } from 'lucide-react';
import { ChartData } from '@/hooks/useOverviewData';

interface ChartsWidgetProps {
  data: ChartData;
}

type ChartType = 'mood' | 'energy' | 'weight' | 'sleep' | 'symptoms';

export function ChartsWidget({ data }: ChartsWidgetProps) {
  const [activeChart, setActiveChart] = useState<ChartType>('mood');

  const chartTypes = [
    { key: 'mood' as ChartType, label: 'Humør', icon: TrendingUp },
    { key: 'energy' as ChartType, label: 'Energi', icon: Activity },
    { key: 'weight' as ChartType, label: 'Vægt', icon: Weight },
    { key: 'sleep' as ChartType, label: 'Søvn', icon: Moon },
    { key: 'symptoms' as ChartType, label: 'Symptomer', icon: BarChart3 },
  ];

  const renderChart = () => {
    const chartData = data[activeChart];
    
    if (!chartData || chartData.length === 0) {
      return (
        <div className="flex items-center justify-center h-48 text-muted-foreground">
          <div className="text-center">
            <BarChart3 className="w-12 h-12 mx-auto mb-2 text-muted-foreground/50" />
            <p className="text-sm">Ingen data tilgængelig</p>
          </div>
        </div>
      );
    }

    if (activeChart === 'symptoms') {
      return renderSymptomsChart();
    }

    return renderLineChart();
  };

  const renderLineChart = () => {
    const chartData = data[activeChart] as Array<{ date: string; value: number }>;
    const maxValue = Math.max(...chartData.map(d => d.value));
    const minValue = Math.min(...chartData.map(d => d.value));
    const range = maxValue - minValue;

    return (
      <div className="h-48 flex items-end justify-between space-x-1 p-4">
        {chartData.map((point, index) => {
          const height = range > 0 ? ((point.value - minValue) / range) * 100 : 50;
          return (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div className="w-full bg-primary/20 rounded-t-sm relative group">
                <div 
                  className="bg-primary transition-all duration-300 rounded-t-sm"
                  style={{ height: `${height}%` }}
                />
                <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-background border rounded px-2 py-1 text-xs whitespace-nowrap z-10">
                  {point.value}
                </div>
              </div>
              <span className="text-xs text-muted-foreground mt-1 rotate-45 origin-left">
                {point.date}
              </span>
            </div>
          );
        })}
      </div>
    );
  };

  const renderSymptomsChart = () => {
    const symptomsData = data.symptoms;
    
    return (
      <div className="space-y-3 p-4">
        {symptomsData.map((symptom, index) => {
          const maxFrequency = Math.max(...symptomsData.map(s => s.frequency));
          const width = maxFrequency > 0 ? (symptom.frequency / maxFrequency) * 100 : 0;
          
          return (
            <div key={symptom.symptom} className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">{symptom.symptom}</span>
                <span className="text-xs text-muted-foreground">
                  {symptom.frequency} {symptom.frequency === 1 ? 'gang' : 'gange'}
                </span>
              </div>
              <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${width}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const getChartTitle = () => {
    switch (activeChart) {
      case 'mood':
        return 'Humør over tid (1-10 skala)';
      case 'energy':
        return 'Energiniveau over tid (1-10 skala)';
      case 'weight':
        return 'Vægt over tid (kg)';
      case 'sleep':
        return 'Søvn over tid (timer)';
      case 'symptoms':
        return 'Symptom frekvens';
      default:
        return '';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            <CardTitle className="text-lg">Grafer</CardTitle>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Chart Type Selector */}
        <div className="flex flex-wrap gap-2 mb-6">
          {chartTypes.map((chartType) => {
            const Icon = chartType.icon;
            return (
              <Button
                key={chartType.key}
                variant={activeChart === chartType.key ? 'default' : 'outline'}
                size="sm"
                onClick={() => setActiveChart(chartType.key)}
                className="flex items-center space-x-2"
              >
                <Icon className="w-4 h-4" />
                <span>{chartType.label}</span>
              </Button>
            );
          })}
        </div>

        {/* Chart Title */}
        <div className="mb-4">
          <h4 className="text-sm font-medium text-muted-foreground">
            {getChartTitle()}
          </h4>
        </div>

        {/* Chart */}
        <div className="border rounded-lg">
          {renderChart()}
        </div>

        {/* Chart Legend */}
        {activeChart !== 'symptoms' && data[activeChart] && data[activeChart].length > 0 && (
          <div className="mt-4 flex items-center justify-center space-x-4 text-xs text-muted-foreground">
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-primary rounded-sm" />
              <span>Målinger</span>
            </div>
            <div className="flex items-center space-x-1">
              <div className="w-3 h-3 bg-primary/20 rounded-sm" />
              <span>Skala</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
} 
