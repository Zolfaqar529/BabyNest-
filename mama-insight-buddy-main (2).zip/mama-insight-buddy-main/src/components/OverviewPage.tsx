import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Download, Share2, Calendar, TrendingUp } from 'lucide-react';
import { useOverviewData } from '@/hooks/useOverviewData';
import { TimelineWidget } from './TimelineWidget';
import { SummaryWidget } from './SummaryWidget';
import { ChartsWidget } from './ChartsWidget';
import { DownloadWidget } from './DownloadWidget';
import { ShareWidget } from './ShareWidget';

interface OverviewPageProps {
  onBack: () => void;
}

export default function OverviewPage({ onBack }: OverviewPageProps) {
  const { 
    timelineData, 
    summaryData, 
    chartData, 
    loading, 
    generateReport,
    exportCSV 
  } = useOverviewData();

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-xl font-semibold">Overblik</h1>
          </div>
          <div className="flex items-center justify-center h-64">
            <div className="text-muted-foreground">Indlæser data...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold">Overblik</h1>
              <p className="text-sm text-muted-foreground">
                Sundhedsdata og udvikling gennem graviditeten
              </p>
            </div>
          </div>
        </div>

        {/* Timeline Widget */}
        <TimelineWidget data={timelineData} />

        {/* Summary Widget */}
        <SummaryWidget data={summaryData} />

        {/* Charts Widget */}
        <ChartsWidget data={chartData} />

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <DownloadWidget 
            onGenerateReport={generateReport}
            onExportCSV={exportCSV}
          />
          <ShareWidget />
        </div>
      </div>
    </div>
  );
} 
