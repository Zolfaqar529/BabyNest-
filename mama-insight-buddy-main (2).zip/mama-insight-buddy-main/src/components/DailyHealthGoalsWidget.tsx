import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, X, Target } from "lucide-react";

interface DailyHealthGoalsWidgetProps {
  todayEntry: any;
}

export default function DailyHealthGoalsWidget({ todayEntry }: DailyHealthGoalsWidgetProps) {
  const getHealthGoals = () => {
    const goals = [
      {
        id: "mood",
        emoji: "😊",
        text: "Har du logget humør?",
        completed: todayEntry?.mood !== undefined,
      },
      {
        id: "sleep",
        emoji: "😴",
        text: "Sovet mindst 7 timer?",
        completed: todayEntry?.sleep >= 7,
      },
      {
        id: "symptoms",
        emoji: "📝",
        text: "Har du logget symptomer?",
        completed: todayEntry?.symptoms && todayEntry.symptoms.length > 0,
      },
      {
        id: "activity",
        emoji: "🚶‍♀️",
        text: "Været fysisk aktiv?",
        completed: todayEntry?.exercise && todayEntry.exercise !== "",
      }
    ];

    return goals;
  };

  const healthGoals = getHealthGoals();
  const completedGoals = healthGoals.filter(goal => goal.completed).length;

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-sm">
          <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
            <Target className="w-3 h-3 text-primary" />
          </div>
          Dagens sundhedsmål
          <span className="text-xs text-muted-foreground ml-auto">
            {completedGoals}/{healthGoals.length}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0 space-y-3">
        {healthGoals.map((goal) => (
          <div key={goal.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/30 transition-colors">
            <span className="text-lg">{goal.emoji}</span>
            <span className="text-sm text-foreground flex-1">{goal.text}</span>
            <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
              goal.completed 
                ? 'bg-green-100 text-green-600' 
                : 'bg-muted text-muted-foreground'
            }`}>
              {goal.completed ? (
                <Check className="w-3 h-3" />
              ) : (
                <X className="w-3 h-3" />
              )}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}