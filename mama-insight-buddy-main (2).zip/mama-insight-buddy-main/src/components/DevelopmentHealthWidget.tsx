import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, X, Target } from "lucide-react";

// Baby development stages for SVG animation
const BabyDevelopmentStages = {
  early: (size: number) => (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} viewBox="0 0 100 100" className="animate-baby-breathe">
        <defs>
          <radialGradient id="seedGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.8" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.2" />
          </radialGradient>
        </defs>
        <circle cx="50" cy="50" r="8" fill="url(#seedGradient)" className="animate-pulse" />
        <circle cx="50" cy="50" r="12" fill="none" stroke="hsl(var(--primary))" strokeWidth="1" opacity="0.4" className="animate-ping" />
      </svg>
    </div>
  ),
  
  sprouting: (size: number) => (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} viewBox="0 0 100 100" className="animate-baby-breathe">
        <defs>
          <linearGradient id="sproutGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="hsl(var(--success))" />
            <stop offset="100%" stopColor="hsl(var(--primary))" />
          </linearGradient>
        </defs>
        <circle cx="50" cy="70" r="6" fill="hsl(var(--primary))" opacity="0.8" />
        <path d="M50 70 Q45 50 40 35 Q45 30 50 35 Q55 30 60 35 Q55 50 50 70" 
              fill="url(#sproutGradient)" opacity="0.9" className="animate-float" />
        <circle cx="50" cy="50" r="20" fill="none" stroke="hsl(var(--primary))" strokeWidth="1" opacity="0.2" className="animate-pulse" />
      </svg>
    </div>
  ),
  
  growing: (size: number) => (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} viewBox="0 0 100 100" className="animate-baby-breathe">
        <defs>
          <radialGradient id="growthGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.9" />
            <stop offset="70%" stopColor="hsl(var(--accent))" stopOpacity="0.6" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.2" />
          </radialGradient>
        </defs>
        <ellipse cx="50" cy="55" rx="20" ry="25" fill="url(#growthGradient)" className="animate-gentle-pulse" />
        <circle cx="45" cy="45" r="3" fill="hsl(var(--foreground))" opacity="0.6" />
        <circle cx="55" cy="45" r="3" fill="hsl(var(--foreground))" opacity="0.6" />
        <circle cx="50" cy="50" r="35" fill="none" stroke="hsl(var(--primary))" strokeWidth="1" opacity="0.15" className="animate-pulse" />
      </svg>
    </div>
  ),
  
  developing: (size: number) => (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} viewBox="0 0 100 100" className="animate-baby-breathe">
        <defs>
          <radialGradient id="babyGradient" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor="hsl(var(--accent))" stopOpacity="0.9" />
            <stop offset="50%" stopColor="hsl(var(--primary))" stopOpacity="0.7" />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
          </radialGradient>
        </defs>
        {/* Head */}
        <ellipse cx="50" cy="35" rx="18" ry="20" fill="url(#babyGradient)" />
        {/* Body */}
        <ellipse cx="50" cy="65" rx="15" ry="22" fill="url(#babyGradient)" opacity="0.8" />
        {/* Arms */}
        <ellipse cx="35" cy="55" rx="4" ry="12" fill="url(#babyGradient)" opacity="0.7" />
        <ellipse cx="65" cy="55" rx="4" ry="12" fill="url(#babyGradient)" opacity="0.7" />
        {/* Legs */}
        <ellipse cx="42" cy="82" rx="4" ry="10" fill="url(#babyGradient)" opacity="0.7" />
        <ellipse cx="58" cy="82" rx="4" ry="10" fill="url(#babyGradient)" opacity="0.7" />
        {/* Glow effect */}
        <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--primary))" strokeWidth="0.5" opacity="0.1" className="animate-pulse" />
      </svg>
    </div>
  )
};

interface DevelopmentHealthWidgetProps {
  userProfile: {
    motherName: string;
    expectedDate: string;
    babyName: string;
    babyGender: string;
    isPostpartum: boolean;
  };
  currentWeek: number;
  daysLeft: number;
  babySize: string;
  todayEntry?: any;
  onNavigate?: (page: string) => void;
}

// Map weeks to development stages
const getBabyVisualization = (week: number, size: number) => {
  if (week <= 8) return BabyDevelopmentStages.early(size);
  if (week <= 16) return BabyDevelopmentStages.sprouting(size);
  if (week <= 28) return BabyDevelopmentStages.growing(size);
  return BabyDevelopmentStages.developing(size);
};

export default function DevelopmentHealthWidget({
  userProfile,
  currentWeek,
  daysLeft,
  babySize,
  todayEntry,
  onNavigate
}: DevelopmentHealthWidgetProps) {
  const [weekData, setWeekData] = useState<any>(null);

  // Dynamic greeting based on tracking data
  const getDynamicGreeting = () => {
    if (!todayEntry) {
      return `Se ${userProfile.babyName || "din baby"}s udvikling`;
    }

    const mood = todayEntry.mood;
    const energy = todayEntry.energy_level;
    const symptoms = todayEntry.symptoms || [];

    // Positive mood messages
    if (mood >= 8) {
      return `Du har det godt i dag! ${userProfile.babyName || "Baby"} nyder også din gode energi ✨`;
    }
    
    // Medium mood with good energy
    if (mood >= 6 && energy >= 7) {
      return `God energi i dag! ${userProfile.babyName || "Baby"} vokser stærkt 💪`;
    }
    
    // Low energy or many symptoms
    if (energy <= 4 || symptoms.length >= 3) {
      return `Tag det roligt i dag. ${userProfile.babyName || "Baby"} og du skal bare hvile 🤗`;
    }
    
    // Medium mood
    if (mood >= 5) {
      return `En almindelig dag. ${userProfile.babyName || "Baby"} udvikler sig fint 🌱`;
    }
    
    // Low mood
    return `Nogle dage er svære. ${userProfile.babyName || "Baby"} er der for dig 💝`;
  };

  const getHealthGoals = () => {
    const goals = [
      {
        id: "mood",
        text: "Har du logget humør?",
        completed: todayEntry?.mood !== undefined,
      },
      {
        id: "sleep",
        text: "Sovet mindst 7 timer?",
        completed: todayEntry?.sleep >= 7,
      },
      {
        id: "symptoms",
        text: "Har du logget symptomer?",
        completed: todayEntry?.symptoms && todayEntry.symptoms.length > 0,
      },
      {
        id: "activity",
        text: "Været fysisk aktiv?",
        completed: todayEntry?.exercise && todayEntry.exercise !== "",
      }
    ];

    return goals;
  };

  useEffect(() => {
    const loadBabyDevelopment = async () => {
      try {
        const response = await fetch('/src/data/babyDevelopment.json');
        const developmentData = await response.json();
        const data = developmentData[currentWeek.toString()];
        setWeekData(data);
      } catch (error) {
        console.error("Could not load baby development data:", error);
      }
    };

    if (currentWeek >= 0) {
      loadBabyDevelopment();
    }
  }, [currentWeek]);

  const getBabyVisualizationComponent = () => {
    const minSize = 140;
    const maxSize = 200;
    const sizeRange = maxSize - minSize;
    const weekProgress = Math.min(currentWeek / 40, 1);
    const scaledSize = minSize + (sizeRange * weekProgress);
    
    return getBabyVisualization(currentWeek, scaledSize);
  };

  const healthGoals = getHealthGoals();
  const completedGoals = healthGoals.filter(goal => goal.completed).length;

  return (
    <Card className="w-full overflow-hidden bg-[#FAF8F6] border-0 shadow-[0px_4px_16px_rgba(0,0,0,0.04)]" style={{ borderRadius: '16px' }}>
      <CardContent className="p-6">
        <div className="flex gap-4">
          {/* Health Goals Side - Funktion (Left) */}
          <div className="flex-1" style={{ minWidth: '68%' }}>
            {/* Header with subtle divider */}
            <div className="flex items-center gap-3 mb-6 pb-3 border-b border-dotted border-muted-foreground/20" style={{ marginLeft: '-8px' }}>
              <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center">
                <Target className="w-2.5 h-2.5 text-primary/70" />
              </div>
              <h3 className="text-sm font-medium text-muted-foreground" style={{ fontFamily: 'Inter, system-ui, -apple-system, sans-serif' }}>
                Dagens mål
              </h3>
              <span className="text-xs text-muted-foreground/60 ml-auto" style={{ fontSize: '10px' }}>
                {completedGoals}/{healthGoals.length}
              </span>
            </div>
            
            {/* Goals list - more spacious */}
            <div className="space-y-5" style={{ marginLeft: '-8px' }}>
              {healthGoals.map((goal, index) => (
                <div 
                  key={goal.id} 
                  className="flex items-center gap-3 group transition-all duration-300"
                  style={{ 
                    opacity: goal.completed ? 1 : 0.7,
                    transform: goal.completed ? 'scale(1)' : 'scale(0.98)'
                  }}
                >
                  <span 
                    className="flex-1 leading-relaxed text-muted-foreground" 
                    style={{ 
                      fontFamily: 'Inter, system-ui, -apple-system, sans-serif',
                      fontSize: '10px',
                      fontWeight: '400',
                      lineHeight: '1.6'
                    }}
                  >
                    {goal.text}
                  </span>
                  
                  {/* Subtle Nordic indicator */}
                  <div className={`w-3 h-3 rounded-full border transition-all duration-500 ${
                    goal.completed 
                      ? 'bg-green-100 border-green-200 scale-110' 
                      : 'bg-transparent border-muted-foreground/30'
                  }`}>
                    {goal.completed && (
                      <div className="w-full h-full flex items-center justify-center">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-scale-in" />
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            {/* Dynamic greeting - moved below goals list and made smaller */}
            {userProfile.babyName && (
              <div className="mt-4 pt-3 border-t border-dotted border-muted-foreground/20" style={{ marginLeft: '-8px' }}>
                <p className="text-xs font-normal italic text-muted-foreground/60 leading-relaxed" style={{ fontSize: '9px' }}>
                  {userProfile.isPostpartum ? 
                    `${userProfile.babyName} er nu ${currentWeek} uger gammel! 🍼` : 
                    getDynamicGreeting()
                  }
                </p>
              </div>
            )}
          </div>

          {/* Baby Development Side - Empati (Right) */}
          <div className="flex-1 space-y-4" style={{ maxWidth: '32%' }}>
            {/* Baby visualization - moved up */}
            {!userProfile.isPostpartum && (
              <div className="flex justify-center items-center -mt-4">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/10 rounded-full blur-2xl animate-baby-breathe" />
                  <div className="relative drop-shadow-sm hover:scale-105 transition-transform duration-500">
                    {getBabyVisualizationComponent()}
                  </div>
                </div>
              </div>
            )}

            {/* Minimalist button - much smaller text */}
            <div className="flex justify-center mt-6">
              <button 
                onClick={() => onNavigate?.("development")}
                className="border border-[#EDEDED] rounded-full px-2 py-1 hover:border-[#E0E0E0] transition-all duration-200 flex items-center gap-1 bg-white/50 backdrop-blur-sm"
                style={{ fontSize: '10px', borderRadius: '9999px', padding: '3px 8px' }}
              >
                <span className="font-medium text-muted-foreground">Se udvikling</span>
                <svg className="w-2 h-2 text-[#C4A57B]" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}