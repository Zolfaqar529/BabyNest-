import { useState, useEffect, useRef } from "react";
import { differenceInWeeks, differenceInDays } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Baby, Heart, Calendar, Info, Share2, Download, BookOpen, ChevronLeft, ChevronRight } from "lucide-react";
import { AIService } from "@/lib/aiService";

interface BabyDevelopmentDetailProps {
  userProfile: {
    motherName: string;
    expectedDate: string;
    babyName: string;
    babyGender: string;
    isPostpartum: boolean;
  };
  onBack: () => void;
}

export default function BabyDevelopmentDetail({ 
  userProfile, 
  onBack 
}: BabyDevelopmentDetailProps) {
  const [weekData, setWeekData] = useState<any>(null);
  const [currentWeek, setCurrentWeek] = useState(0);
  const [daysLeft, setDaysLeft] = useState(0);
  const [weeklyMessage, setWeeklyMessage] = useState("");
  const [showNoteInput, setShowNoteInput] = useState(false);
  const [weekNote, setWeekNote] = useState("");
  const [isScrolled, setIsScrolled] = useState(false);
  const headerRef = useRef<HTMLDivElement>(null);

  // Calculate pregnancy data
  useEffect(() => {
    const calculatePregnancyData = () => {
      const expectedDate = new Date(userProfile.expectedDate);
      const today = new Date();
      
      if (userProfile.isPostpartum) {
        // Calculate weeks since birth
        const weeksSinceBirth = differenceInWeeks(today, expectedDate);
        setCurrentWeek(Math.min(12, Math.max(0, weeksSinceBirth))); // Cap at 12 weeks postpartum
        setDaysLeft(0);
      } else {
        // Calculate pregnancy weeks (from conception, which is 2 weeks after LMP)
        const pregnancyStart = new Date(expectedDate);
        pregnancyStart.setDate(pregnancyStart.getDate() - 280); // 40 weeks = 280 days
        
        const pregnancyWeeks = differenceInWeeks(today, pregnancyStart);
        const daysRemaining = differenceInDays(expectedDate, today);
        
        setCurrentWeek(Math.min(42, Math.max(0, pregnancyWeeks))); // Cap between 0-42 weeks
        setDaysLeft(Math.max(0, daysRemaining));
      }
    };

    calculatePregnancyData();
  }, [userProfile]);


  useEffect(() => {
    const loadBabyDevelopment = async () => {
      try {
        const response = await fetch('/src/data/babyDevelopment.json');
        const developmentData = await response.json();
        const data = developmentData[currentWeek.toString()];
        setWeekData(data);
      } catch (error) {
        console.error("Could not load baby development data:", error);
      }
    };

    if (currentWeek >= 0) {
      loadBabyDevelopment();
    }
  }, [currentWeek]);

  // Generate AI weekly message
  useEffect(() => {
    if (currentWeek > 0) {
      const message = AIService.generateWeeklyMessage(currentWeek, userProfile);
      setWeeklyMessage(message);
    }
  }, [currentWeek, userProfile]);

  // Scroll effect for sticky header
  useEffect(() => {
    const handleScroll = () => {
      const scrolled = window.scrollY > 100;
      setIsScrolled(scrolled);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const getProgressPercentage = () => {
    if (userProfile.isPostpartum) return 100;
    return Math.min(100, (currentWeek / 40) * 100);
  };

  const getFruitSize = () => {
    if (weekData?.size) return weekData.size;
    
    // Fallback fruit sizes
    const fruitSizes = [
      "frø", "frø", "sesam", "blåbær", "ærtebælle", "linse", "blåbær",
      "hindbær", "kirsebær", "jordgulvet", "dadel", "lime", "fersken",
      "citron", "nektarin", "avocado", "løg", "paprika", "banan", 
      "grapefrugt", "broccoli", "aubergine", "majskolbe", "blomkål",
      "agurk", "rød kål", "honningdynte", "cocos", "græskar", "ananas",
      "savoy kål", "butternut squash", "honningmelon", "cantaloupe melon",
      "romaine salat", "schweizer kål", "vandmelon", "babymelon", "græskar", "vandmelon"
    ];
    
    return fruitSizes[currentWeek] || "frugt";
  };

  const getBabyVisualization = () => {
    // Scale fruit size proportionally with pregnancy week
    const minSize = 150;
    const maxSize = 320;
    const sizeRange = maxSize - minSize;
    const weekProgress = Math.min(currentWeek / 40, 1);
    const scaledSize = minSize + (sizeRange * weekProgress);
    
    const fruitName = getFruitSize().toLowerCase();
    
    // 3D Fruit SVG illustrations with floating effect
    const renderFruit = () => {
      if (fruitName.includes('blåbær') || fruitName.includes('hindbær')) {
        return (
          <svg width={scaledSize} height={scaledSize} viewBox="0 0 200 200" className="animate-float">
            <defs>
              <radialGradient id="blueberryGrad" cx="35%" cy="25%" r="65%">
                <stop offset="0%" stopColor="#7c3aed" />
                <stop offset="60%" stopColor="#5b21b6" />
                <stop offset="100%" stopColor="#3730a3" />
              </radialGradient>
              <filter id="fruitShadow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="4" dy="8" stdDeviation="8" floodOpacity="0.3"/>
              </filter>
            </defs>
            <circle cx="100" cy="95" r="35" fill="url(#blueberryGrad)" filter="url(#fruitShadow)" />
            <circle cx="85" cy="80" r="3" fill="#a78bfa" opacity="0.7" />
            <circle cx="110" cy="85" r="2" fill="#a78bfa" opacity="0.7" />
            <path d="M95 65 Q100 60 105 65" stroke="#22c55e" strokeWidth="2" fill="none" />
          </svg>
        );
      }
      
      if (fruitName.includes('lime') || fruitName.includes('citron')) {
        return (
          <svg width={scaledSize} height={scaledSize} viewBox="0 0 200 200" className="animate-float">
            <defs>
              <radialGradient id="limeGrad" cx="35%" cy="25%" r="65%">
                <stop offset="0%" stopColor="#84cc16" />
                <stop offset="60%" stopColor="#65a30d" />
                <stop offset="100%" stopColor="#4d7c0f" />
              </radialGradient>
            </defs>
            <ellipse cx="100" cy="95" rx="40" ry="45" fill="url(#limeGrad)" filter="url(#fruitShadow)" />
            <ellipse cx="85" cy="75" rx="8" ry="3" fill="#a3e635" opacity="0.6" />
            <path d="M95 55 Q100 50 105 55" stroke="#22c55e" strokeWidth="3" fill="none" />
          </svg>
        );
      }
      
      if (fruitName.includes('avocado')) {
        return (
          <svg width={scaledSize} height={scaledSize} viewBox="0 0 200 200" className="animate-float">
            <defs>
              <radialGradient id="avocadoGrad" cx="35%" cy="25%" r="65%">
                <stop offset="0%" stopColor="#84cc16" />
                <stop offset="60%" stopColor="#365314" />
                <stop offset="100%" stopColor="#1a2e05" />
              </radialGradient>
              <radialGradient id="avocadoPit" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#fbbf24" />
                <stop offset="100%" stopColor="#d97706" />
              </radialGradient>
            </defs>
            <path d="M100 40 Q70 60 75 120 Q85 150 100 155 Q115 150 125 120 Q130 60 100 40" 
                  fill="url(#avocadoGrad)" filter="url(#fruitShadow)" />
            <ellipse cx="100" cy="105" rx="15" ry="20" fill="url(#avocadoPit)" />
            <ellipse cx="90" cy="65" rx="8" ry="4" fill="#a3e635" opacity="0.5" />
          </svg>
        );
      }
      
      if (fruitName.includes('banan')) {
        return (
          <svg width={scaledSize} height={scaledSize} viewBox="0 0 200 200" className="animate-float">
            <defs>
              <radialGradient id="bananaGrad" cx="35%" cy="25%" r="65%">
                <stop offset="0%" stopColor="#fbbf24" />
                <stop offset="60%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#d97706" />
              </radialGradient>
            </defs>
            <path d="M80 50 Q90 70 95 100 Q100 130 110 150 Q120 140 115 110 Q110 80 105 60 Q95 45 80 50" 
                  fill="url(#bananaGrad)" filter="url(#fruitShadow)" />
            <path d="M82 55 Q88 70 92 95 Q96 125 106 145" 
                  stroke="#fed7aa" strokeWidth="2" fill="none" opacity="0.6" />
            <ellipse cx="78" cy="52" rx="3" ry="6" fill="#65a30d" />
          </svg>
        );
      }
      
      if (fruitName.includes('grapefrugt')) {
        return (
          <svg width={scaledSize} height={scaledSize} viewBox="0 0 200 200" className="animate-float">
            <defs>
              <radialGradient id="grapefruitGrad" cx="35%" cy="25%" r="65%">
                <stop offset="0%" stopColor="#fb7185" />
                <stop offset="60%" stopColor="#e11d48" />
                <stop offset="100%" stopColor="#be123c" />
              </radialGradient>
            </defs>
            <circle cx="100" cy="95" r="50" fill="url(#grapefruitGrad)" filter="url(#fruitShadow)" />
            <circle cx="80" cy="75" r="8" fill="#fda4af" opacity="0.6" />
            <circle cx="115" cy="80" r="6" fill="#fda4af" opacity="0.6" />
            <path d="M95 45 Q100 40 105 45" stroke="#22c55e" strokeWidth="3" fill="none" />
          </svg>
        );
      }
      
      if (fruitName.includes('vandmelon')) {
        return (
          <svg width={scaledSize} height={scaledSize} viewBox="0 0 200 200" className="animate-float">
            <defs>
              <radialGradient id="watermelonGrad" cx="35%" cy="25%" r="65%">
                <stop offset="0%" stopColor="#22c55e" />
                <stop offset="60%" stopColor="#16a34a" />
                <stop offset="100%" stopColor="#15803d" />
              </radialGradient>
              <radialGradient id="watermelonInside" cx="50%" cy="50%" r="70%">
                <stop offset="0%" stopColor="#fb7185" />
                <stop offset="80%" stopColor="#e11d48" />
                <stop offset="100%" stopColor="#be123c" />
              </radialGradient>
            </defs>
            <ellipse cx="100" cy="95" rx="55" ry="60" fill="url(#watermelonGrad)" filter="url(#fruitShadow)" />
            <ellipse cx="100" cy="95" rx="45" ry="50" fill="url(#watermelonInside)" />
            <ellipse cx="85" cy="80" rx="2" ry="4" fill="#1f2937" />
            <ellipse cx="110" cy="75" rx="2" ry="4" fill="#1f2937" />
            <ellipse cx="95" cy="105" rx="2" ry="4" fill="#1f2937" />
            <ellipse cx="115" cy="100" rx="2" ry="4" fill="#1f2937" />
          </svg>
        );
      }
      
      // Default fruit (generic)
      return (
        <svg width={scaledSize} height={scaledSize} viewBox="0 0 200 200" className="animate-float">
          <defs>
            <radialGradient id="genericFruitGrad" cx="35%" cy="25%" r="65%">
              <stop offset="0%" stopColor="hsl(var(--primary))" />
              <stop offset="60%" stopColor="hsl(var(--primary) / 0.8)" />
              <stop offset="100%" stopColor="hsl(var(--primary) / 0.6)" />
            </radialGradient>
          </defs>
          <circle cx="100" cy="95" r="40" fill="url(#genericFruitGrad)" filter="url(#fruitShadow)" />
          <circle cx="85" cy="75" r="6" fill="hsl(var(--primary-glow))" opacity="0.6" />
          <path d="M95 55 Q100 50 105 55" stroke="#22c55e" strokeWidth="3" fill="none" />
        </svg>
      );
    };

    return (
      <div className="flex items-center justify-center">
        {renderFruit()}
      </div>
    );
  };

  const getTrimester = () => {
    if (currentWeek <= 12) return { name: "Første trimester", color: "bg-primary/20 text-primary" };
    if (currentWeek <= 27) return { name: "Andet trimester", color: "bg-success/20 text-success" };
    return { name: "Tredje trimester", color: "bg-warning/20 text-warning" };
  };

  const handleShareImage = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Uge ${currentWeek} - ${userProfile.babyName}`,
          text: `${userProfile.babyName} er nu på størrelse med ${getFruitSize()}!`,
        });
      } catch (error) {
        console.log('Sharing cancelled');
      }
    }
  };

  const handleSaveNote = () => {
    if (weekNote.trim()) {
      const existingNotes = JSON.parse(localStorage.getItem("babynest_weekly_notes") || "[]");
      const today = new Date().toISOString().split('T')[0];
      
      existingNotes.push({
        week: currentWeek,
        note: weekNote,
        date: today,
        userProfile: userProfile.motherName
      });
      
      localStorage.setItem("babynest_weekly_notes", JSON.stringify(existingNotes));
      setWeekNote("");
      setShowNoteInput(false);
    }
  };

  const trimester = getTrimester();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-primary-glow/10 p-4 pb-20">
      <div className="max-w-sm mx-auto space-y-4">
        {/* Sticky Header with Scroll Effect */}
        <div 
          ref={headerRef}
          className={`
            transition-all duration-300 ease-in-out
            ${isScrolled 
              ? 'fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border/50 p-4 scale-95' 
              : 'relative p-0 scale-100'
            }
          `}
        >
          <div className="max-w-sm mx-auto flex items-center space-x-3">
            <Button variant="ghost" onClick={onBack} className="p-2">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className={`font-playfair font-medium ${isScrolled ? 'text-base' : 'text-xl'} transition-all duration-300`}>
                {userProfile.isPostpartum ? `Uge ${currentWeek} efter fødslen` : `Graviditetsuge ${currentWeek}`}
              </h1>
              {!isScrolled && (
                <p className="text-muted-foreground">
                  {userProfile.isPostpartum ? 
                    `${userProfile.babyName || "Baby"} er nu ${currentWeek} uger gammel` :
                    `${daysLeft} dage tilbage`
                  }
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Spacer when header is sticky */}
        {isScrolled && <div className="h-20" />}

        {/* Main visualization card */}
        <Card className="nordic-card overflow-hidden">
          <CardContent className="p-4">
            {/* Trimester badge */}
            {!userProfile.isPostpartum && (
              <div className="flex justify-center mb-6">
                <Badge className={`${trimester.color} px-4 py-2 rounded-full font-medium`}>
                  {trimester.name}
                </Badge>
              </div>
            )}

            {/* Baby visualization */}
            <div className="relative flex justify-center items-center min-h-[200px] mb-4">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/15 to-accent/25 rounded-full blur-2xl animate-baby-breathe scale-125" />
                <div className="relative drop-shadow-lg">
                  {getBabyVisualization()}
                </div>
              </div>
            </div>

            {/* Size comparison */}
            <div className="text-center mb-4">
              <h3 className="text-lg font-playfair font-medium mb-2">Størrelse sammenligning</h3>
              <div className="bg-gradient-to-r from-muted/30 to-muted/10 rounded-xl p-4 border border-border/20">
                <p className="text-lg font-semibold mb-1">
                  {userProfile.babyName || "Baby"} er nu på størrelse med 
                </p>
                <p className="text-xl font-playfair font-bold text-primary capitalize">
                  {getFruitSize()}
                </p>
              </div>
            </div>

            {/* Progress bar */}
            {!userProfile.isPostpartum && (
              <div className="mb-4">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-sm font-medium text-muted-foreground">Graviditetsforløb</span>
                  <span className="text-sm font-semibold text-foreground">{Math.round(getProgressPercentage())}%</span>
                </div>
                <Progress value={getProgressPercentage()} className="h-2 rounded-full" />
              </div>
            )}

            {/* AI Weekly Message */}
            {weeklyMessage && (
              <div className="mb-4 p-3 bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl border border-primary/20">
                <p className="text-center text-foreground font-medium italic">
                  "{weeklyMessage}"
                </p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-2 justify-center">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleShareImage}
                className="flex items-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                Del
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowNoteInput(true)}
                className="flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                Tilføj notat
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Note Input Card */}
        {showNoteInput && (
          <Card className="nordic-card">
            <CardHeader>
              <CardTitle className="text-lg">Notat om uge {currentWeek}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Skriv dine tanker, følelser eller observationer om denne uge..."
                value={weekNote}
                onChange={(e) => setWeekNote(e.target.value)}
                className="min-h-[100px]"
              />
              <div className="flex gap-2">
                <Button onClick={handleSaveNote} disabled={!weekNote.trim()}>
                  Gem notat
                </Button>
                <Button variant="outline" onClick={() => setShowNoteInput(false)}>
                  Annuller
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Development details */}
        {weekData && (
          <Card className="nordic-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Baby className="w-5 h-5 text-primary" />
                {weekData.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-muted-foreground leading-relaxed">
                {weekData.description}
              </p>

              {weekData.keyDevelopments && (
                <div>
                  <h4 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Info className="w-4 h-4 text-accent" />
                    Vigtige udviklingstrin
                  </h4>
                  <div className="grid gap-3">
                    {weekData.keyDevelopments.map((development: string, index: number) => (
                      <div key={index} className="flex items-start gap-3 p-3 bg-gradient-to-r from-muted/20 to-muted/5 rounded-xl border border-border/10">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                        <p className="text-sm font-medium">{development}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Timeline info */}
        <Card className="nordic-card">
          <CardContent className="p-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Calendar className="w-6 h-6 text-primary" />
                </div>
                <p className="text-sm text-muted-foreground mb-1">Aktuel uge</p>
                <p className="text-xl font-semibold">{currentWeek}</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Heart className="w-6 h-6 text-accent-foreground" />
                </div>
                <p className="text-sm text-muted-foreground mb-1">
                  {userProfile.isPostpartum ? "Uger siden fødsel" : "Dage tilbage"}
                </p>
                <p className="text-xl font-semibold">
                  {userProfile.isPostpartum ? currentWeek : Math.max(0, daysLeft)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}