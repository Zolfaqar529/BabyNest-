import { Card, CardContent } from "@/components/ui/card";
import { Calendar } from "lucide-react";

interface InteractiveTodayWidgetProps {
  todayStats: Array<{
    label: string;
    value: string;
    icon: any;
  }>;
  onNavigateToTracking: () => void;
}

export default function InteractiveTodayWidget({ todayStats, onNavigateToTracking }: InteractiveTodayWidgetProps) {
  return (
    <Card 
      className="nordic-card cursor-pointer transition-all duration-300 hover:shadow-md hover:scale-[1.01] border-0"
      onClick={onNavigateToTracking}
    >
      <CardContent className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-full bg-primary/5 flex items-center justify-center">
            <Calendar className="w-5 h-5 text-primary/70" />
          </div>
          <h2 className="text-lg font-medium text-foreground">I dag</h2>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {todayStats.map((stat, index) => (
            <div key={index} className="group">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-background/50 hover:bg-background/80 transition-all duration-200 hover:scale-102">
                <div className="w-8 h-8 rounded-full bg-primary/5 flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                  <stat.icon className="w-4 h-4 text-primary/70" />
                </div>
                <div className="flex-1">
                  <p className="text-base font-medium text-foreground">{stat.value}</p>
                  <p className="text-xs text-muted-foreground font-normal">{stat.label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}