import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useSupabaseData } from "@/hooks/useSupabaseData";
import { 
  Heart, 
  Moon, 
  Activity, 
  Scale, 
  Smile,
  Frown,
  Meh,
  Check,
  ArrowLeft,
  Save
} from "lucide-react";
import { AnimatedButton } from '@/components/ui/animated-button';

interface TrackingData {
  mood: number;
  energy: number;
  sleep: number;
  symptoms: string[];
  weight: string;
  exercise: string;
  notes: string;
  stress_level: number;
  sleep_quality: number;
  nausea_level: number;
  date?: string;
}

interface DailyTrackingProps {
  onBack: () => void;
  onSave?: (data: TrackingData) => void;
}

// Simple custom slider component that definitely works
const SimpleSlider = ({ 
  value, 
  onChange, 
  min = 1, 
  max = 10, 
  step = 1, 
  label 
}: { 
  value: number; 
  onChange: (value: number) => void; 
  min?: number; 
  max?: number; 
  step?: number;
  label: string;
}) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = Number(e.target.value);
    console.log(`${label} slider changed to:`, newValue);
    onChange(newValue);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium">{label}: {value}</span>
        <span className="text-xs text-muted-foreground">{min} - {max}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={handleInputChange}
        className="w-full h-3 bg-secondary rounded-lg appearance-none cursor-pointer slider"
        style={{
          background: `linear-gradient(to right, hsl(var(--primary)) 0%, hsl(var(--primary)) ${((value - min) / (max - min)) * 100}%, hsl(var(--secondary)) ${((value - min) / (max - min)) * 100}%, hsl(var(--secondary)) 100%)`
        }}
      />
      <style>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: hsl(var(--primary));
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .slider::-moz-range-thumb {
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: hsl(var(--primary));
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
      `}</style>
    </div>
  );
};

export default function DailyTracking({ onBack, onSave }: DailyTrackingProps) {
  const { saveDailyEntry, getTodayEntry, refreshData } = useSupabaseData();
  const { toast } = useToast();
  
  const [trackingData, setTrackingData] = useState<TrackingData>({
    mood: 5,
    energy: 5,
    sleep: 7,
    symptoms: [],
    weight: "",
    exercise: "",
    notes: "",
    stress_level: 5,
    sleep_quality: 7,
    nausea_level: 1
  });

  // Load existing data for today if it exists
  useEffect(() => {
    const todayEntry = getTodayEntry();
    
    if (todayEntry) {
      setTrackingData({
        mood: todayEntry.mood || 5,
        energy: todayEntry.energy_level || 5,
        sleep: todayEntry.sleep || 7,
        symptoms: todayEntry.symptoms || [],
        weight: todayEntry.weight || "",
        exercise: todayEntry.exercise || "",
        notes: todayEntry.notes || "",
        stress_level: todayEntry.stress_level || 5,
        sleep_quality: todayEntry.sleep_quality || 7,
        nausea_level: todayEntry.nausea_level || 1
      });
    }
  }, [getTodayEntry]); // Depend on the function to reload when data changes

  const commonSymptoms = [
    "Kvalme", "Hovedpine", "Træthed", "Rygsmerter", 
    "Hævede fødder", "Heartburn", "Forstoppelse", "Søvnløshed",
    "Kramper", "Svimmelhed", "Åndedrætsbesvær", "Hyppig vandladning"
  ];

  const handleSymptomToggle = (symptom: string) => {
    console.log('Symptom clicked:', symptom);
    setTrackingData(prev => {
      const newSymptoms = prev.symptoms.includes(symptom)
        ? prev.symptoms.filter(s => s !== symptom)
        : [...prev.symptoms, symptom];
      console.log('New symptoms:', newSymptoms);
      return {
        ...prev,
        symptoms: newSymptoms
      };
    });
  };

  const getMoodIcon = (mood: number) => {
    if (mood <= 3) return <Frown className="w-6 h-6 text-destructive" />;
    if (mood <= 7) return <Meh className="w-6 h-6 text-warning" />;
    return <Smile className="w-6 h-6 text-success" />;
  };

  const getMoodLabel = (mood: number) => {
    if (mood <= 3) return "Dårligt";
    if (mood <= 7) return "Okay";
    return "Godt";
  };

  const handleSave = async () => {
    const today = new Date().toISOString().split('T')[0];
    
    try {
      await saveDailyEntry({
        date: today,
        mood: trackingData.mood,
        energy_level: trackingData.energy,
        sleep: trackingData.sleep,
        symptoms: trackingData.symptoms,
        weight: trackingData.weight,
        exercise: trackingData.exercise,
        notes: trackingData.notes,
        stress_level: trackingData.stress_level,
        sleep_quality: trackingData.sleep_quality,
        nausea_level: trackingData.nausea_level,
        source_tab: 'tracking'
      });

      // Refresh data after saving
      await refreshData();

      toast({
        title: "Gemt!",
        description: "Dine daglige data er gemt og vil nu vises i Overblik!",
      });

      if (onSave) {
        onSave({ ...trackingData, date: today });
      }
    } catch (error) {
      console.error('Save error:', error);
      toast({
        title: "Fejl",
        description: "Der opstod en fejl ved gemning. Prøv igen.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-primary-glow/10 p-4 pb-20">
      <div className="max-w-sm mx-auto space-y-4">
        
        {/* Header */}
        <div className="flex items-center space-x-3 mb-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Tilbage
          </Button>
          <div>
            <h1 className="text-lg font-bold">Daglig tracking</h1>
            <p className="text-sm text-muted-foreground">Registrer hvordan du har det i dag</p>
          </div>
        </div>

        {/* Mood */}
        <Card className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Heart className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-base font-medium">Humør</h3>
          </div>
          
          <SimpleSlider
            value={trackingData.mood}
            onChange={(value) => setTrackingData(prev => ({ ...prev, mood: value }))}
            min={1}
            max={10}
            label="Humør"
          />
          
          <div className="flex items-center justify-center space-x-3 p-4 rounded-2xl bg-muted/30 mt-4">
            {getMoodIcon(trackingData.mood)}
            <span className="font-medium">{getMoodLabel(trackingData.mood)} ({trackingData.mood}/10)</span>
          </div>
        </Card>

        {/* Energy */}
        <Card className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-base font-medium">Energi</h3>
          </div>
          
          <SimpleSlider
            value={trackingData.energy}
            onChange={(value) => setTrackingData(prev => ({ ...prev, energy: value }))}
            min={1}
            max={10}
            label="Energiniveau"
          />
        </Card>

        {/* Sleep */}
        <Card className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Moon className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-base font-medium">Søvn</h3>
          </div>
          
          <SimpleSlider
            value={trackingData.sleep}
            onChange={(value) => setTrackingData(prev => ({ ...prev, sleep: value }))}
            min={1}
            max={12}
            step={0.5}
            label="Søvn i nat (timer)"
          />
        </Card>

        {/* Symptoms */}
        <Card className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Heart className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-base font-medium">Symptomer i dag</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">Klik for at vælge/fravælge</p>
          
          <div className="grid grid-cols-2 gap-3">
            {commonSymptoms.map((symptom, index) => {
              const isSelected = trackingData.symptoms.includes(symptom);
              return (
                <button
                  key={index}
                  onClick={() => handleSymptomToggle(symptom)}
                  className={`
                    text-center py-3 px-4 rounded-lg border transition-all duration-200 text-sm font-medium
                    ${isSelected 
                      ? 'bg-primary text-primary-foreground border-primary' 
                      : 'bg-background text-foreground border-border hover:bg-accent'
                    }
                  `}
                >
                  <div className="flex items-center justify-center gap-1">
                    {isSelected && <Check className="w-3 h-3" />}
                    <span>{symptom}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </Card>

        {/* Weight & Exercise */}
        <Card className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Scale className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-base font-medium">Vægt og motion</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="weight" className="text-sm font-medium">Vægt i kg (valgfrit)</Label>
              <Input
                id="weight"
                type="number"
                placeholder="68.5"
                value={trackingData.weight}
                onChange={(e) => setTrackingData(prev => ({ ...prev, weight: e.target.value }))}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label htmlFor="exercise" className="text-sm font-medium">Aktivitet i dag</Label>
              <Input
                id="exercise"
                placeholder="Gåtur 30 min"
                value={trackingData.exercise}
                onChange={(e) => setTrackingData(prev => ({ ...prev, exercise: e.target.value }))}
                className="mt-2"
              />
            </div>
          </div>
        </Card>

        {/* Stress, Sleep Quality, Nausea */}
        <Card className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Moon className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-base font-medium">Følelsesmæssigt velbefindende</h3>
          </div>
          
          <div className="space-y-6">
            <SimpleSlider
              value={trackingData.stress_level}
              onChange={(value) => setTrackingData(prev => ({ ...prev, stress_level: value }))}
              min={1}
              max={10}
              label="Stressniveau"
            />

            <SimpleSlider
              value={trackingData.sleep_quality}
              onChange={(value) => setTrackingData(prev => ({ ...prev, sleep_quality: value }))}
              min={1}
              max={10}
              label="Søvnkvalitet"
            />

            <SimpleSlider
              value={trackingData.nausea_level}
              onChange={(value) => setTrackingData(prev => ({ ...prev, nausea_level: value }))}
              min={1}
              max={10}
              label="Kvalme niveau"
            />
          </div>
        </Card>

        {/* Notes */}
        <Card className="p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Heart className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-base font-medium">Dagbog</h3>
          </div>
          <p className="text-sm text-muted-foreground mb-4">Hvordan har din dag været?</p>
          
          <Textarea
            placeholder="Skriv dine tanker og oplevelser fra i dag..."
            value={trackingData.notes}
            onChange={(e) => setTrackingData(prev => ({ ...prev, notes: e.target.value }))}
            rows={4}
          />
        </Card>

        {/* Save button */}
        <Button 
          onClick={handleSave}
          className="w-full bg-gradient-to-r from-primary to-primary-glow hover:opacity-90 text-lg py-6"
        >
          <Save className="w-5 h-5 mr-2" />
          Gem dagens data
        </Button>
      </div>
    </div>
  );
}