import { Card, CardContent } from "@/components/ui/card";
import { Calendar, Heart, Moon, Activity, Scale } from "lucide-react";

interface TodayWidgetProps {
  todayStats: Array<{
    label: string;
    value: string;
    icon: any;
  }>;
  onNavigateToTracking: () => void;
}

export default function TodayWidget({ todayStats, onNavigateToTracking }: TodayWidgetProps) {
  return (
    <Card 
      className="cursor-pointer hover:shadow-md transition-all duration-300 hover:scale-[1.02]"
      onClick={onNavigateToTracking}
    >
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
            <Calendar className="w-4 h-4 text-primary" />
          </div>
          <h2 className="text-sm font-medium text-foreground">I dag</h2>
        </div>
        
        <div className="flex justify-between gap-2 mb-4">
          {todayStats.map((stat, index) => (
            <div key={index} className="flex-1 text-center">
              <div className="w-6 h-6 mx-auto mb-1 bg-primary/10 rounded-full flex items-center justify-center">
                <stat.icon className="w-3 h-3 text-primary" />
              </div>
              <p className="text-sm font-medium mb-0.5">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>
        
        <div className="pt-3 border-t border-border/50">
          <p className="text-xs text-muted-foreground text-center">
            Note: Husk at drikke vand gennem dagen
          </p>
        </div>
      </CardContent>
    </Card>
  );
}