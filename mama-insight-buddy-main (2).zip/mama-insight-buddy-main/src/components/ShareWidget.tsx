import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Share2, Copy, Lock, Eye, EyeOff } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function ShareWidget() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [shareLink, setShareLink] = useState<string>('');
  const [pinCode, setPinCode] = useState<string>('');
  const [showPin, setShowPin] = useState(false);
  const [isLinkGenerated, setIsLinkGenerated] = useState(false);
  const { toast } = useToast();

  const generateShareLink = async () => {
    setIsGenerating(true);
    try {
      // Simulate API call to generate secure share link
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const randomId = Math.random().toString(36).substring(2, 8);
      const generatedPin = Math.floor(1000 + Math.random() * 9000).toString();
      
      const link = `https://babynest.app/data/${randomId}`;
      setShareLink(link);
      setPinCode(generatedPin);
      setIsLinkGenerated(true);
      
      toast({
        title: "Delingslink genereret",
        description: "Linket er nu klar til deling med din sundhedsfaglige kontakt.",
      });
    } catch (error) {
      toast({
        title: "Fejl",
        description: "Kunne ikke generere delingslink. Prøv igen.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async (text: string, type: 'link' | 'pin') => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: `${type === 'link' ? 'Link' : 'Pinkode'} kopieret`,
        description: `${type === 'link' ? 'Linket' : 'Pinkoden'} er kopieret til udklipsholder.`,
      });
    } catch (error) {
      toast({
        title: "Fejl",
        description: "Kunne ikke kopiere til udklipsholder.",
        variant: "destructive",
      });
    }
  };

  const resetShare = () => {
    setShareLink('');
    setPinCode('');
    setIsLinkGenerated(false);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Share2 className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">Del med sundhedsfaglig</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {!isLinkGenerated ? (
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <Eye className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-blue-800 font-medium mb-1">
                    Sikker deling
                  </p>
                  <p className="text-xs text-blue-700">
                    Generer et sikkert link med pinkode til deling med din læge eller jordemoder. 
                    Linket giver engangsadgang til din rapport.
                  </p>
                </div>
              </div>
            </div>

            <Button 
              onClick={generateShareLink}
              disabled={isGenerating}
              className="w-full"
            >
              {isGenerating ? 'Genererer...' : 'Generer delingslink'}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Share Link */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Delingslink</label>
              <div className="flex space-x-2">
                <Input 
                  value={shareLink}
                  readOnly
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(shareLink, 'link')}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* PIN Code */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Pinkode</label>
              <div className="flex space-x-2">
                <Input 
                  type={showPin ? 'text' : 'password'}
                  value={pinCode}
                  readOnly
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowPin(!showPin)}
                >
                  {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyToClipboard(pinCode, 'pin')}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Security Info */}
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <Lock className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-green-800 font-medium mb-1">
                    Sikkerhed
                  </p>
                  <p className="text-xs text-green-700">
                    Linket udløber automatisk efter 24 timer og kan kun bruges én gang. 
                    Del både link og pinkode med din sundhedsfaglige kontakt.
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                onClick={resetShare}
                className="flex-1"
              >
                Generer nyt link
              </Button>
              <Button 
                onClick={() => {
                  copyToClipboard(`${shareLink}\nPinkode: ${pinCode}`, 'link');
                }}
                className="flex-1"
              >
                Kopier alt
              </Button>
            </div>
          </div>
        )}

        {/* Instructions */}
        <div className="text-xs text-muted-foreground space-y-1">
          <p>• Linket giver adgang til din rapport i 24 timer</p>
          <p>• Del både link og pinkode med din læge/jordemoder</p>
          <p>• Linket kan kun bruges én gang</p>
        </div>
      </CardContent>
    </Card>
  );
} 
