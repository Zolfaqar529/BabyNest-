import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { AIService, UserContext, DailyData } from "@/lib/aiService";
import { GPTService } from "@/lib/gptService";
import { 
  MessageCircle, 
  Send, 
  ArrowLeft,
  Bot,
  User,
  Heart,
  Baby,
  Lightbulb
} from "lucide-react";

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

interface AIChatProps {
  onBack: () => void;
  userProfile: {
    motherName: string;
    expectedDate: string;
    babyName: string;
    babyGender: string;
    isPostpartum: boolean;
  };
}

export default function AIChat({ onBack, userProfile }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [recentData, setRecentData] = useState<DailyData[]>([]);

  // Load historical data and initialize chat
  useEffect(() => {
    // Load recent tracking data for context
    const existingHistory = localStorage.getItem("babynest_history") || "[]";
    const history: DailyData[] = JSON.parse(existingHistory);
    setRecentData(history.slice(-7)); // Last 7 days

    // Initialize with personalized greeting and micro-notification
    const microNotification = AIService.generateMicroNotification(userProfile);
    const initialMessage: Message = {
      id: "1",
      text: `Hej ${userProfile.motherName}! 👋 Jeg er din personlige AI-rådgiver.\n\n${microNotification}\n\nJeg kan hjælpe dig med spørgsmål om graviditet, symptomer, babys udvikling og meget mere. Hvad kan jeg hjælpe dig med i dag?`,
      isUser: false,
      timestamp: new Date()
    };
    setMessages([initialMessage]);
  }, [userProfile]);

  const quickQuestions = [
    "Er det normalt at have ondt i lænden?",
    "Hvad kan jeg gøre ved kvalme?",
    "Hvordan udvikler min baby sig denne uge?", 
    "Hvordan har du det i dag?",
    "Kan du hjælpe med at analysere mine symptomer?",
    "Hvornår skal jeg kontakte min jordemoder?"
  ];

  const handleSendMessage = async (text: string) => {
    if (!text.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: text,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText("");
    setIsTyping(true);

    // Generate AI response
    setTimeout(async () => {
      const aiResponse = await generateAIResponse(text);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        isUser: false,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
      
      // Save chat messages for daily report
      const chatHistory = JSON.parse(localStorage.getItem("babynest_chat") || "[]");
      chatHistory.push(userMessage, aiMessage);
      localStorage.setItem("babynest_chat", JSON.stringify(chatHistory));
    }, 1500);
  };

  const generateAIResponse = async (question: string): Promise<string> => {
    const pregnancyWeek = AIService.calculatePregnancyWeek(userProfile.expectedDate, userProfile.isPostpartum);
    
    // Try advanced GPT response first
    try {
      const gptResponse = await GPTService.generateContextualResponse(
        question,
        { ...userProfile, pregnancyWeek },
        recentData,
        messages.slice(-5).map(m => m.text) // Last 5 messages for context
      );
      return gptResponse;
    } catch (error) {
      console.error('GPT service failed, falling back to basic AI:', error);
    }

    // Fallback to existing logic
    const lowerQuestion = question.toLowerCase();
    
    // Check for emotional support questions
    if (lowerQuestion.includes("hvordan har du det") || lowerQuestion.includes("hvordan føler")) {
      const insight = AIService.generateCombinedInsight(recentData, userProfile);
      let response = `Tak fordi du spørger, kære ${userProfile.motherName}. Det betyder meget at du deler dine oplevelser med mig. 💕\n\n`;
      
      if (insight) {
        response += `${insight.observation} ${insight.empathicMessage}\n\n💡 ${insight.suggestion}`;
      } else if (recentData.length > 0) {
        const summary = AIService.generateDiarySummary(recentData, userProfile);
        if (summary) {
          response += `${summary}\n\nHusk at hver dag er anderledes, og du gør det fantastisk! ✨`;
        }
      } else {
        response += "Jeg kan se at det er første gang vi taler - jeg vil gerne lære dig bedre at kende. Fortæl mig gerne, hvordan du har det i dag? 🌸";
      }
      
      return response;
    }

    // Symptom analysis
    if (lowerQuestion.includes("symptom") || lowerQuestion.includes("analyse")) {
      if (recentData.length === 0) {
        return `For at give dig den bedste hjælp med symptomanalyse, anbefaler jeg at du starter med at registrere dine daglige oplevelser i tracking-delen. 📊\n\nMen fortæl mig gerne - hvilke symptomer oplever du? Jeg kan stadig give dig generel vejledning. 💝`;
      }
      
      const recentSymptoms = recentData.slice(-3).flatMap(d => d.symptoms);
      if (recentSymptoms.length === 0) {
        return `Det er dejligt at høre at du ikke har registreret mange symptomer på det seneste! 😊\n\nHvad specifikt kunne du tænke dig hjælp til? Jeg er her for at støtte dig. 💚`;
      }
      
      const analysis = AIService.analyzeSymptom(recentSymptoms[0], userProfile, recentData);
      return `${analysis.empathicResponse}\n\n**Om ${analysis.symptom.toLowerCase()}:**\n${analysis.explanation}\n\n**Mine forslag:**\n${analysis.suggestions.map(s => `• ${s}`).join('\n')}\n\n${analysis.needsAttention ? '⚠️ Dette er noget du bør holde ekstra øje med.' : '💚 Dette er typisk normalt i din situation.'}`;
    }

    // Development questions  
    if (lowerQuestion.includes("udvikl") || lowerQuestion.includes("baby")) {
      const week = AIService.calculatePregnancyWeek(userProfile.expectedDate, userProfile.isPostpartum);
      const personalizedText = AIService.generatePersonalizedDevelopmentText(week, userProfile);
      
      return `**${userProfile.babyName}s udvikling** 👶\n\n${personalizedText}\n\n✨ Hver dag er ${userProfile.babyName} tættere på at møde dig. Du gør et fantastisk job!`;
    }

    // Individual symptom responses with enhanced context
    if (lowerQuestion.includes("ryg") || lowerQuestion.includes("lænd")) {
      const analysis = AIService.analyzeSymptom("rygsmerter", userProfile, recentData);
      return `${analysis.empathicResponse}\n\n${analysis.explanation}\n\n**Mine forslag til dig:**\n${analysis.suggestions.map(s => `• ${s}`).join('\n')}`;
    }
    
    if (lowerQuestion.includes("kvalme") || lowerQuestion.includes("morgenkvalme")) {
      const analysis = AIService.analyzeSymptom("kvalme", userProfile, recentData);
      return `${analysis.empathicResponse}\n\n${analysis.explanation}\n\n**Prøv disse tips:**\n${analysis.suggestions.map(s => `• ${s}`).join('\n')}`;
    }

    if (lowerQuestion.includes("træt") || lowerQuestion.includes("energi")) {
      const analysis = AIService.analyzeSymptom("træthed", userProfile, recentData);
      return `${analysis.empathicResponse}\n\n${analysis.explanation}\n\n**For at booste din energi:**\n${analysis.suggestions.map(s => `• ${s}`).join('\n')}`;
    }

    // Contact guidance
    if (lowerQuestion.includes("jordemoder") || lowerQuestion.includes("læge") || lowerQuestion.includes("kontakt")) {
      return "Kontakt din jordemoder eller læge hvis du oplever: 🚨\n\n• Kraftige blødninger\n• Kraftige mavesmerter\n• Vedvarende hovedpine\n• Synsforstyrrelser\n• Kraftig hævelse af hænder/ansigt\n• Feber over 38°C\n• Manglende fosterbevægelser\n• Vedvarend kvalme/opkast\n\nHusk: Det er altid bedre at ringe én gang for meget end én gang for lidt, kære " + userProfile.motherName + "! 💕";
    }

    // Fallback with personal touch
    const microTip = AIService.generateMicroNotification(userProfile);
    return `Tak for dit spørgsmål, ${userProfile.motherName}! 💭\n\n${microTip}\n\nJeg vil gerne hjælpe dig bedre - prøv at omformulere dit spørgsmål eller vælg et af de hurtige spørgsmål ovenfor. Du kan også spørge mig "Hvordan har du det i dag?" for en mere personlig samtale. ✨`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-primary-glow/10 p-4 pb-20">
      <div className="max-w-sm mx-auto space-y-4">
        {/* Header */}
        <div className="flex items-center space-x-3 mb-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Tilbage
          </Button>
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-primary to-primary-glow rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">AI Rådgiver</h1>
              <p className="text-muted-foreground">Din personlige graviditetsassistent</p>
            </div>
          </div>
        </div>

        {/* Quick questions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Lightbulb className="w-5 h-5 mr-2 text-warning" />
              Populære spørgsmål
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-2">
              {quickQuestions.map((question, index) => (
                <Badge
                  key={index}
                  variant="outline"
                  className="cursor-pointer p-3 text-left hover:bg-primary hover:text-primary-foreground transition-all justify-start"
                  onClick={() => handleSendMessage(question)}
                >
                  {question}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Chat messages */}
        <Card className="min-h-[400px]">
          <CardContent className="p-6">
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex items-start space-x-3 ${
                    message.isUser ? "justify-end" : "justify-start"
                  }`}
                >
                  {!message.isUser && (
                    <div className="w-8 h-8 bg-gradient-to-r from-primary to-primary-glow rounded-full flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                  )}
                  
                  <div
                    className={`max-w-md p-4 rounded-lg ${
                      message.isUser
                        ? "bg-primary text-primary-foreground ml-12"
                        : "bg-muted mr-12"
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{message.text}</p>
                    <p className="text-xs opacity-70 mt-2">
                      {message.timestamp.toLocaleTimeString("da-DK", { 
                        hour: "2-digit", 
                        minute: "2-digit" 
                      })}
                    </p>
                  </div>
                  
                  {message.isUser && (
                    <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                      <User className="w-4 h-4 text-secondary-foreground" />
                    </div>
                  )}
                </div>
              ))}
              
              {isTyping && (
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-primary to-primary-glow rounded-full flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-muted p-4 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-100" />
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce delay-200" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Input */}
        <Card>
          <CardContent className="p-4">
            <div className="flex space-x-2">
              <Input
                placeholder="Stil et spørgsmål om graviditet, symptomer eller baby..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage(inputText)}
                className="flex-1"
              />
              <Button 
                onClick={() => handleSendMessage(inputText)}
                disabled={!inputText.trim() || isTyping}
                className="bg-gradient-to-r from-primary to-primary-glow"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}