-- Create daily_entries table for daily tracking data
CREATE TABLE public.daily_entries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  date DATE NOT NULL,
  physical_feelings TEXT,
  emotional_state TEXT,
  notes TEXT,
  energy_level INTEGER,
  ai_feedback TEXT,
  symptoms TEXT[],
  source_tab TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, date)
);

-- Enable Row Level Security
ALTER TABLE public.daily_entries ENABLE ROW LEVEL SECURITY;

-- Create policies for daily_entries
CREATE POLICY "Users can view their own daily entries" 
ON public.daily_entries 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own daily entries" 
ON public.daily_entries 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own daily entries" 
ON public.daily_entries 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own daily entries" 
ON public.daily_entries 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_daily_entries_updated_at
BEFORE UPDATE ON public.daily_entries
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();