-- Fix sleep field to allow decimal values and ensure all tracking data fields support appropriate data types
ALTER TABLE daily_entries 
ALTER COLUMN sleep TYPE NUMERIC(4,2);

-- Also ensure other numeric fields can handle decimals if needed
ALTER TABLE daily_entries 
ALTER COLUMN weight TYPE TEXT; -- Already text, but ensure it stays that way for flexibility

-- Add missing indexes for better performance
CREATE INDEX IF NOT EXISTS idx_daily_entries_user_date ON daily_entries(user_id, date);
CREATE INDEX IF NOT EXISTS idx_baby_logs_user_date ON baby_logs(user_id, date);