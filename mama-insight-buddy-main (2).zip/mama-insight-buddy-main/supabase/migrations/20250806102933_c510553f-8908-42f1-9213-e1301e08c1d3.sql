-- Add new fields to daily_entries table
ALTER TABLE public.daily_entries 
ADD COLUMN stress_level INTEGER CHECK (stress_level >= 1 AND stress_level <= 10),
ADD COLUMN sleep_quality INTEGER CHECK (sleep_quality >= 1 AND sleep_quality <= 10),
ADD COLUMN nausea_level INTEGER CHECK (nausea_level >= 1 AND nausea_level <= 10);

-- Add research data sharing option to profiles
ALTER TABLE public.profiles 
ADD COLUMN share_data_for_research BOOLEAN DEFAULT false;

-- Create AI responses table
CREATE TABLE public.ai_responses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  question TEXT NOT NULL,
  response TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on ai_responses
ALTER TABLE public.ai_responses ENABLE ROW LEVEL SECURITY;

-- Create policies for ai_responses
CREATE POLICY "Users can view their own AI responses" 
ON public.ai_responses 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own AI responses" 
ON public.ai_responses 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Create pregnancy week content table
CREATE TABLE public.pregnancy_week_content (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  week_number INTEGER NOT NULL UNIQUE CHECK (week_number >= 1 AND week_number <= 42),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  tip TEXT NOT NULL,
  illustration_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on pregnancy_week_content (public read access)
ALTER TABLE public.pregnancy_week_content ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access to pregnancy content
CREATE POLICY "Anyone can view pregnancy week content" 
ON public.pregnancy_week_content 
FOR SELECT 
USING (true);

-- Add triggers for timestamp updates
CREATE TRIGGER update_ai_responses_updated_at
BEFORE UPDATE ON public.ai_responses
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_pregnancy_week_content_updated_at
BEFORE UPDATE ON public.pregnancy_week_content
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample pregnancy week content
INSERT INTO public.pregnancy_week_content (week_number, title, message, tip) VALUES
(12, 'Uge 12 - Første trimester er slut!', 'Tillykke! Du har gennemført det første trimester. Din baby er nu fuldt udviklet i miniature og risikoen for spontan abort er betydeligt reduceret.', 'Det er nu sikkert at dele de gode nyheder med familie og venner.'),
(16, 'Uge 16 - Første bevægelser', 'Du kan måske begynde at mærke babys første svage bevægelser. Det føles ofte som små bobler eller sommerfugle i maven.', 'Læg mærke til mønstre i babys bevægelser - de bliver mere regelmæssige over tid.'),
(20, 'Uge 20 - Halvvejs der!', 'Du er nu halvvejs gennem din graviditet! Dette er en milepæl at fejre. Din baby vokser støt og du kan mærke mere regelmæssige bevægelser.', 'Overvej at booke din anatomiscanoning hvis du ikke allerede har gjort det.'),
(24, 'Uge 24 - Viabilitet', 'Din baby har nu nået viabilitet, hvilket betyder at overlevelschancerne ved for tidlig fødsel er væsentligt forbedret.', 'Tal med din jordemoder om tegn på for tidlig fødsel og hvornår du skal kontakte hospitalet.'),
(28, 'Uge 28 - Tredje trimester!', 'Velkommen til det tredje og sidste trimester! Din baby vokser hurtigt nu og du kan mærke kraftigere bevægelser.', 'Begynd at overveje din fødselsplan og tal med din partner om jeres ønsker.'),
(32, 'Uge 32 - Hjernen udvikles', 'Babys hjerne gennemgår en intens udviklingsperiode. Søvn-vågen cyklusser bliver mere etablerede.', 'Læs eller syng for din baby - de kan høre og genkende din stemme.'),
(36, 'Uge 36 - Næsten klar!', 'Din baby er nu næsten fuldt udviklet. Lungerne modnes og babys position stabiliseres.', 'Pak din hospitalstaske og lav en plan for transporten til hospitalet.'),
(40, 'Uge 40 - Termin!', 'Du har nået din beregnede termin! Din baby er nu fuldt udviklet og klar til at møde verden.', 'Husk at kun 5% føder på selve terminen - det er normalt at gå over tid.');