-- Extend profiles table with additional fields
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS parent_name TEXT,
ADD COLUMN IF NOT EXISTS due_date DATE,
ADD COLUMN IF NOT EXISTS baby_name TEXT,
ADD COLUMN IF NOT EXISTS baby_gender TEXT,
ADD COLUMN IF NOT EXISTS consent_given BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS profile_image_url TEXT;

-- Create baby_logs table for post-birth tracking
CREATE TABLE IF NOT EXISTS public.baby_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  baby_id UUID,
  date DATE NOT NULL,
  sleep_hours DECIMAL(4,2),
  sleep_quality INTEGER,
  feeding_times INTEGER,
  feeding_notes TEXT,
  diaper_changes INTEGER,
  weight_grams INTEGER,
  length_cm DECIMAL(5,2),
  notes TEXT,
  mood_rating INTEGER,
  development_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on baby_logs
ALTER TABLE public.baby_logs ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for baby_logs
CREATE POLICY "Users can view their own baby logs" 
ON public.baby_logs 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own baby logs" 
ON public.baby_logs 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own baby logs" 
ON public.baby_logs 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own baby logs" 
ON public.baby_logs 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add additional fields to daily_entries for better tracking
ALTER TABLE public.daily_entries 
ADD COLUMN IF NOT EXISTS mood INTEGER,
ADD COLUMN IF NOT EXISTS sleep INTEGER,
ADD COLUMN IF NOT EXISTS weight TEXT,
ADD COLUMN IF NOT EXISTS exercise TEXT;

-- Create trigger for baby_logs updated_at
CREATE TRIGGER update_baby_logs_updated_at
BEFORE UPDATE ON public.baby_logs
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_baby_logs_user_date ON public.baby_logs(user_id, date);
CREATE INDEX IF NOT EXISTS idx_daily_entries_user_date ON public.daily_entries(user_id, date);

-- Add foreign key constraint to baby_logs (optional, referencing babies table)
-- ALTER TABLE public.baby_logs 
-- ADD CONSTRAINT fk_baby_logs_baby 
-- FOREIGN KEY (baby_id) REFERENCES public.babies(id) ON DELETE SET NULL;